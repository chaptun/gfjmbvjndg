/* skwc_Omni service worker: เปิดเร็ว + ติดตั้งเป็นแอปได้ (ข้อมูลจาก /api ไม่ถูกแคช) */
const V = 'skwc-v2', SHELL = ['/', '/css/style.css', '/js/app.js', '/js/admin.js', '/js/extra.js', '/icons/icon-192.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(V).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== V).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api') || u.pathname.startsWith('/uploads') || u.pathname.startsWith('/brand') || u.pathname === '/theme.css' || u.pathname === '/manifest.webmanifest') return;
  e.respondWith(fetch(e.request).then((r) => { if (r.ok) { const c = r.clone(); caches.open(V).then((x) => x.put(e.request, c)); } return r; }).catch(() => caches.match(e.request).then((m) => m || caches.match('/'))));
});
