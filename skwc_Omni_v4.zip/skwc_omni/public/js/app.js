'use strict';
/* skwc_Omni — หน้าบ้าน (Vanilla JS SPA) */
const SK = (window.SK = { user: null, meta: null, site: null, acts: {}, forms: {}, inputs: {}, timers: [], pages: {}, state: {} });
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const BKK = 'Asia/Bangkok';

const ICONS = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>', search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  book: '<path d="M4 19V5a2 2 0 0 1 2-2h14v16H6a2 2 0 0 0-2 2zm0 0a2 2 0 0 0 2 2h14"/>', chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-5.4A8 8 0 1 1 21 12z"/>',
  trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>', plus: '<path d="M12 5v14M5 12h14"/>', logout: '<path d="M9 21H5V3h4M16 17l5-5-5-5M21 12H9"/>',
  eyeoff: '<path d="M3 3l18 18M10.6 6.1A9 9 0 0 1 12 6c5 0 9 6 9 6a15 15 0 0 1-3.2 3.7M6.6 6.7C4 8.4 3 12 3 12s4 6 9 6a9 9 0 0 0 3-.5"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>', check: '<path d="M5 12l5 5 9-10"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>', list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 21a7 7 0 0 1 14 0M17 4.5a3.5 3.5 0 0 1 0 7M22 21a6 6 0 0 0-4-5.6"/>', image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="M21 16l-5-5L5 21"/>',
  pin: '<path d="M12 21s7-6.2 7-12a7 7 0 0 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/>', star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  send: '<path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>', lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>', info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>', x: '<path d="M6 6l12 12M18 6L6 18"/>', back: '<path d="M15 5l-7 7 7 7"/>', clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1"/>',
  sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 3v4M17 5h4M5 17v4M3 19h4"/>', bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 21a2 2 0 0 0 4 0"/>',
  calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>', mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.5 7.5l8.5 6 8.5-6"/>', menu: '<path d="M4 7h16M4 12h16M4 17h16"/>', thumbup: '<path d="M7 11v9H4v-9zM7 11l4-7c1.5 0 2.5 1 2 2.5L12.5 10H19a2 2 0 0 1 2 2.3l-1 6A2 2 0 0 1 18 20H7"/>', thumbdown: '<path d="M7 13V4H4v9zM7 13l4 7c1.5 0 2.5-1 2-2.5L12.5 14H19a2 2 0 0 0 2-2.3l-1-6A2 2 0 0 0 18 4H7"/>', printer: '<path d="M7 9V3h10v6M7 17H4v-7h16v7h-3M7 14h10v7H7z"/>',
  megaphone: '<path d="M3 11v2a1 1 0 0 0 1 1h3l8 4V6L7 10H4a1 1 0 0 0-1 1z"/><path d="M18.5 9a4 4 0 0 1 0 6"/><path d="M7 14l1.5 5h2.5l-1-4.5"/>', edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>', crown: '<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/>',
  palette: '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.2-2.5 1.6-2.5H17a4 4 0 0 0 4-4C21 6.5 17 3 12 3z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7" r="1"/>', upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
};
const ic = (n) => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

/* ---------- utils ---------- */
async function api(method, path, body) {
  const r = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: body ? JSON.stringify(body) : undefined });
  let j = null; try { j = await r.json(); } catch (e) { /* no body */ }
  if (!r.ok) {
    if (r.status === 401 && !path.startsWith('/auth/login')) { SK.user = null; if (!location.hash.startsWith('#/login')) location.hash = '#/login'; }
    const e = new Error((j && j.error) || 'เกิดข้อผิดพลาด'); e.status = r.status; e.data = j; throw e;
  }
  return j;
}
function toast(msg, type) {
  const el = document.createElement('div'); el.className = 'toast ' + (type || ''); el.setAttribute('role', 'status');
  el.innerHTML = `${ic(type === 'err' ? 'alert' : type === 'ok' ? 'check' : 'info')}<span>${esc(msg)}</span>`;
  $('#toasts').appendChild(el); setTimeout(() => el.remove(), 4200);
}
const fail = (e) => toast(e.message || 'เกิดข้อผิดพลาด', 'err');
const dt = (s) => (s ? new Date(s.includes('T') ? s : s.replace(' ', 'T') + 'Z') : null);
function ago(s) {
  const d = dt(s); if (!d) return ''; const m = Math.floor((Date.now() - d) / 60000);
  if (m < 1) return 'เมื่อสักครู่'; if (m < 60) return m + ' นาทีที่แล้ว'; const h = Math.floor(m / 60); if (h < 24) return h + ' ชั่วโมงที่แล้ว';
  const dd = Math.floor(h / 24); if (dd < 7) return dd + ' วันที่แล้ว'; return d.toLocaleDateString('th-TH', { timeZone: BKK, day: 'numeric', month: 'short', year: '2-digit' });
}
const full = (s) => { const d = dt(s); return d ? d.toLocaleString('th-TH', { timeZone: BKK, dateStyle: 'medium', timeStyle: 'short' }) : ''; };
const hm = (s) => { const d = dt(s); return d ? d.toLocaleTimeString('th-TH', { timeZone: BKK, hour: '2-digit', minute: '2-digit' }) : ''; };
const day = (s) => (s ? new Date(s + 'T00:00:00').toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: '2-digit' }) : '');
const tagNo = (id) => 'No. ' + String(id).padStart(4, '0');
const person = (p) => (p.anon ? `${esc(p.name)}` : `${esc(p.name)}${roleBadge(p)}${p.grade ? ` · ม.${p.grade}${p.room ? '/' + esc(p.room) : ''}` : ''}`);
const initial = (n) => esc(String(n || '?').trim().charAt(0));
const opts = (arr, sel, ph) => (ph ? `<option value="">${esc(ph)}</option>` : '') + arr.map((o) => `<option ${o === sel ? 'selected' : ''}>${esc(o)}</option>`).join('');
const debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
function setPage(html) { $('#root').innerHTML = html; window.scrollTo(0, 0); requestAnimationFrame(afterRender); }
/* ยศ: ป้ายข้างชื่อ (นักเรียนทั่วไปไม่แสดง) */
const ROLE_IC = { council: 'users', teacher: 'book', director: 'crown', admin: 'shield' };
const roleBadge = (p) => (p && p.role && p.role !== 'student' && p.role_label && !p.anon ? `<span class="role ${p.role}">${ic(ROLE_IC[p.role] || 'star')}${esc(p.role_label)}</span>` : '');
/* รูปแสดงเต็มภาพเสมอ (object-fit: contain) + พื้นหลังเบลอจากรูปเดียวกัน */
const imgfit = (src, alt, cls) => `<div class="imgfit ${cls || ''}" style="--bg:url('${esc(src)}')"><img src="${esc(src)}" alt="${esc(alt)}" loading="lazy"></div>`;
let revealIO = null;
function afterRender() {
  $$('.tags>*,.newsgrid>*,.cards>*,.stats>*,.lb').forEach((el, n) => { if (el.classList.contains('reveal')) return; el.classList.add('reveal'); el.style.setProperty('--i', n % 8); });
  if (!('IntersectionObserver' in window)) { $$('.reveal').forEach((e) => e.classList.add('in')); }
  else { revealIO = revealIO || new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); revealIO.unobserve(e.target); } }), { threshold: 0.08 }); $$('.reveal:not(.in)').forEach((e) => revealIO.observe(e)); }
  $$('[data-count]').forEach((el) => {  // นับเลขขึ้นแบบแอนิเมชัน
    const to = +el.dataset.count || 0, off = document.documentElement.dataset.anim === 'off'; if (off || to < 2) { el.textContent = to; return; }
    const t0 = performance.now(), dur = 900; const f = (t) => { const k = Math.min(1, (t - t0) / dur); el.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(f); }; requestAnimationFrame(f);
  });
}
function applySite() {
  const s = SK.site; if (!s) return;
  document.documentElement.dataset.anim = s.anim_level || 'full';
  document.title = `${s.brand_name} — ${s.school_name}`;
  const m = $('meta[name=theme-color]'); if (m) m.content = s.theme_color;
}
function reloadTheme(preview) { const l = $('#theme-css'); if (l) l.href = '/theme.css?v=' + Date.now() + (preview ? '&c=' + encodeURIComponent(preview) : ''); }
const feat = (k) => !SK.site || !SK.site.features || SK.site.features[k] !== false;
const loading = () => `<div class="loading"><div class="spin" role="progressbar" aria-label="กำลังโหลด"></div></div>`;
const empty = (icon, title, sub) => `<div class="empty">${ic(icon)}<div class="b">${esc(title)}</div>${sub ? `<div class="sm">${esc(sub)}</div>` : ''}</div>`;

function modal(html, wide) {
  closeModal();
  const bg = document.createElement('div'); bg.className = 'modal-bg'; bg.id = 'modal';
  bg.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${html}</div>`;
  bg.addEventListener('mousedown', (e) => { if (e.target === bg) closeModal(); });
  document.body.appendChild(bg);
  const f = $('input,select,textarea,button.btn', bg); if (f) f.focus();
  return bg;
}
function closeModal() { const m = $('#modal'); if (m) m.remove(); }
function confirmBox(title, text, okLabel, onOk, danger) {
  modal(`<h2>${esc(title)}</h2><p class="mute">${esc(text)}</p><div class="row mt" style="justify-content:flex-end"><button class="btn ghost" data-act="close">ยกเลิก</button><button class="btn ${danger ? 'danger' : ''}" id="cfm-ok">${esc(okLabel)}</button></div>`);
  $('#cfm-ok').onclick = async () => { closeModal(); try { await onOk(); } catch (e) { fail(e); } };
}
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });
document.addEventListener('click', (e) => { const el = e.target.closest('[data-act]'); if (!el) return; const f = SK.acts[el.dataset.act]; if (f) { if (el.tagName === 'A' && !el.getAttribute('href')) e.preventDefault(); f(el, e); } });
document.addEventListener('submit', (e) => { const f = e.target.closest('[data-form]'); if (!f) return; e.preventDefault(); const h = SK.forms[f.dataset.form]; if (h) h(f, e); });
document.addEventListener('input', (e) => { const el = e.target.closest('[data-in]'); if (el && SK.inputs[el.dataset.in]) SK.inputs[el.dataset.in](el); });
document.addEventListener('change', (e) => { const el = e.target.closest('[data-ch]'); if (el && SK.inputs[el.dataset.ch]) SK.inputs[el.dataset.ch](el); });
SK.acts.close = closeModal;

/* ---------- shell ---------- */
function unreadBadge() { const n = SK.user ? SK.user.unread : 0; return `<span class="badge unread-b ${n ? '' : 'hide'}" data-u>${n}</span>`; }
const notifBadge = () => { const n = SK.user ? SK.user.notif_unread : 0; return `<span class="badge ${n ? '' : 'hide'}" data-n>${n}</span>`; };
function navItems() { // เมนูหลัก (เรียบ ๆ) — ที่เหลืออยู่ในหน้า "เมนู"
  return [['#/home', 'home', 'หน้าแรก'], ['#/news', 'megaphone', 'ประกาศ'], feat('calendar') && ['#/calendar', 'calendar', 'ปฏิทิน'], feat('items') && ['#/items', 'search', 'ของหาย'], feat('tutor') && ['#/tutor', 'book', 'ติวเตอร์'], feat('ai') && ['#/ai', 'sparkle', (SK.site && SK.site.ai_name) || 'skwc_AI']].filter(Boolean);
}
function tabItems() { return [['#/home', 'home', 'หน้าแรก'], ['#/news', 'megaphone', 'ประกาศ'], feat('ai') && ['#/ai', 'sparkle', 'AI'], feat('items') ? ['#/items', 'search', 'ของหาย'] : feat('tutor') && ['#/tutor', 'book', 'ติวเตอร์'], ['#/menu', 'menu', 'เมนู']].filter(Boolean); }
function shell(content, active) {
  const u = SK.user, site = SK.site || {};
  const link = ([h, i, t]) => `<a href="${h}" class="${active === h || (h === '#/menu' && ['#/chats', '#/leaderboard', '#/suggest', '#/inbox', '#/profile', '#/notifications', '#/calendar', '#/tutor'].includes(active) && !navItems().some((x) => x[0] === active)) ? 'on' : ''}">${ic(i)}<span>${t}</span></a>`;
  const nav = navItems().map(link).join('');
  const logo = site.logo ? `<span class="logo img"><img src="${esc(site.logo)}" alt="ตราโรงเรียน"></span>` : `<span class="logo"><span>${esc(String(site.brand_name || 'SK').slice(0, 2).toUpperCase())}</span></span>`;
  const ticker = site.ticker_on === '1' && site.ticker_text ? `<div class="ticker" role="status"><div class="ticker-in"><span>${ic('megaphone')} ${esc(site.ticker_text)}</span></div></div>` : '';
  return `${ticker}<header class="topbar"><div class="topbar-in">
    <a class="brand" href="#/home">${logo}<span>${esc(site.brand_name || 'skwc_Omni')}<small>${esc(SK.meta ? SK.meta.school_name : '')}</small></span></a>
    <nav class="nav" aria-label="เมนูหลัก">${nav}</nav>
    <div class="who">
      <a class="iconbtn ${active === '#/notifications' ? 'on' : ''}" href="#/notifications" title="แจ้งเตือน" aria-label="แจ้งเตือน">${ic('bell')}${notifBadge()}</a>
      <a class="iconbtn ${active === '#/chats' ? 'on' : ''}" href="#/chats" title="แชต" aria-label="แชต">${ic('chat')}${unreadBadge()}</a>
      <a class="iconbtn desk ${active === '#/menu' ? 'on' : ''}" href="#/menu" title="เมนูทั้งหมด" aria-label="เมนูทั้งหมด">${ic('menu')}</a>
      ${feat('leaderboard') ? `<a class="pts" href="#/leaderboard" title="คะแนนความดี">${ic('star')}<b>${u.points}</b></a>` : ''}
      <a href="#/profile" class="avatar" title="โปรไฟล์ของฉัน" aria-label="โปรไฟล์ของฉัน">${initial(u.name)}</a></div></div></header>
    <main class="page">${content}</main>${site.footer_text ? `<footer class="foot">${esc(site.footer_text)}</footer>` : ''}<nav class="tabbar" aria-label="เมนูมือถือ">${tabItems().map(link).join('')}</nav>`;
}
async function refreshMe() {
  try { SK.user = await api('GET', '/auth/me'); $$('[data-u]').forEach((b) => { b.textContent = SK.user.unread; b.classList.toggle('hide', !SK.user.unread); }); $$('[data-n]').forEach((b) => { b.textContent = SK.user.notif_unread; b.classList.toggle('hide', !SK.user.notif_unread); }); } catch (e) { /* handled in api */ }
}
setInterval(() => { if (SK.user && !document.hidden) refreshMe(); }, 15000);

/* ---------- login ---------- */
SK.pages.login = () => {
  const s = SK.site || {}, school = (SK.meta && SK.meta.school_name) || s.school_name || '';
  const light = s.logo_light || s.logo, dark = s.logo;
  const feats = [['megaphone', 'ประกาศโรงเรียน', 'ข่าวสารจากสภานักเรียน ครู และผู้บริหาร', true], ['tag', 'บอร์ดของหาย', 'แจ้งของที่พบ ตามหาของ พร้อมรูปและจุดที่พบ', feat('items')], ['book', 'จับคู่ติวเตอร์', 'ม.1–ม.6 แยกตามวิชา ติวกับเพื่อนในโรงเรียน', feat('tutor')], ['sparkle', (s.ai_name || 'skwc_AI') + ' ผู้ช่วยตอบกฎระเบียบ', 'ถามได้ทันทีว่าทำแบบนี้ผิดกฎไหม พร้อมเหตุผล', feat('ai')]].filter((x) => x[3]);
  setPage(`<div class="login">
    <section class="login-art">
      <div class="la-grid" aria-hidden="true"></div><i class="blob b1"></i><i class="blob b2"></i>
      <div class="la-inner">
        <div class="la-badge">${light ? `<img src="${esc(light)}" alt="ตราโรงเรียน${esc(school)}">` : ic('shield')}</div>
        <div class="la-title"><span class="la-eyebrow">${esc(school || 'ระบบโรงเรียน')}</span><h1>${esc(s.login_title || 'skwc_Omni')}</h1><p>${esc(s.login_text || '')}</p></div>
        <ul class="la-feats">${feats.map(([i, t, d]) => `<li><span class="la-ico">${ic(i)}</span><span><b>${esc(t)}</b><small>${esc(d)}</small></span></li>`).join('')}</ul>
      </div>
    </section>
    <section class="login-form"><div class="lf-wrap">
      <div class="lf-top">${dark ? `<img class="lf-logo" src="${esc(dark)}" alt="">` : ''}<div><b>${esc(s.brand_name || 'skwc_Omni')}</b><small>${esc(school)}</small></div></div>
      <form data-form="login" class="lf-card" autocomplete="on">
        <div class="lf-head"><h2>เข้าสู่ระบบ</h2><p>ยินดีต้อนรับ ใช้บัญชีนักเรียนของคุณเข้าใช้งาน</p></div>
        <label class="field icon-field"><span>เลขประจำตัวนักเรียน</span><div class="inwrap">${ic('user')}<input class="in" name="student_id" inputmode="numeric" autocomplete="username" placeholder="เช่น 10001" required autofocus></div></label>
        <label class="field icon-field"><span>รหัสผ่าน <em>(เริ่มต้น = เลขบัตรประชาชน 13 หลัก)</em></span><div class="inwrap pw">${ic('lock')}<input class="in" type="password" name="password" autocomplete="current-password" placeholder="••••••••••••" required><button type="button" data-act="togglepw" aria-label="แสดงหรือซ่อนรหัสผ่าน">${ic('eye')}</button></div></label>
        <div id="login-err" class="alert bad hide" role="alert"></div>
        <button class="btn block lg" type="submit"><span>เข้าสู่ระบบ</span>${ic('back').replace('class="ic"', 'class="ic flip"')}</button>
        <div class="lf-note">${ic('shield')}<span>ข้อมูลของคุณถูกเข้ารหัส ผู้ดูแลระบบไม่สามารถดูรหัสผ่านย้อนหลังได้</span></div>
      </form>
      <p class="lf-help">ลืมรหัสผ่านหรือเข้าสู่ระบบไม่ได้? ติดต่อครูที่ปรึกษาหรือผู้ดูแลระบบ</p>
    </div></section></div>`);
};
SK.acts.togglepw = (el) => { const i = $('input', el.parentElement); i.type = i.type === 'password' ? 'text' : 'password'; el.innerHTML = ic(i.type === 'password' ? 'eye' : 'eyeoff'); };
SK.forms.login = async (f) => {
  const btn = $('button[type=submit]', f), err = $('#login-err'); btn.disabled = true; err.classList.add('hide');
  try { await api('POST', '/auth/login', { student_id: f.elements.student_id.value.trim(), password: f.elements.password.value }); await boot(); location.hash = '#/home'; route(); }
  catch (e) { err.textContent = e.message; err.classList.remove('hide'); btn.disabled = false; }
};
SK.acts.logout = async () => { try { await api('POST', '/auth/logout'); } catch (e) { /* ignore */ } SK.user = null; location.hash = '#/login'; route(); };

/* ---------- force change password ---------- */
SK.pages.changepw = () => {
  setPage(`<div class="login-form" style="min-height:100vh"><form data-form="changepw" class="card stack" style="max-width:440px;width:100%">
    <div><h2>ตั้งรหัสผ่านใหม่</h2><p class="mute sm mt">เพื่อความปลอดภัย กรุณาเปลี่ยนรหัสผ่านก่อนเริ่มใช้งาน อย่างน้อย 8 ตัวอักษร และต้องไม่ใช่เลขบัตรประชาชน</p></div>
    <label class="field"><span>รหัสผ่านปัจจุบัน</span><input class="in" type="password" name="current" autocomplete="current-password" required></label>
    <label class="field"><span>รหัสผ่านใหม่</span><input class="in" type="password" name="password" minlength="8" autocomplete="new-password" required></label>
    <label class="field"><span>ยืนยันรหัสผ่านใหม่</span><input class="in" type="password" name="confirm" minlength="8" autocomplete="new-password" required></label>
    <div id="cp-err" class="alert bad hide" role="alert"></div>
    <div class="row"><button class="btn grow" type="submit">บันทึกรหัสผ่านใหม่</button>${SK.user && !SK.user.must_change ? '<a class="btn ghost" href="#/profile">ยกเลิก</a>' : '<button type="button" class="btn ghost" data-act="logout">ออก</button>'}</div></form></div>`);
};
SK.forms.changepw = async (f) => {
  const err = $('#cp-err'); err.classList.add('hide');
  if (f.elements.password.value !== f.elements.confirm.value) { err.textContent = 'รหัสผ่านใหม่ทั้งสองช่องไม่ตรงกัน'; err.classList.remove('hide'); return; }
  try { await api('POST', '/auth/change-password', { current: f.elements.current.value, password: f.elements.password.value }); await refreshMe(); toast('เปลี่ยนรหัสผ่านแล้ว', 'ok'); location.hash = '#/home'; route(); }
  catch (e) { err.textContent = e.message; err.classList.remove('hide'); }
};

/* ---------- lost & found ---------- */
const STATUS = (i) => {
  if (i.status === 'open') return i.kind === 'found' ? ['รอเจ้าของมารับ', ''] : ['ยังตามหาอยู่', 'lost'];
  return { claimed: ['กำลังติดต่อกัน', 'warn'], pending_admin: ['รอแอดมินยืนยัน', 'info'], returned: ['คืนแล้ว', 'ok'], closed: ['ปิดโพสต์', ''] }[i.status] || [i.status, ''];
};
function tagCard(i) {
  const [st, cls] = STATUS(i);
  return `<a class="tag ${i.status === 'returned' ? 'done' : ''}" href="#/item/${i.id}"><span class="tag-hole"></span>
    ${i.photo ? imgfit(i.photo, i.title, 'tag-photo') : `<div class="tag-photo imgfit">${ic('image')}</div>`}
    <div class="tag-body"><div class="tag-top"><span class="pill ${i.kind === 'lost' ? 'lost' : ''}">${i.kind === 'found' ? 'พบของ' : 'ตามหา'}</span><span class="tag-no">${tagNo(i.id)}</span></div>
      <h3>${esc(i.title)}</h3>
      <div class="meta">${ic('pin')}<span>${esc(i.location || 'ไม่ระบุสถานที่')}</span></div>
      <div class="meta">${ic('clock')}<span>${i.event_date ? day(i.event_date) : ago(i.created_at)}</span></div>
      <div class="tag-foot"><span class="pill ${cls}">${st}</span><span class="xs mute">${i.poster.anon ? esc(i.poster.name) : esc((i.poster.name || '').split(' ')[0])}</span></div></div></a>`;
}
SK.state.items = { kind: '', status: 'open', category: '', location: '', q: '', mine: '' };
SK.pages.items = async () => {
  const f = SK.state.items; setPage(shell(loading(), '#/items'));
  const m = SK.meta;
  setPage(shell(`<div class="page-head"><div><h1>บอร์ดของหาย</h1><p>ค้นหาของที่ตามหา หรือแจ้งของที่เก็บได้</p></div>
      <div class="row"><a class="btn" href="#/items/new?kind=found">${ic('plus')}แจ้งของที่พบ</a><a class="btn ghost" href="#/items/new?kind=lost">${ic('search')}ตามหาของหาย</a></div></div>
    <div class="card flat stack">
      <div class="row"><input class="in grow" type="search" placeholder="ค้นหา เช่น กระเป๋า ขวดน้ำ ห้องสมุด" value="${esc(f.q)}" data-in="itemq" aria-label="ค้นหา">
        <select class="in" style="width:auto" data-ch="itemcat" aria-label="หมวดหมู่">${opts(m.categories, f.category, 'ทุกหมวด')}</select>
        <select class="in" style="width:auto" data-ch="itemloc" aria-label="สถานที่">${opts(m.locations, f.location, 'ทุกสถานที่')}</select></div>
      <div class="row between"><div class="chips" id="kind-chips">${[['', 'ทั้งหมด'], ['found', 'พบของ'], ['lost', 'ตามหา']].map(([v, t]) => `<button class="chip ${f.kind === v ? 'on' : ''}" data-act="itemkind" data-v="${v}">${t}</button>`).join('')}</div>
        <div class="row"><div class="chips">${[['open', 'ยังไม่ได้คืน'], ['returned', 'คืนแล้ว']].map(([v, t]) => `<button class="chip ${f.status === v ? 'on' : ''}" data-act="itemstatus" data-v="${v}">${t}</button>`).join('')}
        <button class="chip ${f.mine ? 'on' : ''}" data-act="itemmine">ของฉัน</button></div></div></div></div>
    <div id="item-list" class="mt2">${loading()}</div>`, '#/items'));
  loadItems();
};
async function loadItems() {
  const f = SK.state.items, p = new URLSearchParams(); Object.entries(f).forEach(([k, v]) => { if (v) p.set(k, v); });
  const box = $('#item-list'); if (!box) return;
  try { const list = await api('GET', '/items?' + p); box.innerHTML = list.length ? `<div class="tags">${list.map(tagCard).join('')}</div>` : empty('search', 'ไม่พบรายการที่ตรงกับตัวกรอง', 'ลองเปลี่ยนคำค้นหา หรือแจ้งเป็นโพสต์ใหม่'); } catch (e) { fail(e); }
}
SK.acts.itemkind = (el) => { SK.state.items.kind = el.dataset.v; $$('#kind-chips .chip').forEach((c) => c.classList.toggle('on', c === el)); loadItems(); };
SK.acts.itemstatus = (el) => { SK.state.items.status = el.dataset.v; $$('[data-act=itemstatus]').forEach((c) => c.classList.toggle('on', c === el)); loadItems(); };
SK.acts.itemmine = (el) => { SK.state.items.mine = SK.state.items.mine ? '' : '1'; el.classList.toggle('on'); loadItems(); };
SK.inputs.itemq = debounce((el) => { SK.state.items.q = el.value.trim(); loadItems(); });
SK.inputs.itemcat = (el) => { SK.state.items.category = el.value; loadItems(); };
SK.inputs.itemloc = (el) => { SK.state.items.location = el.value; loadItems(); };

function resizeImage(file, max = 1024, type = 'image/jpeg') {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => { const s = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement('canvas'); c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
      const g = c.getContext('2d'); if (type === 'image/jpeg') { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); } g.drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res(c.toDataURL(type, 0.86)); };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('เปิดไฟล์รูปไม่ได้')); }; img.src = url;
  });
}
SK.pages.itemNew = (q) => {
  const m = SK.meta, kind = q.get('kind') === 'lost' ? 'lost' : 'found', today = new Date().toLocaleDateString('en-CA', { timeZone: BKK });
  setPage(shell(`<div class="page-head"><div><a href="#/items" class="sm">${ic('back')} กลับไปบอร์ด</a><h1 class="mt">แจ้งของ</h1></div></div>
    <form class="card stack" data-form="itemnew" style="max-width:720px">
      <div class="seg" role="group" aria-label="ประเภท"><button type="button" class="${kind === 'found' ? 'on' : ''}" data-act="itemnewkind" data-v="found">ฉันเก็บของได้</button><button type="button" class="${kind === 'lost' ? 'on' : ''}" data-act="itemnewkind" data-v="lost">ฉันทำของหาย</button></div>
      <input type="hidden" name="kind" value="${kind}">
      <label class="field"><span>ชื่อสิ่งของ</span><input class="in" name="title" maxlength="80" required placeholder="เช่น กระเป๋าดินสอสีชมพู"></label>
      <div class="grid2"><label class="field"><span>หมวดหมู่</span><select class="in" name="category">${opts(m.categories)}</select></label>
        <label class="field"><span id="loc-l">${kind === 'found' ? 'สถานที่ที่เก็บได้' : 'สถานที่ที่คาดว่าทำหาย'}</span><select class="in" name="location">${opts(m.locations)}</select></label></div>
      <label class="field"><span>วันที่</span><input class="in" type="date" name="event_date" value="${today}" max="${today}"></label>
      <label class="field"><span>รายละเอียด</span><textarea class="in" name="description" maxlength="500" placeholder="สี ขนาด ตำหนิ ฯลฯ"></textarea>
        <small id="hint">${kind === 'found' ? 'เก็บลักษณะเฉพาะบางอย่างไว้ถามเจ้าของเพื่อยืนยัน อย่าบอกทั้งหมดในโพสต์' : 'ห้ามใส่เบอร์โทรหรือช่องทางติดต่อส่วนตัว ให้คุยผ่านแชตในเว็บ'}</small></label>
      <div class="field"><span>รูปถ่าย (ไม่บังคับ แต่ช่วยให้เจอเจ้าของไวขึ้น)</span><label class="upload" id="up"><input type="file" accept="image/*" hidden id="photo-in" data-ch="photo"><div id="up-prev">${ic('image')}<div>แตะเพื่อถ่ายรูปหรือเลือกรูป</div></div></label><input type="hidden" name="photo"></div>
      ${SK.user.anon_enabled ? `<div class="alert">${ic('eyeoff')}<span>โหมดไม่ระบุตัวตนเปิดอยู่ โพสต์นี้จะแสดงเป็นนามแฝงต่อผู้ใช้อื่น</span></div>` : ''}
      <div class="row"><button class="btn" type="submit">โพสต์ลงบอร์ด</button><a class="btn ghost" href="#/items">ยกเลิก</a></div></form>`, '#/items'));
};
SK.acts.itemnewkind = (el) => {
  const f = $('form[data-form=itemnew]'); f.elements.kind.value = el.dataset.v; $$('.seg button', f).forEach((b) => b.classList.toggle('on', b === el));
  $('#loc-l').textContent = el.dataset.v === 'found' ? 'สถานที่ที่เก็บได้' : 'สถานที่ที่คาดว่าทำหาย';
  $('#hint').textContent = el.dataset.v === 'found' ? 'เก็บลักษณะเฉพาะบางอย่างไว้ถามเจ้าของเพื่อยืนยัน อย่าบอกทั้งหมดในโพสต์' : 'ห้ามใส่เบอร์โทรหรือช่องทางติดต่อส่วนตัว ให้คุยผ่านแชตในเว็บ';
};
SK.inputs.photo = async (el) => {
  const f = el.files[0]; if (!f) return;
  try { const d = await resizeImage(f, +el.dataset.max || 1280); $('input[name=photo]').value = d; $('#up-prev').innerHTML = `<img src="${d}" alt="ตัวอย่างรูป"><div class="sm">แตะเพื่อเปลี่ยนรูป</div>`; } catch (e) { fail(e); }
};
SK.forms.itemnew = async (f) => {
  const btn = $('button[type=submit]', f); btn.disabled = true;
  try {
    const r = await api('POST', '/items', { kind: f.elements.kind.value, title: f.elements.title.value, category: f.elements.category.value, location: f.elements.location.value, event_date: f.elements.event_date.value, description: f.elements.description.value, photo: f.elements.photo.value || undefined });
    toast('โพสต์ลงบอร์ดแล้ว', 'ok'); location.hash = '#/item/' + r.id;
  } catch (e) { fail(e); btn.disabled = false; }
};
const STEPS = ['แจ้งบนบอร์ด', 'มีผู้ติดต่อ', 'เจ้าของรับของ', 'แอดมินให้คะแนน'];
SK.pages.item = async (id) => {
  setPage(shell(loading(), '#/items'));
  let i; try { i = await api('GET', '/items/' + id); } catch (e) { setPage(shell(empty('alert', e.message, 'รายการนี้อาจถูกลบหรือไม่มีอยู่'), '#/items')); return; }
  const [st, cls] = STATUS(i), idx = { open: 1, claimed: 2, pending_admin: 3, returned: 4 }[i.status];
  const acts = [];
  if (i.can_respond) acts.push(`<button class="btn" data-act="respond" data-id="${i.id}">${i.kind === 'found' ? 'นี่คือของฉัน' : 'ฉันพบของชิ้นนี้'}</button>`);
  if (i.conv_id) acts.push(`<a class="btn ${i.can_respond ? 'ghost' : ''}" href="#/chats/${i.conv_id}">${ic('chat')}เปิดแชต</a>`);
  if (i.can_confirm_received) acts.push(`<button class="btn ok" data-act="received" data-id="${i.id}">${ic('check')}ได้รับของคืนแล้ว</button>`);
  if (i.can_release) acts.push(`<button class="btn ghost" data-act="release" data-id="${i.id}">ไม่ใช่เจ้าของ / ยกเลิกการติดต่อ</button>`);
  if (i.mine && ['open', 'claimed'].includes(i.status)) acts.push(`<button class="btn danger" data-act="closeitem" data-id="${i.id}">ปิดโพสต์</button>`);
  setPage(shell(`<a href="#/items" class="sm">${ic('back')} กลับไปบอร์ด</a>
    <div class="detail mt">${i.photo ? imgfit(i.photo, i.title, 'photo') : `<div class="photo imgfit">${ic('image')}</div>`}
    <div><div class="row"><span class="pill ${i.kind === 'lost' ? 'lost' : ''}">${i.kind === 'found' ? 'พบของ' : 'ตามหาของ'}</span><span class="pill ${cls}">${st}</span><span class="tag-no">${tagNo(i.id)}</span></div>
      <h1 class="mt">${esc(i.title)}</h1>
      <dl class="kv"><dt>หมวดหมู่</dt><dd>${esc(i.category || '-')}</dd><dt>สถานที่</dt><dd>${esc(i.location || '-')}</dd><dt>วันที่</dt><dd>${i.event_date ? day(i.event_date) : '-'}</dd>
        <dt>ผู้โพสต์</dt><dd>${person(i.poster)}</dd><dt>โพสต์เมื่อ</dt><dd>${full(i.created_at)}</dd>${i.responder ? `<dt>ผู้ติดต่อ</dt><dd>${person(i.responder)}</dd>` : ''}</dl>
      ${i.description ? `<p style="white-space:pre-wrap">${esc(i.description)}</p>` : ''}
      ${idx ? `<ul class="steps" aria-label="ขั้นตอน">${STEPS.map((s, n) => `<li class="${n < idx ? 'done' : n === idx ? 'now' : ''}">${s}</li>`).join('')}</ul>` : ''}
      <div class="row mt">${acts.join('')}</div>
      <div class="alert mt">${ic('star')}<span>เมื่อของถูกส่งคืนและแอดมินยืนยัน ผู้ที่ช่วยหาของเจอจะได้รับ <b>+${SK.meta.points_return} คะแนนความดี</b></span></div>
    </div></div>`, '#/items'));
};
SK.acts.respond = (el) => confirmBox('ยืนยันการติดต่อ', 'ระบบจะเปิดแชตกับผู้โพสต์ ให้อธิบายลักษณะของที่ไม่ปรากฏในโพสต์เพื่อยืนยัน แล้วนัดรับของในโรงเรียน', 'ตกลง เปิดแชต', async () => { const r = await api('POST', `/items/${el.dataset.id}/respond`); location.hash = '#/chats/' + r.conv_id; });
SK.acts.received = (el) => confirmBox('ยืนยันว่าได้รับของคืนแล้ว?', 'กดเมื่อได้รับของจริงเท่านั้น แอดมินจะตรวจสอบและให้คะแนนผู้ช่วยหาของ', 'ยืนยัน ได้รับของแล้ว', async () => { await api('POST', `/items/${el.dataset.id}/received`); toast('ส่งให้แอดมินตรวจสอบแล้ว', 'ok'); SK.pages.item(el.dataset.id); });
SK.acts.release = (el) => confirmBox('ยกเลิกการติดต่อ?', 'โพสต์จะกลับไปเปิดรับใหม่อีกครั้ง', 'ยกเลิกการติดต่อ', async () => { await api('POST', `/items/${el.dataset.id}/release`); SK.pages.item(el.dataset.id); });
SK.acts.closeitem = (el) => confirmBox('ปิดโพสต์นี้?', 'โพสต์จะไม่แสดงบนบอร์ดอีก', 'ปิดโพสต์', async () => { await api('POST', `/items/${el.dataset.id}/close`); location.hash = '#/items'; }, true);

/* ---------- tutor ---------- */
SK.state.tutor = { kind: 'offer', grade: '', subject: '', q: '' };
function tutorCard(t) {
  return `<article class="tcard ${t.kind}"><div class="grade"><div><small>ม.</small>${t.grade}</div></div>
    <div><h3>${esc(t.subject)}</h3><div class="row"><span class="pill ${t.kind === 'offer' ? '' : 'lost'}">${t.kind === 'offer' ? 'มีคนสอน' : 'อยากเรียน'}</span><span class="xs mute">${ago(t.created_at)}</span></div></div>
    <p class="topic">${esc(t.topic || 'ไม่มีรายละเอียดเพิ่มเติม')}</p>${t.schedule ? `<p class="sm mute" style="grid-column:1/-1;margin-top:.3rem">${ic('clock')} ${esc(t.schedule)}</p>` : ''}
    <div class="foot"><span class="sm">${person(t.poster)}${t.rating ? ` <span class="stars" title="${t.rating.count} รีวิว">★ ${t.rating.avg} <small>(${t.rating.count})</small></span>` : ''}</span>${t.mine ? `<button class="btn sm danger" data-act="closetutor" data-id="${t.id}">ปิดโพสต์</button>` : `<button class="btn sm" data-act="contacttutor" data-id="${t.id}">${ic('chat')}ติดต่อ</button>`}</div></article>`;
}
SK.pages.tutor = async () => {
  const f = SK.state.tutor, m = SK.meta;
  setPage(shell(`<div class="page-head"><div><h1>จับคู่ติวเตอร์</h1><p>เลือกชั้นและวิชา แล้วคุยกันผ่านแชตในเว็บ</p></div><a class="btn" href="#/tutor/new">${ic('plus')}ลงประกาศ</a></div>
    <div id="matches"></div>
    <div class="card flat stack"><div class="row between"><div class="seg" id="tk"><button class="${f.kind === 'offer' ? 'on' : ''}" data-act="tkind" data-v="offer">มีคนสอน</button><button class="${f.kind === 'request' ? 'on' : ''}" data-act="tkind" data-v="request">อยากเรียน</button></div>
      <button class="chip ${f.kind === 'mine' ? 'on' : ''}" data-act="tkind" data-v="mine">โพสต์ของฉัน</button></div>
      <div class="chips" id="tg"><button class="chip ${f.grade === '' ? 'on' : ''}" data-act="tgrade" data-v="">ทุกชั้น</button>${[1, 2, 3, 4, 5, 6].map((g) => `<button class="chip ${String(f.grade) === String(g) ? 'on' : ''}" data-act="tgrade" data-v="${g}">ม.${g}</button>`).join('')}</div>
      <div class="row"><select class="in grow" data-ch="tsub" aria-label="วิชา">${opts(m.subjects, f.subject, 'ทุกวิชา')}</select><input class="in grow" type="search" placeholder="ค้นหาหัวข้อ" value="${esc(f.q)}" data-in="tq" aria-label="ค้นหา"></div></div>
    <div id="tlist" class="mt2">${loading()}</div>`, '#/tutor'));
  loadTutor(); loadMatches();
};
async function loadMatches() {
  try {
    const ms = (await api('GET', '/tutor/matches')).filter((x) => x.matches.length); const box = $('#matches'); if (!box || !ms.length) return;
    box.innerHTML = `<div class="match mt" style="margin-bottom:1.2rem"><h2>${ic('star')} จับคู่ให้คุณแล้ว</h2><p class="sm mute">โพสต์ของคุณมีคนที่ชั้นและวิชาตรงกัน</p>${ms.map((x) => `<div class="mt"><div class="b sm">${x.post.kind === 'offer' ? 'คุณสอน' : 'คุณอยากเรียน'} ${esc(x.post.subject)} ม.${x.post.grade}</div><div class="cards mt">${x.matches.map(tutorCard).join('')}</div></div>`).join('')}</div>`;
  } catch (e) { /* ignore */ }
}
async function loadTutor() {
  const f = SK.state.tutor, p = new URLSearchParams();
  if (f.kind === 'mine') p.set('mine', '1'); else p.set('kind', f.kind);
  if (f.grade && f.kind !== 'mine') p.set('grade', f.grade); if (f.subject && f.kind !== 'mine') p.set('subject', f.subject); if (f.q) p.set('q', f.q);
  const box = $('#tlist'); if (!box) return;
  try { const l = await api('GET', '/tutor?' + p); box.innerHTML = l.length ? `<div class="cards">${l.map(tutorCard).join('')}</div>` : empty('book', 'ยังไม่มีประกาศที่ตรงกัน', 'ลงประกาศของคุณเองแล้วระบบจะจับคู่ให้'); } catch (e) { fail(e); }
}
SK.acts.tkind = (el) => { SK.state.tutor.kind = el.dataset.v; $$('#tk button').forEach((b) => b.classList.toggle('on', b === el)); $$('[data-act=tkind]').forEach((b) => { if (b.classList.contains('chip')) b.classList.toggle('on', b === el); }); loadTutor(); };
SK.acts.tgrade = (el) => { SK.state.tutor.grade = el.dataset.v; $$('#tg .chip').forEach((c) => c.classList.toggle('on', c === el)); loadTutor(); };
SK.inputs.tsub = (el) => { SK.state.tutor.subject = el.value; loadTutor(); };
SK.inputs.tq = debounce((el) => { SK.state.tutor.q = el.value.trim(); loadTutor(); });
SK.acts.contacttutor = async (el) => { try { const r = await api('POST', `/tutor/${el.dataset.id}/contact`); location.hash = '#/chats/' + r.conv_id; } catch (e) { fail(e); } };
SK.acts.closetutor = (el) => confirmBox('ปิดประกาศนี้?', 'จะไม่แสดงในรายการอีก (ใช้เมื่อจับคู่ได้แล้ว)', 'ปิดประกาศ', async () => { await api('POST', `/tutor/${el.dataset.id}/close`); loadTutor(); loadMatches(); }, true);
SK.pages.tutorNew = () => {
  const m = SK.meta;
  setPage(shell(`<div class="page-head"><div><a href="#/tutor" class="sm">${ic('back')} กลับ</a><h1 class="mt">ลงประกาศติวเตอร์</h1></div></div>
    <form class="card stack" data-form="tutornew" style="max-width:640px">
      <div class="seg"><button type="button" class="on" data-act="tnkind" data-v="offer">ฉันสอนได้</button><button type="button" data-act="tnkind" data-v="request">ฉันอยากเรียน</button></div><input type="hidden" name="kind" value="offer">
      <div class="field"><span>ชั้นเรียนที่เกี่ยวข้อง</span><div class="chips" id="tng">${[1, 2, 3, 4, 5, 6].map((g) => `<button type="button" class="chip ${g === 6 ? 'on' : ''}" data-act="tngrade" data-v="${g}">ม.${g}</button>`).join('')}</div><input type="hidden" name="grade" value="6"><small>ผู้สอน: เลือกชั้นของเนื้อหาที่จะสอน · ผู้เรียน: เลือกชั้นที่คุณเรียนอยู่</small></div>
      <label class="field"><span>วิชา</span><select class="in" name="subject">${opts(m.subjects)}</select></label>
      <label class="field"><span>หัวข้อ / รายละเอียด</span><textarea class="in" name="topic" maxlength="300" required placeholder="เช่น ติวแคลคูลัส ลิมิตและอนุพันธ์"></textarea></label>
      <label class="field"><span>ช่วงเวลาที่สะดวก</span><input class="in" name="schedule" maxlength="120" placeholder="เช่น พักเที่ยง / หลังเลิกเรียนวันพุธ"></label>
      <div class="alert warn">${ic('lock')}<span>ห้ามใส่เบอร์โทร ไลน์ เฟซบุ๊ก ไอจี หรือช่องทางส่วนตัวอื่นๆ ระบบจะบล็อกอัตโนมัติ ให้คุยผ่านแชตในเว็บเท่านั้น</span></div>
      <div class="row"><button class="btn" type="submit">ลงประกาศ</button><a class="btn ghost" href="#/tutor">ยกเลิก</a></div></form>`, '#/tutor'));
};
SK.acts.tnkind = (el) => { const f = $('form[data-form=tutornew]'); f.elements.kind.value = el.dataset.v; $$('.seg button', f).forEach((b) => b.classList.toggle('on', b === el)); };
SK.acts.tngrade = (el) => { const f = $('form[data-form=tutornew]'); f.elements.grade.value = el.dataset.v; $$('#tng .chip').forEach((b) => b.classList.toggle('on', b === el)); };
SK.forms.tutornew = async (f) => {
  const btn = $('button[type=submit]', f); btn.disabled = true;
  try { await api('POST', '/tutor', { kind: f.elements.kind.value, grade: +f.elements.grade.value, subject: f.elements.subject.value, topic: f.elements.topic.value, schedule: f.elements.schedule.value }); toast('ลงประกาศแล้ว', 'ok'); SK.state.tutor.kind = f.elements.kind.value; location.hash = '#/tutor'; }
  catch (e) { fail(e); btn.disabled = false; }
};

/* ---------- chat ---------- */
SK.pages.chats = async (cid) => {
  setPage(shell(`<div class="chatwrap ${cid ? 'in-chat' : ''}" id="cw"><div class="card flat convlist convcol" id="cl">${loading()}</div><div class="card chatbox chatcol" id="cb">${cid ? loading() : `<div class="empty" style="margin:auto;border:0">${ic('chat')}<div class="b">เลือกการสนทนาทางซ้าย</div><div class="sm">แชตเริ่มได้จากโพสต์ของหายหรือประกาศติวเตอร์</div></div>`}</div></div>`, '#/chats'));
  const loadList = async () => {
    try {
      const l = await api('GET', '/conversations'), box = $('#cl'); if (!box) return;
      box.innerHTML = l.length ? l.map((c) => `<a class="conv ${String(c.id) === String(cid) ? 'on' : ''}" href="#/chats/${c.id}"><span class="avatar">${initial(c.other.name)}</span><div class="grow"><div class="t">${esc(c.title)}</div><div class="last">${esc(c.other.name)} · ${esc(c.last)}</div></div>${c.unread && String(c.id) !== String(cid) ? `<span class="badge">${c.unread}</span>` : ''}</a>`).join('') : empty('chat', 'ยังไม่มีแชต', 'กด "ติดต่อ" ที่ประกาศติวเตอร์ หรือ "นี่คือของฉัน" ที่โพสต์ของหาย');
    } catch (e) { fail(e); }
  };
  loadList(); SK.timers.push(setInterval(() => { if (!document.hidden) loadList(); }, 8000));
  if (!cid) return;
  let c; try { c = await api('GET', '/conversations/' + cid); } catch (e) { $('#cb').innerHTML = empty('alert', e.message); return; }
  const link = c.type === 'item' ? `#/item/${c.ref_id}` : '#/tutor';
  $('#cb').innerHTML = `<div class="chat-head"><a href="#/chats" class="btn ghost sm" id="back-btn" aria-label="กลับ">${ic('back')}</a><span class="avatar">${initial(c.other.name)}</span><div class="grow"><div class="b">${esc(c.other.name)}${roleBadge(c.other)}</div><div class="xs mute">${esc(c.title)}</div></div>${c.type === 'item' ? `<a class="btn ghost sm" href="${link}">ดูโพสต์</a>` : ''}</div>
    <div class="safe">${ic('lock')}<span>คุยในเว็บนี้เท่านั้น — ห้ามแชร์เบอร์ ไลน์ เฟซบุ๊ก ไอจี ติ๊กต่อก หรือลิงก์ ระบบตรวจจับอัตโนมัติ และผู้ดูแลระบบตรวจสอบบันทึกแชตได้</span></div>
    <div class="msgs" id="msgs" aria-live="polite"></div>
    <form class="composer" data-form="send" data-cid="${cid}"><input class="in" name="body" maxlength="500" placeholder="พิมพ์ข้อความ..." autocomplete="off" required aria-label="ข้อความ"><button class="btn" type="submit" aria-label="ส่ง">${ic('send')}</button></form>`;
  if (c.type === 'tutor') api('GET', `/conversations/${cid}/review`).then((r) => { const h = $('.chat-head'); if (!h) return; if (r.can_review) h.insertAdjacentHTML('beforeend', `<button class="btn ghost sm" data-act="review" data-cid="${cid}" data-name="${esc(r.target_name)}">${ic('star')}ให้ดาว</button>`); else if (r.reviewed) h.insertAdjacentHTML('beforeend', `<span class="pill ok">ให้ ${r.reviewed} ดาวแล้ว</span>`); }).catch(() => {});
  let last = 0; const box = $('#msgs');
  const poll = async () => {
    if (!$('#msgs')) return;
    try {
      const ms = await api('GET', `/conversations/${cid}/messages?after=${last}`); if (!ms.length) return;
      const near = box.scrollHeight - box.scrollTop - box.clientHeight < 80 || last === 0;
      ms.forEach((m) => { last = m.id; const d = document.createElement('div');
        if (m.system) { d.className = 'm sys'; d.textContent = m.body; } else { d.className = 'm ' + (m.mine ? 'me' : 'them'); d.innerHTML = `${esc(m.body)}<small>${m.mine ? '' : esc(m.sender) + ' · '}${hm(m.created_at)}</small>`; }
        box.appendChild(d); });
      if (near) box.scrollTop = box.scrollHeight; refreshMe();
    } catch (e) { /* ignore transient */ }
  };
  await poll(); SK.timers.push(setInterval(poll, 3000)); SK.poll = poll;
};
SK.forms.send = async (f) => {
  const body = f.elements.body.value.trim(); if (!body) return; const btn = $('button', f); btn.disabled = true;
  try { await api('POST', `/conversations/${f.dataset.cid}/messages`, { body }); f.elements.body.value = ''; if (SK.poll) await SK.poll(); }
  catch (e) { toast(e.message, 'err'); }
  btn.disabled = false; f.elements.body.focus();
};

/* ---------- home / leaderboard / profile ---------- */
const EV_TH = { exam: 'สอบ', activity: 'กิจกรรม', holiday: 'วันหยุด', deadline: 'กำหนดส่ง', other: 'อื่นๆ' };
const evDate = (d) => { const x = new Date(d + 'T00:00:00'); return `<span class="evdate"><b>${x.getDate()}</b><small>${x.toLocaleDateString('th-TH', { month: 'short' })}</small></span>`; };
SK.pages.home = async () => {
  setPage(shell(`<div class="skel" style="height:200px"></div>`, '#/home'));
  const [d, ev] = await Promise.all([api('GET', '/home'), feat('calendar') ? api('GET', '/events/upcoming?n=4').catch(() => []) : []]);
  const u = SK.user, s = SK.site || {}, first = (u.name || '').split(' ')[0];
  const title = esc((s.hero_title || 'สวัสดี {name}').replace('{name}', first));
  const text = s.hero_text ? esc(s.hero_text) : 'ติดตามข่าวสาร ถามกฎระเบียบ ตามหาของ และหาเพื่อนติวได้ที่เดียว';
  const tiles = [['#/news', 'megaphone', 'ประกาศ', `${d.news_total} เรื่อง`], feat('items') && ['#/items/new?kind=found', 'plus', 'แจ้งของที่พบ', 'ช่วยหาเจ้าของ'], feat('items') && ['#/items/new?kind=lost', 'search', 'ตามหาของ', 'โพสต์ของหาย'], feat('tutor') && ['#/tutor', 'book', 'ติวเตอร์', 'หาเพื่อนติว'], feat('ai') && ['#/ai', 'sparkle', 'ถาม ' + (s.ai_name || 'skwc_AI'), 'กฎระเบียบโรงเรียน'], feat('suggest') && ['#/suggest', 'mail', 'ข้อเสนอแนะ', 'ส่งถึงสภา/ผอ.']].filter(Boolean);
  setPage(shell(`<section class="hero ${s.hero_image ? 'has-img' : ''}" ${s.hero_image ? `style="background-image:url('${esc(s.hero_image)}')"` : ''}><i class="blob b1"></i><i class="blob b2"></i>
      <div><h1>${title}${roleBadge(u)}</h1><p>${text}</p></div></section>
    <div class="tiles mt">${tiles.map(([h, i, t, sub]) => `<a class="tile" href="${h}"><span class="ti">${ic(i)}</span><b>${t}</b><small>${sub}</small></a>`).join('')}</div>

    <section class="section"><div class="sec-head"><h2>ประกาศล่าสุด</h2><a href="#/news">ดูทั้งหมด ›</a></div>
      ${d.news.length ? `<div class="newsgrid">${d.news.slice(0, 3).map(newsCard).join('')}</div>` : empty('megaphone', 'ยังไม่มีประกาศ', u.can_announce ? 'กด "ลงประกาศ" เพื่อประกาศเรื่องแรก' : 'รอประกาศจากสภานักเรียนและครู')}</section>

    ${feat('calendar') || feat('ai') ? `<section class="section duo">
      ${feat('calendar') ? `<div class="card"><div class="sec-head"><h3>กิจกรรมที่กำลังจะมาถึง</h3><a href="#/calendar">ปฏิทิน ›</a></div>
        ${ev.length ? ev.map((e) => `<a class="evrow" href="#/calendar">${evDate(e.start_date)}<div class="grow"><div class="b">${esc(e.title)}</div><div class="xs mute">${esc(e.location || '')}</div></div><span class="evtype ev-${e.type}">${EV_TH[e.type]}</span></a>`).join('') : '<p class="mute sm">ยังไม่มีกิจกรรมที่ลงไว้</p>'}</div>` : ''}
      ${feat('ai') ? `<div class="card aipromo"><div class="aiorb" aria-hidden="true">${ic('sparkle')}</div><h3>ถาม ${esc(s.ai_name || 'skwc_AI')}</h3><p class="sm mute">สงสัยว่าทำแบบนี้ผิดกฎไหม? ถามได้ตลอด ไม่ต้องกลัวโดนดุ</p>
        <form class="row mt" data-form="aiquick"><input class="in grow" name="q" placeholder="เช่น ใส่รองเท้าผ้าใบมาเรียนได้ไหม" maxlength="200" aria-label="คำถามถึง AI"><button class="btn" type="submit">ถาม</button></form></div>` : ''}
    </section>` : ''}

    ${feat('items') ? `<section class="section"><div class="sec-head"><h2>ของหายล่าสุด</h2><a href="#/items">ดูบอร์ดทั้งหมด ›</a></div>
      ${d.latest.length ? `<div class="tags">${d.latest.map(tagCard).join('')}</div>` : empty('tag', 'ยังไม่มีโพสต์', 'เป็นคนแรกที่แจ้งของบนบอร์ด')}</section>` : ''}`, '#/home'));
};
SK.forms.aiquick = (f) => { const q = f.elements.q.value.trim(); location.hash = '#/ai' + (q ? '?q=' + encodeURIComponent(q) : ''); };

/* ---------- ประกาศ (news) ---------- */
const LV = { normal: '', important: 'สำคัญ', urgent: 'ด่วน' };
const lvPill = (l) => (l === 'normal' ? '' : `<span class="lv ${l}">${ic(l === 'urgent' ? 'alert' : 'star')}${LV[l]}</span>`);
function newsCard(a) {
  return `<a class="news ${a.level} ${a.pinned ? 'pinned' : ''} ${a.photo ? '' : 'noimg'}" href="#/news/${a.id}">${a.pinned ? `<span class="pinflag">${ic('pin')}ปักหมุด</span>` : ''}${a.photo ? imgfit(a.photo, a.title) : ''}
    <div class="news-body">${lvPill(a.level)}<h3>${esc(a.title)}</h3>${a.body ? `<p class="excerpt">${esc(a.body)}</p>` : ''}<div class="news-meta"><b>${esc(a.author.name)}</b>${roleBadge(a.author)}<span>· ${ago(a.created_at)}</span></div></div></a>`;
}
SK.state.news = { level: '', q: '' };
SK.pages.news = async () => {
  const f = SK.state.news;
  setPage(shell(`<div class="page-head"><div><h1>ประกาศ</h1><p>ข่าวสารจากสภานักเรียน ครู และผู้บริหาร</p></div>${SK.user.can_announce ? `<a class="btn" href="#/news/new">${ic('plus')}ลงประกาศ</a>` : ''}</div>
    <div class="card flat stack"><div class="row"><input class="in grow" type="search" placeholder="ค้นหาประกาศ" value="${esc(f.q)}" data-in="newsq" aria-label="ค้นหา"><div class="chips">${[['', 'ทั้งหมด'], ['important', 'สำคัญ'], ['urgent', 'ด่วน']].map(([v, t]) => `<button class="chip ${f.level === v ? 'on' : ''}" data-act="newslv" data-v="${v}">${t}</button>`).join('')}</div></div></div>
    <div id="news-list" class="mt2">${loading()}</div>`, '#/news'));
  loadNews();
};
async function loadNews() {
  const f = SK.state.news, p = new URLSearchParams(); if (f.level) p.set('level', f.level); if (f.q) p.set('q', f.q);
  const box = $('#news-list'); if (!box) return;
  try { const l = await api('GET', '/announcements?' + p); box.innerHTML = l.length ? `<div class="newsgrid">${l.map(newsCard).join('')}</div>` : empty('megaphone', 'ยังไม่มีประกาศ', 'ลองเปลี่ยนตัวกรอง'); afterRender(); } catch (e) { fail(e); }
}
SK.acts.newslv = (el) => { SK.state.news.level = el.dataset.v; $$('[data-act=newslv]').forEach((c) => c.classList.toggle('on', c === el)); loadNews(); };
SK.inputs.newsq = debounce((el) => { SK.state.news.q = el.value.trim(); loadNews(); });
SK.pages.newsItem = async (id) => {
  setPage(shell(loading(), '#/news'));
  let a; try { a = await api('GET', '/announcements/' + id); } catch (e) { setPage(shell(empty('alert', e.message, 'ประกาศนี้อาจถูกลบแล้ว'), '#/news')); return; }
  setPage(shell(`<a href="#/news" class="sm">${ic('back')} กลับไปประกาศ</a><article class="article mt">
    <div class="row">${lvPill(a.level)}${a.pinned ? `<span class="pill">${ic('pin')}ปักหมุด</span>` : ''}${a.status === 'hidden' ? '<span class="pill bad">ถูกซ่อน</span>' : ''}</div>
    <h1 class="mt">${esc(a.title)}</h1>
    <div class="row mt"><span class="avatar">${initial(a.author.name)}</span><div><b>${esc(a.author.name)}</b>${roleBadge(a.author)}<div class="xs mute">${full(a.created_at)}${a.updated_at ? ' · แก้ไข ' + ago(a.updated_at) : ''}</div></div></div>
    ${a.photo ? imgfit(a.photo, a.title, 'auto') : ''}
    ${a.body ? `<div class="body">${esc(a.body)}</div>` : ''}
    ${a.can_edit && SK.user.can_announce ? `<div class="row mt2"><a class="btn ghost" href="#/news/edit/${a.id}">${ic('edit')}แก้ไข</a><button class="btn danger" data-act="newsdel" data-id="${a.id}">${ic('trash')}ลบประกาศ</button></div>` : ''}</article>`, '#/news'));
};
SK.acts.newsdel = (el) => confirmBox('ลบประกาศนี้?', 'ประกาศจะหายจากหน้าเว็บทันที', 'ลบประกาศ', async () => { await api('DELETE', '/announcements/' + el.dataset.id); toast('ลบประกาศแล้ว', 'ok'); location.hash = '#/news'; }, true);
SK.pages.newsForm = async (id) => {
  let a = null;
  if (id) { try { a = await api('GET', '/announcements/' + id); } catch (e) { setPage(shell(empty('alert', e.message), '#/news')); return; } }
  const canPin = ['teacher', 'director', 'admin'].includes(SK.user.role);
  setPage(shell(`<div class="page-head"><div><a href="#/news" class="sm">${ic('back')} กลับ</a><h1 class="mt">${a ? 'แก้ไขประกาศ' : 'ลงประกาศ'}</h1></div></div>
    <form class="card stack" data-form="newsform" data-id="${a ? a.id : ''}" style="max-width:780px">
      <div class="alert">${ic('megaphone')}<span>ประกาศในนามของคุณ: <b>${esc(SK.user.name)}</b>${roleBadge(SK.user)} — ทุกคนในโรงเรียนจะเห็นประกาศนี้</span></div>
      <label class="field"><span>หัวข้อประกาศ</span><input class="in" name="title" maxlength="120" required value="${a ? esc(a.title) : ''}" placeholder="เช่น รับสมัครคณะกรรมการนักเรียน"></label>
      <label class="field"><span>รายละเอียด</span><textarea class="in" name="body" maxlength="4000" style="min-height:200px" placeholder="พิมพ์รายละเอียดประกาศ">${a ? esc(a.body || '') : ''}</textarea></label>
      <div class="grid2"><label class="field"><span>ระดับความสำคัญ</span><select class="in" name="level">${[['normal', 'ปกติ'], ['important', 'สำคัญ'], ['urgent', 'ด่วน']].map(([v, t]) => `<option value="${v}" ${a && a.level === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        ${canPin ? `<label class="field"><span>ปักหมุดไว้บนสุด</span><label class="row" style="margin-top:.5rem"><span class="switch"><input type="checkbox" name="pinned" ${a && a.pinned ? 'checked' : ''}><i></i></span><span class="sm mute">แสดงเป็นอันดับแรก</span></label></label>` : '<div></div>'}</div>
      <div class="field"><span>รูปภาพ (แสดงเต็มภาพ ไม่ถูกตัด)</span><label class="upload"><input type="file" accept="image/*" hidden id="photo-in" data-ch="photo" data-max="1600"><div id="up-prev">${a && a.photo ? `<img src="${esc(a.photo)}" alt="รูปเดิม"><div class="sm">แตะเพื่อเปลี่ยนรูป</div>` : `${ic('image')}<div>แตะเพื่อเลือกรูป</div>`}</div></label><input type="hidden" name="photo">
        ${a && a.photo ? '<label class="row mt sm"><input type="checkbox" name="remove_photo"> <span>ลบรูปเดิมออก</span></label>' : ''}</div>
      <div class="row"><button class="btn" type="submit">${a ? 'บันทึกการแก้ไข' : 'เผยแพร่ประกาศ'}</button><a class="btn ghost" href="#/news">ยกเลิก</a></div></form>`, '#/news'));
};
SK.forms.newsform = async (f) => {
  const btn = $('button[type=submit]', f); btn.disabled = true; const id = f.dataset.id;
  const body = { title: f.elements.title.value, body: f.elements.body.value, level: f.elements.level.value, pinned: f.elements.pinned ? f.elements.pinned.checked : undefined, photo: f.elements.photo.value || undefined, remove_photo: f.elements.remove_photo ? f.elements.remove_photo.checked : undefined };
  try { const r = id ? await api('PUT', '/announcements/' + id, body) : await api('POST', '/announcements', body); toast(id ? 'บันทึกแล้ว' : 'เผยแพร่ประกาศแล้ว', 'ok'); location.hash = '#/news/' + (id || r.id); }
  catch (e) { fail(e); btn.disabled = false; }
};

SK.pages.leaderboard = async () => {
  setPage(shell(loading(), '#/leaderboard'));
  const d = await api('GET', '/leaderboard'), t = d.top, ord = [t[1], t[0], t[2]].filter(Boolean);
  setPage(shell(`<div class="page-head"><div><h1>อันดับคะแนนความดี</h1><p>คืนของแล้วถูกยืนยันโดยแอดมินแล้ว ${d.returned_total} ชิ้นตลอดเวลา${d.my_rank ? ` · อันดับของคุณ ${d.my_rank}` : ''}</p></div></div>
    ${t.length ? `<div class="podium">${ord.map((p) => `<div class="pod p${p.rank}"><div class="rk">${p.rank}</div><div class="nm">${esc(p.name)}</div><div class="sc">${p.points} คะแนน</div></div>`).join('')}</div>
    <div class="card flat" style="padding:0">${t.slice(3).map((p) => `<div class="lb ${p.me ? 'me' : ''}"><span class="rk">${p.rank}</span><span class="grow">${esc(p.name)}${roleBadge(p)}${p.grade ? ` <span class="xs mute">ม.${p.grade}</span>` : ''}</span><b>${p.points}</b></div>`).join('') || '<div class="lb mute">ยังมี 3 อันดับแรกเท่านั้น</div>'}</div>` : empty('trophy', 'ยังไม่มีใครได้คะแนน', 'ช่วยเพื่อนหาของเจอเพื่อเป็นคนแรก')}`, '#/leaderboard'));
};
SK.pages.profile = async () => {
  setPage(shell(loading(), '#/profile')); await refreshMe();
  const u = SK.user, hist = await api('GET', '/me/points');
  const anon = { none: `<p class="sm mute">โหมดนี้ซ่อนชื่อจริงของคุณจากนักเรียนคนอื่นในโพสต์ แชต และอันดับ ต้องให้แอดมินอนุมัติก่อน <b>แอดมินยังเห็นตัวตนจริงของคุณเสมอ</b> เพื่อดูแลความปลอดภัย</p><button class="btn mt" data-act="anonreq">ขออนุมัติโหมดไม่ระบุตัวตน</button>`,
    pending: `<div class="alert warn">${ic('clock')}<span>ส่งคำขอแล้ว รอแอดมินอนุมัติ${u.anon_note ? `<br><span class="xs">เหตุผล: ${esc(u.anon_note)}</span>` : ''}</span></div>`,
    rejected: `<div class="alert bad">${ic('x')}<span>คำขอไม่ได้รับการอนุมัติ หากมีข้อสงสัยให้ติดต่อผู้ดูแลระบบ</span></div>`,
    approved: `<div class="row between"><div><div class="b">เปิดโหมดไม่ระบุตัวตน</div><div class="sm mute">โพสต์และข้อความใหม่จะแสดงเป็นนามแฝง แอดมินยังเห็นตัวตนจริง</div></div><label class="switch"><input type="checkbox" data-ch="anontoggle" ${u.anon_enabled ? 'checked' : ''} aria-label="เปิดโหมดไม่ระบุตัวตน"><i></i></label></div>` }[u.anon_status];
  setPage(shell(`<div class="page-head"><h1>โปรไฟล์ของฉัน</h1><button class="btn ghost" data-act="logout">${ic('logout')}ออกจากระบบ</button></div>
    <div class="grid2" style="align-items:start"><div class="stack"><div class="card"><div class="row"><span class="avatar" style="width:56px;height:56px;font-size:1.4rem">${initial(u.name)}</span><div><h2>${esc(u.name)}${roleBadge(u)}</h2><div class="mute sm">เลขประจำตัว ${esc(u.student_id)}${u.grade ? ` · ม.${u.grade}${u.room ? '/' + esc(u.room) : ''}` : ''}</div></div></div></div>
      ${u.can_announce ? `<div class="card"><h3>${ic('megaphone')} สิทธิ์ของคุณ: ${esc(u.role_label)}</h3><p class="sm mute mt">คุณลงประกาศถึงทุกคนในโรงเรียนได้${u.is_backend ? ' และเข้าหลังบ้านเพื่อจัดการระบบได้' : ''}</p><div class="row mt"><a class="btn sm" href="#/news/new">${ic('plus')}ลงประกาศ</a>${u.is_backend ? `<a class="btn sm ghost" href="#/admin">${ic('shield')}หลังบ้าน</a>` : ''}</div></div>` : ''}
      <div class="card"><h3>โหมดไม่ระบุตัวตน</h3><div class="mt">${anon}</div></div>
      <div class="card"><h3>ความปลอดภัยบัญชี</h3><p class="sm mute mt">รหัสผ่านเริ่มต้นคือเลขบัตรประชาชน แนะนำให้เปลี่ยนเป็นรหัสผ่านของคุณเอง</p><a class="btn ghost mt" href="#/changepw">${ic('lock')}เปลี่ยนรหัสผ่าน</a></div></div>
    <div class="card"><div class="row between"><h3>คะแนนความดี</h3><b style="font:700 1.8rem var(--f-display);color:var(--rose-d)">${u.points}</b></div>
      <div class="mt">${hist.length ? hist.map((h) => `<div class="lb" style="padding:.55rem 0"><span class="grow sm">${esc(h.reason)}<div class="xs mute">${ago(h.created_at)}</div></span><b style="color:${h.delta > 0 ? 'var(--ok)' : 'var(--bad)'}">${h.delta > 0 ? '+' : ''}${h.delta}</b></div>`).join('') : '<p class="sm mute">ยังไม่มีประวัติคะแนน ช่วยเพื่อนหาของเพื่อเริ่มสะสมคะแนน</p>'}</div></div></div>`, '#/profile'));
};
SK.acts.anonreq = () => {
  modal(`<h2>ขอโหมดไม่ระบุตัวตน</h2><form data-form="anonreq" class="stack"><label class="field"><span>เหตุผล (ให้แอดมินพิจารณา)</span><textarea class="in" name="reason" maxlength="300" required placeholder="เช่น ไม่สะดวกให้ชื่อปรากฏเมื่อแจ้งของ"></textarea></label>
    <div class="alert">${ic('info')}<span>แอดมินจะเห็นตัวตนจริงของคุณเสมอ เพื่อป้องกันการใช้งานในทางที่ผิด</span></div>
    <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn" type="submit">ส่งคำขอ</button></div></form>`);
};
SK.forms.anonreq = async (f) => { try { await api('POST', '/anon/request', { reason: f.elements.reason.value }); closeModal(); toast('ส่งคำขอแล้ว', 'ok'); SK.pages.profile(); } catch (e) { fail(e); } };
SK.inputs.anontoggle = async (el) => { try { SK.user = await api('POST', '/anon/toggle', { enabled: el.checked }); toast(el.checked ? 'เปิดโหมดไม่ระบุตัวตนแล้ว' : 'ปิดโหมดไม่ระบุตัวตนแล้ว', 'ok'); } catch (e) { el.checked = !el.checked; fail(e); } };

/* ---------- router ---------- */
async function boot() {
  try { SK.site = await api('GET', '/public'); applySite(); } catch (e) { /* ใช้ค่าเริ่มต้น */ }
  try { SK.user = await api('GET', '/auth/me'); SK.meta = await api('GET', '/meta'); } catch (e) { SK.user = null; }
}
async function route() {
  SK.timers.forEach(clearInterval); SK.timers = []; SK.poll = null; closeModal();
  const [path, qs] = (location.hash || '#/').slice(1).split('?'), p = path.split('/').filter(Boolean), q = new URLSearchParams(qs || '');
  if (!SK.user) { await boot(); }
  if (!SK.user) { if (p[0] !== 'login') { location.hash = '#/login'; return; } return SK.pages.login(); }
  if (p[0] === 'login') { location.hash = '#/home'; return; }
  if (SK.user.must_change && p[0] !== 'changepw') { location.hash = '#/changepw'; return; }
  try {
    if (p[0] === 'changepw') return SK.pages.changepw();
    if (p[0] === 'admin') { if (!SK.user.is_backend) { location.hash = '#/home'; return; } return SK.pages.admin(p[1] || 'dashboard', p[2]); }
    switch (p[0]) {
      case 'news':
        if (p[1] === 'new' || p[1] === 'edit') { if (!SK.user.can_announce) { location.hash = '#/news'; return; } return SK.pages.newsForm(p[1] === 'edit' ? p[2] : null); }
        return p[1] ? SK.pages.newsItem(p[1]) : SK.pages.news();
      case 'menu': return SK.pages.menu();
      case 'notifications': return SK.pages.notifications();
      case 'calendar': if (!feat('calendar')) { location.hash = '#/home'; return; } return SK.pages.calendar();
      case 'suggest': if (!feat('suggest')) { location.hash = '#/home'; return; } return SK.pages.suggest();
      case 'inbox': if (!SK.user.can_announce) { location.hash = '#/home'; return; } return SK.pages.inbox();
      case 'ai': if (!feat('ai')) { location.hash = '#/home'; return; } return SK.pages.ai(q.get('q'));
      case 'items': if (!feat('items')) { location.hash = '#/home'; return; } return p[1] === 'new' ? SK.pages.itemNew(q) : SK.pages.items();
      case 'item': if (!feat('items')) { location.hash = '#/home'; return; } return SK.pages.item(p[1]);
      case 'tutor': if (!feat('tutor')) { location.hash = '#/home'; return; } return p[1] === 'new' ? SK.pages.tutorNew() : SK.pages.tutor();
      case 'chats': return SK.pages.chats(p[1]);
      case 'leaderboard': if (!feat('leaderboard')) { location.hash = '#/home'; return; } return SK.pages.leaderboard();
      case 'profile': return SK.pages.profile();
      default: return SK.pages.home();
    }
  } catch (e) { if (e.status !== 401) { setPage(shell(empty('alert', 'เปิดหน้านี้ไม่ได้', e.message), '')); } }
}
window.addEventListener('hashchange', route);
route();
