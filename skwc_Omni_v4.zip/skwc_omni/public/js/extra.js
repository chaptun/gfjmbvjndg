'use strict';
/* skwc_Omni — ฟีเจอร์เสริม: เมนู · แจ้งเตือน · ปฏิทิน · ข้อเสนอแนะ · รีวิว · จับคู่ของหาย · skwc_AI */
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
const pad2 = (n) => String(n).padStart(2, '0');
const ymd = (y, m, d) => `${y}-${pad2(m + 1)}-${pad2(d)}`;
const todayStr = () => { const n = new Date(Date.now() + 7 * 3600e3); return ymd(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate()); };

/* ================= เมนูทั้งหมด ================= */
SK.pages.menu = async () => {
  const u = SK.user, s = SK.site || {};
  const sec = (t, items) => { const l = items.filter(Boolean); return l.length ? `<h3 class="menu-h">${t}</h3><div class="menugrid">${l.map(([h, i, t2, sub, b]) => `<a class="mitem" href="${h}"><span class="ti">${ic(i)}</span><div class="grow"><b>${t2}</b><small>${sub}</small></div>${b || ''}</a>`).join('')}</div>` : ''; };
  setPage(shell(`<div class="page-head"><div><h1>เมนูทั้งหมด</h1><p>รวมทุกฟังก์ชันของ ${esc(s.brand_name || '')} ไว้ที่เดียว</p></div></div>
    ${sec('ใช้งานบ่อย', [['#/news', 'megaphone', 'ประกาศ', 'ข่าวสารจากสภา ครู ผู้บริหาร'], feat('calendar') && ['#/calendar', 'calendar', 'ปฏิทิน', 'สอบ กิจกรรม วันหยุด'], feat('items') && ['#/items', 'search', 'ของหาย', 'ตามหา / แจ้งของที่พบ'], feat('tutor') && ['#/tutor', 'book', 'ติวเตอร์', 'จับคู่ตามชั้นและวิชา'], feat('ai') && ['#/ai', 'sparkle', s.ai_name || 'skwc_AI', 'ถามกฎระเบียบ'], ['#/chats', 'chat', 'แชต', 'ข้อความของฉัน', unreadBadge()]])}
    ${sec('ชุมชน', [feat('leaderboard') && ['#/leaderboard', 'trophy', 'อันดับความดี', 'คะแนนจากการช่วยคืนของ'], feat('suggest') && ['#/suggest', 'mail', 'ข้อเสนอแนะ', 'ส่งถึงสภา/ผอ. ไม่ระบุชื่อได้'], ['#/notifications', 'bell', 'แจ้งเตือน', 'เรื่องที่เกี่ยวกับคุณ', notifBadge()]])}
    ${u.can_announce ? sec('สำหรับทีมงาน', [['#/news/new', 'plus', 'ลงประกาศ', 'ถึงทุกคนในโรงเรียน'], feat('suggest') && ['#/inbox', 'mail', 'กล่องข้อเสนอแนะ', 'อ่านและตอบกลับ'], u.is_backend && ['#/admin', 'shield', 'หลังบ้าน', 'จัดการระบบ']]) : ''}
    ${sec('บัญชี', [['#/profile', 'user', 'โปรไฟล์และตั้งค่า', u.name]])}`, '#/menu'));
};

/* ================= แจ้งเตือน ================= */
SK.pages.notifications = async () => {
  setPage(shell(loading(), '#/notifications'));
  const r = await api('GET', '/notifications');
  setPage(shell(`<div class="page-head"><div><h1>แจ้งเตือน</h1><p>${r.unread ? `ยังไม่ได้อ่าน ${r.unread} เรื่อง` : 'อ่านครบแล้ว'}</p></div>${r.unread ? '<button class="btn ghost sm" data-act="nreadall">อ่านทั้งหมด</button>' : ''}</div>
    ${r.items.length ? `<div class="card flat notifs">${r.items.map((n) => `<a class="notif ${n.read ? '' : 'unread'}" href="${esc(n.link || '#/notifications')}" data-act="nread" data-id="${n.id}"><span class="dot"></span><div class="grow"><div class="b">${esc(n.title)}</div>${n.body ? `<div class="sm mute">${esc(n.body)}</div>` : ''}</div><span class="xs mute">${ago(n.created_at)}</span></a>`).join('')}</div>` : empty('bell', 'ยังไม่มีแจ้งเตือน', 'เมื่อมีประกาศ ของหายที่ตรงกัน หรือคำตอบ จะขึ้นที่นี่')}`, '#/notifications'));
};
SK.acts.nread = async (el) => { try { await api('POST', '/notifications/read', { id: +el.dataset.id }); refreshMe(); } catch (e) { /* ไม่เป็นไร */ } };
SK.acts.nreadall = async () => { await api('POST', '/notifications/read', { all: true }); refreshMe(); SK.pages.notifications(); };

/* ================= ปฏิทิน ================= */
SK.state.cal = null;
SK.pages.calendar = async () => {
  const n = new Date(Date.now() + 7 * 3600e3); SK.state.cal = SK.state.cal || { y: n.getUTCFullYear(), m: n.getUTCMonth(), sel: null };
  setPage(shell(`<div class="page-head"><div><h1>ปฏิทินโรงเรียน</h1><p>สอบ กิจกรรม วันหยุด และกำหนดส่งงาน</p></div>${SK.user.can_announce ? `<button class="btn" data-act="evnew">${ic('plus')}เพิ่มกิจกรรม</button>` : ''}</div><div id="cal-body">${loading()}</div>`, '#/calendar'));
  loadCal();
};
async function loadCal() {
  const st = SK.state.cal, days = new Date(Date.UTC(st.y, st.m + 1, 0)).getUTCDate(), lead = new Date(Date.UTC(st.y, st.m, 1)).getUTCDay();
  let evs = []; try { evs = await api('GET', `/events?from=${ymd(st.y, st.m, 1)}&to=${ymd(st.y, st.m, days)}`); } catch (e) { fail(e); }
  const box = $('#cal-body'); if (!box) return; SK.cal = { evs };
  const on = (ds) => evs.filter((e) => e.start_date <= ds && (e.end_date || e.start_date) >= ds), td = todayStr();
  let cells = ''; for (let i = 0; i < lead; i++) cells += '<span class="cell off"></span>';
  for (let d = 1; d <= days; d++) { const ds = ymd(st.y, st.m, d), l = on(ds); cells += `<button class="cell ${ds === td ? 'today' : ''} ${st.sel === ds ? 'sel' : ''}" data-act="calday" data-d="${ds}" aria-label="${d}"><span class="dn">${d}</span>${l.slice(0, 2).map((e) => `<i class="ev ev-${e.type}">${esc(e.title)}</i>`).join('')}${l.length > 2 ? `<i class="more">+${l.length - 2}</i>` : ''}</button>`; }
  const list = (st.sel ? on(st.sel) : evs), title = new Date(Date.UTC(st.y, st.m, 1)).toLocaleDateString('th-TH', { month: 'long', year: 'numeric', timeZone: 'UTC' });
  box.innerHTML = `<div class="card calcard"><div class="calhead"><button class="btn ghost sm" data-act="calprev" aria-label="เดือนก่อน">${ic('back')}</button><h2>${title}</h2><button class="btn ghost sm" data-act="calnext" aria-label="เดือนถัดไป" style="transform:scaleX(-1)">${ic('back')}</button></div>
    <div class="calgrid"><b>อา</b><b>จ</b><b>อ</b><b>พ</b><b>พฤ</b><b>ศ</b><b>ส</b>${cells}</div>
    <div class="legend">${Object.entries(EV_TH).map(([k, v]) => `<span><i class="dotc ev-${k}"></i>${v}</span>`).join('')}</div></div>
    <div class="sec-head mt2"><h3>${st.sel ? 'วันที่ ' + day(st.sel) : 'ทั้งเดือนนี้'}</h3>${st.sel ? '<button class="btn ghost sm" data-act="calall">ดูทั้งเดือน</button>' : ''}</div>
    ${list.length ? `<div class="card flat">${list.map((e) => `<div class="evrow">${evDate(e.start_date)}<div class="grow"><div class="b">${esc(e.title)} <span class="evtype ev-${e.type}">${EV_TH[e.type]}</span></div><div class="sm mute">${e.end_date && e.end_date !== e.start_date ? `ถึง ${day(e.end_date)} · ` : ''}${esc(e.location || '')}</div>${e.description ? `<div class="sm" style="white-space:pre-wrap">${esc(e.description)}</div>` : ''}${e.author ? `<div class="xs mute">โดย ${esc(e.author.name)}${roleBadge(e.author)}</div>` : ''}</div>${e.can_edit ? `<button class="btn ghost sm" data-act="evedit" data-id="${e.id}">${ic('edit')}</button>` : ''}</div>`).join('')}</div>` : empty('calendar', st.sel ? 'วันนี้ไม่มีกิจกรรม' : 'เดือนนี้ยังไม่มีกิจกรรม')}`;
}
SK.acts.calprev = () => { const s = SK.state.cal; s.m--; if (s.m < 0) { s.m = 11; s.y--; } s.sel = null; loadCal(); };
SK.acts.calnext = () => { const s = SK.state.cal; s.m++; if (s.m > 11) { s.m = 0; s.y++; } s.sel = null; loadCal(); };
SK.acts.calday = (el) => { SK.state.cal.sel = SK.state.cal.sel === el.dataset.d ? null : el.dataset.d; loadCal(); };
SK.acts.calall = () => { SK.state.cal.sel = null; loadCal(); };
function evForm(e, d) {
  modal(`<h2>${e ? 'แก้ไขกิจกรรม' : 'เพิ่มกิจกรรม'}</h2><form class="stack" data-form="evform" data-id="${e ? e.id : ''}">
    <label class="field"><span>ชื่อกิจกรรม</span><input class="in" name="title" maxlength="100" required value="${e ? esc(e.title) : ''}"></label>
    <div class="grid2"><label class="field"><span>เริ่ม</span><input class="in" type="date" name="start_date" required value="${e ? e.start_date : d || todayStr()}"></label><label class="field"><span>สิ้นสุด (ไม่บังคับ)</span><input class="in" type="date" name="end_date" value="${e && e.end_date ? e.end_date : ''}"></label></div>
    <div class="grid2"><label class="field"><span>ประเภท</span><select class="in" name="type">${Object.entries(EV_TH).map(([k, v]) => `<option value="${k}" ${e && e.type === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label><label class="field"><span>สถานที่</span><input class="in" name="location" maxlength="80" value="${e ? esc(e.location || '') : ''}"></label></div>
    <label class="field"><span>รายละเอียด</span><textarea class="in" name="description" maxlength="1000">${e ? esc(e.description || '') : ''}</textarea></label>
    ${e ? '' : '<label class="row sm"><input type="checkbox" name="notify"> <span>แจ้งเตือนทุกคนในโรงเรียน</span></label>'}
    <div class="row" style="justify-content:space-between">${e ? `<button type="button" class="btn danger" data-act="evdel" data-id="${e.id}">${ic('trash')}ลบ</button>` : '<span></span>'}<span class="row"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn" type="submit">บันทึก</button></span></div></form>`);
}
SK.acts.evnew = () => evForm(null, SK.state.cal && SK.state.cal.sel);
SK.acts.evedit = (el) => evForm((SK.cal.evs || []).find((x) => String(x.id) === el.dataset.id));
SK.acts.evdel = (el) => confirmBox('ลบกิจกรรมนี้?', 'ลบแล้วกู้คืนไม่ได้', 'ลบ', async () => { await api('DELETE', '/events/' + el.dataset.id); toast('ลบแล้ว', 'ok'); loadCal(); }, true);
SK.forms.evform = async (f) => {
  const e = f.elements, id = f.dataset.id, b = { title: e.title.value, start_date: e.start_date.value, end_date: e.end_date.value, type: e.type.value, location: e.location.value, description: e.description.value, notify: e.notify ? e.notify.checked : false };
  try { id ? await api('PUT', '/events/' + id, b) : await api('POST', '/events', b); closeModal(); toast('บันทึกแล้ว', 'ok'); loadCal(); } catch (er) { fail(er); }
};

/* ================= กล่องข้อเสนอแนะ ================= */
SK.state.sug = { tab: 'send', to: 'council' };
SK.pages.suggest = async () => {
  const st = SK.state.sug;
  setPage(shell(`<div class="page-head"><div><h1>กล่องข้อเสนอแนะ</h1><p>บอกสิ่งที่อยากให้โรงเรียนปรับปรุง ส่งถึงสภานักเรียนหรือผู้อำนวยการ</p></div></div>
    <div class="seg"><button class="${st.tab === 'send' ? 'on' : ''}" data-act="sugtab" data-v="send">ส่งเรื่องใหม่</button><button class="${st.tab === 'mine' ? 'on' : ''}" data-act="sugtab" data-v="mine">เรื่องของฉัน / ติดตาม</button></div>
    <div id="sug-body" class="mt">${loading()}</div>`, '#/suggest'));
  if (st.tab === 'send') {
    $('#sug-body').innerHTML = `<form class="card stack" data-form="sugsend" style="max-width:720px">
      <div class="field"><span>ส่งถึง</span><div class="seg"><button type="button" class="${st.to === 'council' ? 'on' : ''}" data-act="sugto" data-v="council">สภานักเรียน</button><button type="button" class="${st.to === 'director' ? 'on' : ''}" data-act="sugto" data-v="director">ผู้อำนวยการ</button></div></div>
      <label class="field"><span>หัวข้อ</span><input class="in" name="subject" maxlength="100" required placeholder="เช่น อยากให้มีเครื่องกรองน้ำเพิ่ม"></label>
      <label class="field"><span>รายละเอียด</span><textarea class="in" name="body" maxlength="2000" required style="min-height:150px" placeholder="เล่าให้ละเอียด ปัญหาคืออะไร อยากให้ปรับอย่างไร"></textarea></label>
      <div class="trow" style="border:0"><div><div class="b">ส่งแบบไม่ระบุชื่อ</div><div class="xs mute">ระบบจะไม่บันทึกว่าใครส่ง คุณจะได้ "รหัสติดตาม" ไว้ดูคำตอบ — เก็บรหัสไว้ให้ดี หายแล้วกู้ไม่ได้</div></div><label class="switch"><input type="checkbox" name="anonymous" aria-label="ไม่ระบุชื่อ"><i></i></label></div>
      <button class="btn" type="submit">${ic('send')}ส่งข้อเสนอแนะ</button></form>`;
  } else {
    const l = await api('GET', '/suggestions/mine');
    $('#sug-body').innerHTML = `<div class="card flat stack" style="max-width:720px"><h3>ติดตามเรื่องที่ส่งแบบไม่ระบุชื่อ</h3><form class="row" data-form="sugtrack"><input class="in grow" name="code" maxlength="12" placeholder="ใส่รหัสติดตาม 8 ตัว" style="text-transform:uppercase" required><button class="btn" type="submit">ตรวจสอบ</button></form><div id="trk"></div></div>
      <h3 class="mt2">เรื่องที่ส่งแบบระบุชื่อ</h3>${l.length ? `<div class="stack mt">${l.map((s) => `<div class="card"><div class="row between"><b>${esc(s.subject)}</b><span class="pill ${s.reply ? 'ok' : s.status === 'seen' ? 'info' : ''}">${s.reply ? 'ตอบแล้ว' : s.status === 'seen' ? 'อ่านแล้ว' : 'รอดำเนินการ'}</span></div><p class="sm mute mt">ถึง${s.to_who === 'council' ? 'สภานักเรียน' : 'ผู้อำนวยการ'} · ${ago(s.created_at)}</p><p class="sm mt" style="white-space:pre-wrap">${esc(s.body)}</p>${s.reply ? `<div class="alert ok mt">${ic('chat')}<span style="white-space:pre-wrap"><b>คำตอบ:</b> ${esc(s.reply)}</span></div>` : ''}</div>`).join('')}</div>` : empty('mail', 'ยังไม่มีเรื่องที่ส่ง')}`;
  }
};
SK.acts.sugtab = (el) => { SK.state.sug.tab = el.dataset.v; SK.pages.suggest(); };
SK.acts.sugto = (el) => { SK.state.sug.to = el.dataset.v; $$('[data-act=sugto]').forEach((b) => b.classList.toggle('on', b === el)); };
SK.forms.sugsend = async (f) => {
  const b = { to_who: SK.state.sug.to, subject: f.elements.subject.value, body: f.elements.body.value, anonymous: f.elements.anonymous.checked };
  try { const r = await api('POST', '/suggestions', b); f.reset();
    modal(`<h2>ส่งเรียบร้อยแล้ว 🎉</h2><p class="mute">ขอบคุณที่ช่วยกันทำให้โรงเรียนดีขึ้น</p>${r.anonymous ? `<div class="alert warn mt">${ic('lock')}<span>รหัสติดตามของคุณ (ระบบไม่เก็บว่าใครส่ง จึงกู้คืนไม่ได้):<br><b style="font:700 1.6rem var(--f-display);letter-spacing:.12em">${r.code}</b></span></div>` : ''}<div class="row mt" style="justify-content:flex-end"><button class="btn" data-act="close">ตกลง</button></div>`);
  } catch (e) { fail(e); }
};
SK.forms.sugtrack = async (f) => {
  try { const s = await api('GET', '/suggestions/track/' + encodeURIComponent(f.elements.code.value.trim())); $('#trk').innerHTML = `<div class="card flat mt"><b>${esc(s.subject)}</b><p class="sm mute">${ago(s.created_at)} · ${s.reply ? 'ตอบแล้ว' : 'รอดำเนินการ'}</p>${s.reply ? `<div class="alert ok mt"><span style="white-space:pre-wrap">${esc(s.reply)}</span></div>` : ''}</div>`; } catch (e) { fail(e); }
};
SK.pages.inbox = async () => {
  setPage(shell(loading(), '#/inbox'));
  const l = await api('GET', '/suggestions/inbox'); SK.inbox = l;
  setPage(shell(`<div class="page-head"><div><h1>กล่องข้อเสนอแนะ</h1><p>${l.filter((x) => x.status === 'new').length} เรื่องใหม่ · เรื่องที่ส่งถึงผู้อำนวยการเห็นเฉพาะ ผอ./ผู้ดูแล</p></div></div>
    ${l.length ? `<div class="stack">${l.map((s) => `<div class="card"><div class="row between"><div><b>${esc(s.subject)}</b> <span class="pill">${s.to_who === 'council' ? 'ถึงสภา' : 'ถึง ผอ.'}</span></div><span class="pill ${s.reply ? 'ok' : s.status === 'seen' ? 'info' : 'warn'}">${s.reply ? 'ตอบแล้ว' : s.status === 'seen' ? 'อ่านแล้ว' : 'ใหม่'}</span></div>
      <p class="xs mute mt">${s.from ? `${esc(s.from.name)}${s.from.grade ? ` · ม.${s.from.grade}${s.from.room ? '/' + esc(s.from.room) : ''}` : ''}` : 'ไม่ระบุชื่อ'} · ${ago(s.created_at)}</p><p class="mt" style="white-space:pre-wrap">${esc(s.body)}</p>
      ${s.reply ? `<div class="alert ok mt"><span style="white-space:pre-wrap"><b>ตอบโดย ${esc(s.replied_by || '')}:</b> ${esc(s.reply)}</span></div>` : ''}
      <div class="row mt"><button class="btn sm" data-act="sugreply" data-id="${s.id}">${ic('chat')}${s.reply ? 'แก้คำตอบ' : 'ตอบกลับ'}</button>${s.status === 'new' ? `<button class="btn ghost sm" data-act="sugseen" data-id="${s.id}">ทำเครื่องหมายว่าอ่านแล้ว</button>` : ''}</div></div>`).join('')}</div>` : empty('mail', 'ยังไม่มีข้อเสนอแนะ')}`, '#/inbox'));
};
SK.acts.sugseen = async (el) => { await api('POST', `/suggestions/${el.dataset.id}/reply`, { status: 'seen' }); SK.pages.inbox(); };
SK.acts.sugreply = (el) => { const s = SK.inbox.find((x) => String(x.id) === el.dataset.id); modal(`<h2>ตอบกลับ</h2><p class="sm mute">${esc(s.subject)}${s.from ? '' : ' (ผู้ส่งไม่ระบุชื่อ — จะเห็นคำตอบผ่านรหัสติดตาม)'}</p><form class="stack mt" data-form="sugreply" data-id="${s.id}"><textarea class="in" name="reply" maxlength="1500" required style="min-height:130px">${esc(s.reply || '')}</textarea><div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn" type="submit">ส่งคำตอบ</button></div></form>`); };
SK.forms.sugreply = async (f) => { try { await api('POST', `/suggestions/${f.dataset.id}/reply`, { reply: f.elements.reply.value }); closeModal(); toast('ส่งคำตอบแล้ว', 'ok'); SK.pages.inbox(); } catch (e) { fail(e); } };

/* ================= รีวิวติวเตอร์ ================= */
SK.acts.review = (el) => {
  modal(`<h2>ให้ดาว ${esc(el.dataset.name)}</h2><p class="sm mute">รีวิวช่วยให้เพื่อนเลือกติวเตอร์ได้ดีขึ้น (ห้ามใส่ข้อมูลติดต่อส่วนตัว)</p><form class="stack mt" data-form="review" data-cid="${el.dataset.cid}"><input type="hidden" name="stars" value="5">
    <div class="starpick" role="radiogroup" aria-label="ให้ดาว">${[1, 2, 3, 4, 5].map((n) => `<button type="button" class="on" data-act="starpick" data-n="${n}" aria-label="${n} ดาว">★</button>`).join('')}</div>
    <textarea class="in" name="comment" maxlength="300" placeholder="เล่าประสบการณ์สั้นๆ (ไม่บังคับ)"></textarea><div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn" type="submit">ส่งรีวิว</button></div></form>`);
};
SK.acts.starpick = (el) => { const n = +el.dataset.n, f = el.closest('form'); f.elements.stars.value = n; $$('.starpick button', f).forEach((b) => b.classList.toggle('on', +b.dataset.n <= n)); };
SK.forms.review = async (f) => { try { await api('POST', `/conversations/${f.dataset.cid}/review`, { stars: +f.elements.stars.value, comment: f.elements.comment.value }); closeModal(); toast('ขอบคุณสำหรับรีวิว', 'ok'); SK.pages.chats(f.dataset.cid); } catch (e) { fail(e); } };

/* ================= จับคู่ของหายอัตโนมัติ (ต่อท้ายหน้ารายการ) ================= */
(() => {
  const orig = SK.pages.item;
  SK.pages.item = async (id) => {
    await orig(id);
    try {
      const ms = await api('GET', `/items/${id}/matches`); const pg = $('.page'); if (!ms.length || !pg) return;
      pg.insertAdjacentHTML('beforeend', `<section class="section matchbox"><div class="sec-head"><h2>${ic('sparkle')} อาจเป็นชิ้นเดียวกัน</h2></div><p class="sm mute">ระบบเทียบชื่อ รายละเอียด หมวดหมู่ และสถานที่ ให้อัตโนมัติ</p><div class="cards mt">${ms.map((m) => `<a class="card mrow" href="#/item/${m.id}">${m.photo ? imgfit(m.photo, m.title, 'mthumb') : `<span class="mthumb imgfit">${ic('image')}</span>`}<div class="grow"><b>${esc(m.title)}</b><div class="xs mute">${m.kind === 'found' ? 'พบของ' : 'ตามหาของ'}${m.location ? ' · ' + esc(m.location) : ''}</div></div><span class="pill ok">${m.score}%</span></a>`).join('')}</div></section>`);
    } catch (e) { /* ไม่เป็นไร */ }
  };
  const prof = SK.pages.profile;
  SK.pages.profile = async () => {
    await prof();
    try { const r = await api('GET', `/users/${SK.user.id}/reviews`); if (!r.count) return; const pg = $('.page'); if (pg) pg.insertAdjacentHTML('beforeend', `<div class="card mt"><h3>รีวิวติวเตอร์ของฉัน <span class="stars">★ ${r.avg} <small>(${r.count})</small></span></h3>${r.list.slice(0, 5).map((x) => `<div class="trow"><div><span class="stars">${'★'.repeat(x.stars)}</span> <span class="xs mute">${esc(x.from)}</span><div class="sm">${esc(x.comment || '')}</div></div><span class="xs mute">${ago(x.created_at)}</span></div>`).join('')}</div>`); } catch (e) { /* ไม่เป็นไร */ }
  };
})();

/* ================= skwc_AI (ผู้ใช้) ================= */
SK.ai = { hist: [], info: null, busy: false };
const VERD = { violates: ['⛔', 'ผิดกฎ', 'bad'], ok: ['✅', 'ทำได้ / ไม่ผิดกฎ', 'ok'], depends: ['⚠️', 'ขึ้นอยู่กับเงื่อนไข', 'warn'], unknown: ['❔', 'ยังไม่มีข้อมูลกฎเรื่องนี้', 'mute'], info: ['ℹ️', 'ข้อมูล', 'info'] };
const SEV_TH = { prohibit: 'ข้อห้าม', duty: 'ข้อปฏิบัติ', info: 'ข้อมูล' };
function aiBubble(r, opt) {
  const v = VERD[r.verdict] || VERD.info, pct = Math.round((r.confidence || 0) * 100);
  return `<div class="aimsg"><div class="aiorb sm" aria-hidden="true">${ic('sparkle')}</div><div class="aibody">
    <div class="verdict v-${v[2]}"><span>${v[0]}</span><b>${v[1]}</b></div>
    <div class="aians">${esc(r.answer)}</div>
    ${r.fallback ? `<div class="alert warn fallback-note">${ic('alert')}<span>${esc(r.fallback)}</span></div>` : ''}
    ${r.fallback ? `<div class="xs mute mt">${esc(r.fallback)}</div>` : ''}
    ${(r.reasoning || []).length ? `<details class="aithink"><summary>ดูวิธีคิด</summary><ol>${r.reasoning.map((x) => `<li>${esc(x)}</li>`).join('')}</ol></details>` : ''}
    ${(r.rules || []).length ? `<div class="chips mt">${r.rules.map((x) => `<button class="chip rule" data-act="airule" data-id="${x.id}">${ic('book')} ${esc(x.title)}</button>`).join('')}</div>` : ''}
    <div class="aimeta"><span class="conf" title="ความมั่นใจของ AI"><i style="width:${pct}%"></i></span><span class="xs mute">มั่นใจ ${pct}% · ${r.mode === 'llm' ? 'AI วิเคราะห์' : 'ค้นหากฎ'}</span>
      ${opt && opt.fb && r.id ? `<span class="fb"><button class="iconbtn sm" data-act="aifb" data-id="${r.id}" data-r="1" aria-label="มีประโยชน์">${ic('thumbup')}</button><button class="iconbtn sm" data-act="aifb" data-id="${r.id}" data-r="-1" aria-label="ไม่ถูกต้อง">${ic('thumbdown')}</button></span>` : ''}</div>
    ${(r.followups || []).length && opt && opt.fb ? `<div class="chips mt">${r.followups.map((q) => `<button class="chip" data-act="aifollow" data-q="${esc(q)}">${esc(q)}</button>`).join('')}</div>` : ''}</div></div>`;
}
SK.pages.ai = async (preq) => {
  setPage(shell(loading(), '#/ai'));
  const info = SK.ai.info = await api('GET', '/ai/info'); SK.ai.hist = [];
  setPage(shell(`<div class="aiwrap"><section class="aihead"><div class="aiorb big" aria-hidden="true">${ic('sparkle')}</div><div class="grow"><h1>${esc(info.name)}</h1><p>ผู้ช่วยตอบกฎระเบียบโรงเรียน เรียนรู้จากสิ่งที่แอดมินสอนไว้</p></div><span class="pill ${info.mode === 'llm' ? 'ok' : 'info'}">${info.mode === 'llm' ? 'AI คิดวิเคราะห์' : 'โหมดค้นหากฎ'}</span></section>
    <div class="aichat" id="aichat" aria-live="polite"><div class="aimsg"><div class="aiorb sm">${ic('sparkle')}</div><div class="aibody"><div class="aians">${esc(info.greeting)}</div></div></div></div>
    <div class="chips aisug" id="aisug">${(info.samples.length ? info.samples : ['ใส่รองเท้าผ้าใบสีขาวมาเรียนได้ไหม', 'เล่นมือถือในคาบเรียนผิดกฎไหม']).map((q) => `<button class="chip" data-act="aifollow" data-q="${esc(q)}">${esc(q)}</button>`).join('')}</div>
    <form class="aicomposer" data-form="aiask"><input class="in" name="q" maxlength="500" placeholder="${info.enabled ? 'พิมพ์คำถาม เช่น ทำแบบนี้ผิดกฎไหม...' : 'ปิดใช้งานชั่วคราว'}" autocomplete="off" ${info.enabled ? '' : 'disabled'} aria-label="คำถาม"><button class="btn" type="submit" ${info.enabled ? '' : 'disabled'} aria-label="ส่ง">${ic('send')}</button></form>
    <p class="xs mute center mt">AI อาจตอบผิดได้ — เรื่องสำคัญให้ถามครูอีกครั้ง · คำถามจะถูกบันทึกและแอดมินดูได้เพื่อปรับปรุงระบบ · ฐานความรู้ ${info.rules} ข้อ</p></div>`, '#/ai'));
  if (preq) aiAsk(preq);
};
async function aiAsk(q) {
  q = String(q || '').trim(); if (!q || SK.ai.busy) return; const box = $('#aichat'); if (!box) return;
  SK.ai.busy = true; const sug = $('#aisug'); if (sug) sug.remove();
  box.insertAdjacentHTML('beforeend', `<div class="usermsg">${esc(q)}</div><div class="aimsg" id="aityping"><div class="aiorb sm spin2">${ic('sparkle')}</div><div class="aibody"><div class="typing"><i></i><i></i><i></i></div></div></div>`);
  box.scrollIntoView({ block: 'end' }); window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
  try {
    const r = await api('POST', '/ai/ask', { question: q, history: SK.ai.hist.slice(-6) });
    $('#aityping').outerHTML = aiBubble(r, { fb: true }); SK.ai.hist.push({ role: 'user', text: q }, { role: 'assistant', text: r.answer });
  } catch (e) { const t = $('#aityping'); if (t) t.outerHTML = `<div class="aimsg"><div class="aiorb sm">${ic('sparkle')}</div><div class="aibody"><div class="alert bad">${esc(e.message)}</div></div></div>`; }
  SK.ai.busy = false; window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
}
SK.forms.aiask = (f) => { const q = f.elements.q.value; f.elements.q.value = ''; aiAsk(q); };
SK.acts.aifollow = (el) => aiAsk(el.dataset.q);
SK.acts.aifb = async (el) => { try { await api('POST', '/ai/feedback', { id: +el.dataset.id, rating: +el.dataset.r }); el.parentElement.innerHTML = `<span class="xs mute">${el.dataset.r === '1' ? 'ขอบคุณ 💖' : 'ขอบคุณ แอดมินจะนำไปปรับปรุง'}</span>`; } catch (e) { fail(e); } };
SK.acts.airule = async (el) => { try { const r = await api('GET', '/ai/rules/' + el.dataset.id); modal(`<h2>${esc(r.title)}</h2><div class="row"><span class="pill ${r.severity === 'prohibit' ? 'bad' : ''}">${SEV_TH[r.severity]}</span>${r.category ? `<span class="pill">${esc(r.category)}</span>` : ''}</div><p class="mt" style="white-space:pre-wrap">${esc(r.content)}</p>${r.penalty ? `<div class="alert warn mt"><span><b>ผลที่ตามมา:</b> ${esc(r.penalty)}</span></div>` : ''}${r.exceptions ? `<div class="alert mt"><span><b>ข้อยกเว้น:</b> ${esc(r.exceptions)}</span></div>` : ''}<div class="row mt" style="justify-content:flex-end"><button class="btn" data-act="close">ปิด</button></div>`); } catch (e) { fail(e); } };

/* ================= หลังบ้าน: เทรน skwc_AI (เฉพาะ role=admin) ================= */
AD.aiTab = 'overview';
const AI_TABS = [['overview', 'ภาพรวมและตั้งค่า'], ['rules', 'กฎระเบียบ'], ['qa', 'ตัวอย่าง Q&A'], ['test', 'ทดสอบ'], ['logs', 'ผลจริงและสอนเพิ่ม'], ['data', 'นำเข้า / สำรอง']];
AD.ai = async (tab) => {
  if (SK.user.role !== 'admin') { setPage(await adminShell(empty('lock', 'เฉพาะผู้ดูแลระบบ', 'การเทรน skwc_AI ทำได้เฉพาะแอดมิน (ผอ. ครู และสภานักเรียนเทรนไม่ได้)'), 'ai')); return; }
  const t = AI_TABS.some((x) => x[0] === tab) ? tab : 'overview'; AD.aiTab = t;
  setPage(await adminShell(head('เทรน skwc_AI', 'สอนกฎระเบียบ ตัวอย่างคำตอบ และบุคลิกของ AI — มีเฉพาะแอดมินที่แก้ได้') + `<div class="seg scrollx" role="tablist">${AI_TABS.map(([k, n]) => `<a class="segbtn ${t === k ? 'on' : ''}" href="#/admin/ai/${k}" role="tab">${n}</a>`).join('')}</div><div id="ai-body" class="mt">${loading()}</div>`, 'ai'));
  try { await ({ overview: aiOverview, rules: aiRules, qa: aiQa, test: aiTest, logs: aiLogs, data: aiData })[t](); } catch (e) { if ($('#ai-body')) $('#ai-body').innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; }
};
async function aiOverview() {
  const o = await api('GET', '/admin/ai/overview'), s = o.settings;
  $('#ai-body').innerHTML = `<div class="stats"><div class="stat"><b>${o.rules}</b><span>กฎที่สอนไว้</span></div><div class="stat"><b>${o.qa}</b><span>ตัวอย่าง Q&A</span></div><div class="stat"><b>${o.logs}</b><span>คำถามจากผู้ใช้</span></div><div class="stat ${o.unreviewed_bad + o.unknown ? 'hot' : ''}"><b>${o.unreviewed_bad + o.unknown}</b><span>รอตรวจ/สอนเพิ่ม</span></div></div>
    <div class="alert ${s.mode === 'llm' ? 'ok' : 'warn'} mt">${ic('sparkle')}<span>${s.mode === 'llm' ? `<b>โหมด AI เต็มรูปแบบ</b> — ใช้โมเดล ${esc(s.ai_model)} คิดวิเคราะห์จากกฎที่คุณสอน ตอบได้ว่า "ผิด/ไม่ผิด" พร้อมเหตุผล${s.env_key ? ' (คีย์จากตัวแปรเครื่อง)' : ''}` : '<b>โหมดค้นหากฎ (ออฟไลน์)</b> — ยังไม่ได้ใส่ API key ระบบจะค้นหากฎที่ใกล้เคียงและแสดงให้ ยังตัดสินผิด/ไม่ผิดเองไม่ได้ ใส่คีย์ด้านล่างเพื่อเปิด AI เต็มรูปแบบ'}</span></div>
    <form class="card stack mt" data-form="aiset" style="max-width:760px"><h3>ตั้งค่า</h3>
      <div class="trow"><div><div class="b">เปิดใช้งาน skwc_AI</div><div class="xs mute">ปิดแล้วผู้ใช้ถามไม่ได้</div></div><label class="switch"><input type="checkbox" name="ai_enabled" ${s.ai_enabled ? 'checked' : ''}><i></i></label></div>
      <div class="grid2"><label class="field"><span>ชื่อ AI</span><input class="in" name="ai_name" value="${esc(s.ai_name)}" maxlength="30"></label><label class="field"><span>จำกัดคำถาม/คน/ชั่วโมง</span><input class="in" type="number" name="ai_limit_hour" min="1" max="500" value="${s.ai_limit_hour}"></label></div>
      <label class="field"><span>ข้อความทักทาย</span><textarea class="in" name="ai_greeting" maxlength="400">${esc(s.ai_greeting)}</textarea></label>
      <label class="field"><span>บุคลิกและแนวทางการตอบ (สอน AI ว่าควรพูดอย่างไร)</span><textarea class="in" name="ai_persona" maxlength="800" style="min-height:110px">${esc(s.ai_persona)}</textarea><small>เช่น "พูดเหมือนรุ่นพี่ใจดี อธิบายเหตุผลทุกครั้ง ถ้ากฎเข้มงวดให้แนะนำให้ปรึกษาครู"</small></label>
      <h3>เชื่อมต่อ AI (ไม่บังคับ)</h3>
      <div class="grid2"><label class="field"><span>โมเดล</span><input class="in" name="ai_model" value="${esc(s.ai_model)}" maxlength="60"><small>claude-haiku-5-5 ถูกและเร็ว · claude-sonnet-5-5 แม่นกว่า</small></label>
        <label class="field"><span>Anthropic API key</span><input class="in" type="password" name="ai_api_key" autocomplete="off" placeholder="${s.key_set ? 'ตั้งไว้แล้ว (••••) พิมพ์ใหม่เพื่อเปลี่ยน' : 'sk-ant-...'}"><small>เก็บในฐานข้อมูลฝั่งเซิร์ฟเวอร์ ไม่ส่งกลับมาที่หน้าเว็บ · หรือตั้งตัวแปรเครื่อง ANTHROPIC_API_KEY แทนได้ (ปลอดภัยกว่า)</small></label></div>
      <div class="row"><button class="btn" type="submit">บันทึก</button>${s.key_set ? '<button type="button" class="btn danger" data-act="aikeyclear">ลบ API key</button>' : ''}</div></form>`;
}
SK.forms.aiset = async (f) => { const e = f.elements; try { await api('PUT', '/admin/ai/settings', { ai_enabled: e.ai_enabled.checked, ai_name: e.ai_name.value, ai_limit_hour: e.ai_limit_hour.value, ai_greeting: e.ai_greeting.value, ai_persona: e.ai_persona.value, ai_model: e.ai_model.value, ai_api_key: e.ai_api_key.value }); SK.site = await api('GET', '/public'); toast('บันทึกแล้ว', 'ok'); AD.ai('overview'); } catch (er) { fail(er); } };
SK.acts.aikeyclear = () => confirmBox('ลบ API key?', 'skwc_AI จะกลับไปโหมดค้นหากฎ', 'ลบ', async () => { await api('PUT', '/admin/ai/settings', { clear_key: true }); AD.ai('overview'); }, true);

/* ---- กฎ ---- */
async function aiRules() {
  const q = AD.aiq || '', l = await api('GET', '/admin/ai/rules?q=' + encodeURIComponent(q));
  $('#ai-body').innerHTML = `<div class="row between"><input class="in" style="max-width:320px" type="search" placeholder="ค้นหากฎ" value="${esc(q)}" data-in="airq" aria-label="ค้นหากฎ"><div class="row"><a class="btn ghost" href="#/admin/ai/data">นำเข้าจากข้อความ</a><button class="btn" data-act="airuleform">${ic('plus')}เพิ่มกฎ</button></div></div>
    <div class="stack mt">${l.length ? l.map((r) => `<div class="card ${r.active ? '' : 'faded'}"><div class="row between"><div><b>${esc(r.title)}</b> <span class="pill ${r.severity === 'prohibit' ? 'bad' : r.severity === 'duty' ? 'warn' : ''}">${SEV_TH[r.severity]}</span>${r.category ? ` <span class="pill">${esc(r.category)}</span>` : ''}${r.active ? '' : ' <span class="pill">ปิดอยู่</span>'}</div><span class="row"><button class="btn ghost sm" data-act="airuleform" data-id="${r.id}">${ic('edit')}</button><button class="btn danger sm" data-act="airuledel" data-id="${r.id}">${ic('trash')}</button></span></div><p class="sm mt" style="white-space:pre-wrap">${esc(r.content)}</p>${r.penalty ? `<p class="xs mute mt">ผลที่ตามมา: ${esc(r.penalty)}</p>` : ''}${r.exceptions ? `<p class="xs mute">ข้อยกเว้น: ${esc(r.exceptions)}</p>` : ''}</div>`).join('') : empty('book', 'ยังไม่มีกฎ', 'กด "เพิ่มกฎ" หรือวางข้อความกฎทั้งฉบับที่แท็บ นำเข้า / สำรอง')}</div>`;
  AD.rules = l;
}
SK.inputs.airq = debounce((el) => { AD.aiq = el.value.trim(); aiRules(); });
SK.acts.airuleform = (el) => { const r = el.dataset.id ? AD.rules.find((x) => String(x.id) === el.dataset.id) : null;
  modal(`<h2>${r ? 'แก้ไขกฎ' : 'เพิ่มกฎ'}</h2><form class="stack" data-form="airule" data-id="${r ? r.id : ''}">
    <label class="field"><span>ชื่อกฎ</span><input class="in" name="title" required maxlength="100" value="${r ? esc(r.title) : ''}" placeholder="เช่น รองเท้านักเรียน"></label>
    <div class="grid2"><label class="field"><span>ประเภท</span><select class="in" name="severity">${Object.entries(SEV_TH).map(([k, v]) => `<option value="${k}" ${r && r.severity === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label><label class="field"><span>หมวด</span><input class="in" name="category" maxlength="40" value="${r ? esc(r.category || '') : ''}" placeholder="การแต่งกาย / ทรงผม / ..."></label></div>
    <label class="field"><span>เนื้อหากฎ (เขียนให้ชัด มีเงื่อนไขครบ)</span><textarea class="in" name="content" required maxlength="3000" style="min-height:120px" placeholder="เช่น ต้องสวมรองเท้าผ้าใบสีขาวหรือสีดำล้วนเท่านั้น ห้ามมีลวดลายหรือสีอื่น">${r ? esc(r.content) : ''}</textarea></label>
    <label class="field"><span>ผลที่ตามมา / บทลงโทษ (ถ้ามี)</span><input class="in" name="penalty" maxlength="400" value="${r ? esc(r.penalty || '') : ''}"></label>
    <label class="field"><span>ข้อยกเว้น (ถ้ามี)</span><input class="in" name="exceptions" maxlength="400" value="${r ? esc(r.exceptions || '') : ''}" placeholder="เช่น วันกีฬาสี หรือมีใบรับรองแพทย์"></label>
    <label class="row sm"><input type="checkbox" name="active" ${!r || r.active ? 'checked' : ''}> <span>ใช้งานกฎนี้</span></label>
    <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn" type="submit">บันทึก</button></div></form>`, true); };
SK.forms.airule = async (f) => { const e = f.elements, id = f.dataset.id, b = { title: e.title.value, severity: e.severity.value, category: e.category.value, content: e.content.value, penalty: e.penalty.value, exceptions: e.exceptions.value, active: e.active.checked }; try { id ? await api('PUT', '/admin/ai/rules/' + id, b) : await api('POST', '/admin/ai/rules', b); closeModal(); toast('บันทึกกฎแล้ว AI ใช้ได้ทันที', 'ok'); aiRules(); } catch (er) { fail(er); } };
SK.acts.airuledel = (el) => confirmBox('ลบกฎนี้?', 'AI จะไม่รู้จักกฎนี้อีก (ถ้าแค่ชั่วคราวให้แก้เป็น "ปิดอยู่")', 'ลบ', async () => { await api('DELETE', '/admin/ai/rules/' + el.dataset.id); aiRules(); }, true);

/* ---- Q&A ---- */
const VERD_OPTS = (cur) => Object.entries(VERD).map(([k, v]) => `<option value="${k}" ${cur === k ? 'selected' : ''}>${v[0]} ${v[1]}</option>`).join('');
async function aiQa() {
  const l = await api('GET', '/admin/ai/qa'); AD.qas = l;
  $('#ai-body').innerHTML = `<div class="row between"><p class="sm mute grow">ตัวอย่างคำถาม-คำตอบที่ "ถูกต้อง" ใช้สอน AI วิธีตัดสิน (AI จะถือเป็นแนวทาง) ยิ่งมีตัวอย่างเคสกำกวมยิ่งแม่น</p><button class="btn" data-act="aiqaform">${ic('plus')}เพิ่มตัวอย่าง</button></div>
    <div class="stack mt">${l.length ? l.map((q) => `<div class="card ${q.active ? '' : 'faded'}"><div class="row between"><div><b>ถาม:</b> ${esc(q.question)}</div><span class="row"><span class="pill ${VERD[q.verdict][2]}">${VERD[q.verdict][0]} ${VERD[q.verdict][1]}</span>${q.source === 'feedback' ? '<span class="pill info">สอนจากผลจริง</span>' : ''}<button class="btn ghost sm" data-act="aiqaform" data-id="${q.id}">${ic('edit')}</button><button class="btn danger sm" data-act="aiqadel" data-id="${q.id}">${ic('trash')}</button></span></div><p class="sm mt" style="white-space:pre-wrap"><b>ตอบ:</b> ${esc(q.answer)}</p></div>`).join('') : empty('chat', 'ยังไม่มีตัวอย่าง', 'เพิ่มเคสที่นักเรียนมักถาม พร้อมคำตอบที่ถูกต้อง')}</div>`;
}
SK.acts.aiqaform = (el) => { const q = el.dataset.id ? AD.qas.find((x) => String(x.id) === el.dataset.id) : (el.dataset.q ? { question: el.dataset.q, answer: '', verdict: 'info' } : null);
  modal(`<h2>${q && q.id ? 'แก้ตัวอย่าง' : 'เพิ่มตัวอย่างคำถาม-คำตอบ'}</h2><form class="stack" data-form="aiqa" data-id="${q && q.id ? q.id : ''}"><label class="field"><span>คำถามของนักเรียน</span><input class="in" name="question" required maxlength="300" value="${q ? esc(q.question) : ''}"></label>
    <label class="field"><span>คำตัดสิน</span><select class="in" name="verdict">${VERD_OPTS(q ? q.verdict : 'info')}</select></label>
    <label class="field"><span>คำตอบที่ถูกต้อง (พร้อมเหตุผล)</span><textarea class="in" name="answer" required maxlength="1500" style="min-height:120px">${q ? esc(q.answer) : ''}</textarea></label>
    <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn" type="submit">บันทึก</button></div></form>`); };
SK.forms.aiqa = async (f) => { const e = f.elements, id = f.dataset.id, b = { question: e.question.value, verdict: e.verdict.value, answer: e.answer.value }; try { id ? await api('PUT', '/admin/ai/qa/' + id, b) : await api('POST', '/admin/ai/qa', b); closeModal(); toast('บันทึกแล้ว', 'ok'); AD.ai(AD.aiTab); } catch (er) { fail(er); } };
SK.acts.aiqadel = (el) => confirmBox('ลบตัวอย่างนี้?', '', 'ลบ', async () => { await api('DELETE', '/admin/ai/qa/' + el.dataset.id); aiQa(); }, true);

/* ---- ทดสอบ ---- */
async function aiTest() {
  $('#ai-body').innerHTML = `<form class="card stack" data-form="aitest" style="max-width:760px"><h3>ลองถามเหมือนนักเรียน</h3><textarea class="in" name="q" maxlength="500" required placeholder="เช่น ผมสีน้ำตาลอ่อนธรรมชาติผิดกฎไหม" style="min-height:90px"></textarea>
    <div class="row"><button class="btn" type="submit" data-m="cur">${ic('sparkle')}ถาม (โหมดปัจจุบัน)</button><button class="btn ghost" type="submit" data-m="local">ถามแบบค้นหากฎ (ออฟไลน์)</button></div><small class="mute">การทดสอบไม่นับเป็นคำถามผู้ใช้ และไม่ถูกจำกัดโควตา</small></form><div id="aires" class="mt"></div>`;
}
SK.forms.aitest = async (f, ev) => {
  const local = ev && ev.submitter && ev.submitter.dataset.m === 'local', box = $('#aires'); box.innerHTML = `<div class="aimsg"><div class="aiorb sm spin2">${ic('sparkle')}</div><div class="aibody"><div class="typing"><i></i><i></i><i></i></div></div></div>`;
  try { const r = await api('POST', '/admin/ai/test', { question: f.elements.q.value, local }); AD.lastTest = { q: f.elements.q.value, r };
    box.innerHTML = `<div class="card flat">${aiBubble(r)}<h4 class="mt2">AI ค้นเจออะไรบ้าง <span class="xs mute">(${r.ms} ms)</span></h4><div class="tbl-wrap mt"><table><thead><tr><th>ประเภท</th><th>รายการ</th><th>คะแนนความคล้าย</th></tr></thead><tbody>${r.retrieved.length ? r.retrieved.map((x) => `<tr><td>${x.type}</td><td>${esc(x.title)}</td><td>${x.score}</td></tr>`).join('') : '<tr><td colspan="3" class="mute">ไม่พบอะไรเลย → ควรเพิ่มกฎ/ตัวอย่างเรื่องนี้</td></tr>'}</tbody></table></div>
      <div class="row mt"><button class="btn" data-act="aitestsave">${ic('check')}คำตอบนี้ผิด/ไม่ดี → สอนคำตอบที่ถูก</button></div></div>`; } catch (e) { box.innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; }
};
SK.acts.aitestsave = () => { AD.qas = []; SK.acts.aiqaform({ dataset: { q: AD.lastTest.q } }); };

/* ---- ผลจริง + สอนเพิ่ม ---- */
AD.logFilter = 'todo';
async function aiLogs() {
  const l = await api('GET', '/admin/ai/logs?filter=' + AD.logFilter + '&q=' + encodeURIComponent(AD.logq || '')); AD.logs = l;
  $('#ai-body').innerHTML = `<div class="row"><div class="chips">${[['todo', 'ต้องตรวจ'], ['bad', '👎 ไม่ถูกใจ'], ['unknown', '❔ ตอบไม่ได้'], ['good', '👍 ถูกใจ'], ['all', 'ทั้งหมด']].map(([k, n]) => `<button class="chip ${AD.logFilter === k ? 'on' : ''}" data-act="ailogf" data-v="${k}">${n}</button>`).join('')}</div><input class="in grow" type="search" placeholder="ค้นคำถาม" value="${esc(AD.logq || '')}" data-in="ailogq" style="max-width:260px"></div>
    <p class="sm mute mt">กด "สอนคำตอบที่ถูก" เพื่อเปลี่ยนเคสที่ AI ตอบพลาดให้เป็นตัวอย่าง — AI จะตอบถูกในครั้งถัดไปทันที ผู้ถามถูกบันทึกชื่อไว้ให้แอดมินเห็น</p>
    <div class="stack mt">${l.length ? l.map((x) => { const v = VERD[x.verdict] || VERD.info; return `<div class="card"><div class="row between"><div><b>${esc(x.question)}</b><div class="xs mute">${esc(x.uname || '-')}${x.ugrade ? ' ม.' + x.ugrade : ''} · ${ago(x.created_at)} · ${x.mode === 'llm' ? 'AI' : 'ค้นหากฎ'}</div></div><span class="row"><span class="pill ${v[2]}">${v[0]} ${v[1]}</span>${x.rating === 1 ? '<span class="pill ok">👍</span>' : x.rating === -1 ? '<span class="pill bad">👎</span>' : ''}${x.reviewed ? '<span class="pill">ตรวจแล้ว</span>' : ''}</span></div>
      <p class="sm mt" style="white-space:pre-wrap">${esc(x.answer || '')}</p>${x.note ? `<p class="xs mute">หมายเหตุผู้ใช้: ${esc(x.note)}</p>` : ''}<div class="row mt"><button class="btn sm" data-act="ailogfix" data-id="${x.id}">${ic('edit')}สอนคำตอบที่ถูก</button>${x.reviewed ? '' : `<button class="btn ghost sm" data-act="ailogdismiss" data-id="${x.id}">ไม่ต้องแก้</button>`}</div></div>`; }).join('') : empty('chat', 'ไม่มีรายการ', 'ยังไม่มีคำถามที่ตรงตัวกรอง')}</div>`;
}
SK.acts.ailogf = (el) => { AD.logFilter = el.dataset.v; aiLogs(); };
SK.inputs.ailogq = debounce((el) => { AD.logq = el.value.trim(); aiLogs(); });
SK.acts.ailogfix = (el) => { const x = AD.logs.find((l) => String(l.id) === el.dataset.id);
  modal(`<h2>สอนคำตอบที่ถูก</h2><div class="alert">${ic('chat')}<span><b>AI เคยตอบ:</b> ${esc(x.answer || '')}</span></div><form class="stack mt" data-form="ailogfix" data-id="${x.id}"><label class="field"><span>คำถาม</span><input class="in" name="question" value="${esc(x.question)}" maxlength="300" required></label><label class="field"><span>คำตัดสินที่ถูก</span><select class="in" name="verdict">${VERD_OPTS(x.verdict)}</select></label><label class="field"><span>คำตอบที่ถูกต้อง</span><textarea class="in" name="answer" required maxlength="1500" style="min-height:120px"></textarea></label><div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn" type="submit">บันทึกเป็นตัวอย่าง</button></div></form>`); };
SK.forms.ailogfix = async (f) => { try { await api('POST', `/admin/ai/logs/${f.dataset.id}/fix`, { question: f.elements.question.value, verdict: f.elements.verdict.value, answer: f.elements.answer.value }); closeModal(); toast('AI เรียนรู้แล้ว ✨', 'ok'); aiLogs(); } catch (e) { fail(e); } };
SK.acts.ailogdismiss = async (el) => { await api('POST', `/admin/ai/logs/${el.dataset.id}/fix`, { dismiss: true }); aiLogs(); };

/* ---- นำเข้า / สำรอง ---- */
async function aiData() {
  const o = await api('GET', '/admin/ai/overview');
  $('#ai-body').innerHTML = `<form class="card stack" data-form="aiimport" style="max-width:820px"><h3>นำเข้ากฎจากข้อความ</h3><p class="sm mute">วางระเบียบโรงเรียนทั้งฉบับ (คัดลอกจากเอกสาร) ระบบแยกเป็นข้อๆ ให้ ${o.settings.mode === 'llm' ? 'และใช้ AI ช่วยจัดหมวด/บทลงโทษ/ข้อยกเว้นได้' : '(ใส่ API key เพื่อให้ AI ช่วยจัดโครงสร้างอัตโนมัติ)'} · ดูตัวอย่างก่อนนำเข้าได้</p>
      <textarea class="in" name="text" required maxlength="20000" style="min-height:200px" placeholder="1. นักเรียนต้องแต่งกายเรียบร้อย...&#10;2. ห้ามนำโทรศัพท์มือถือเข้าห้องเรียน..."></textarea>
      ${o.settings.mode === 'llm' ? '<label class="row sm"><input type="checkbox" name="smart" checked> <span>ใช้ AI ช่วยจัดโครงสร้าง</span></label>' : ''}
      <div class="row"><button class="btn ghost" type="submit" data-m="preview">ดูตัวอย่างก่อน</button><button class="btn" type="submit" data-m="import">นำเข้าเลย</button></div><div id="impprev"></div></form>
    <div class="card stack mt" style="max-width:820px"><h3>สำรอง / กู้คืนข้อมูลที่สอน</h3><p class="sm mute">ดาวน์โหลดกฎ + ตัวอย่าง Q&A ทั้งหมดเป็นไฟล์ JSON เก็บไว้หรือย้ายไปเว็บอื่นได้ (ไม่รวม API key)</p>
      <div class="row"><a class="btn ghost" href="/api/admin/ai/export" download>${ic('upload')}ดาวน์โหลดสำรอง</a><label class="btn ghost">${ic('plus')}กู้คืนจากไฟล์<input type="file" accept="application/json,.json" hidden data-ch="airestore"></label></div></div>`;
}
SK.forms.aiimport = async (f, ev) => {
  const prev = ev && ev.submitter && ev.submitter.dataset.m === 'preview', e = f.elements;
  try { const r = await api('POST', '/admin/ai/import', { text: e.text.value, smart: e.smart ? e.smart.checked : false, preview: prev });
    if (prev) $('#impprev').innerHTML = `<div class="alert ok mt">แยกได้ ${r.rules.length} ข้อ (${r.used === 'ai' ? 'ด้วย AI' : 'ตามเลขข้อ/ย่อหน้า'})</div><div class="stack mt">${r.rules.slice(0, 12).map((x) => `<div class="card flat"><b>${esc(x.title)}</b> <span class="pill ${x.severity === 'prohibit' ? 'bad' : ''}">${SEV_TH[x.severity]}</span><p class="xs mute">${esc(x.content.slice(0, 160))}</p></div>`).join('')}${r.rules.length > 12 ? `<p class="xs mute">…และอีก ${r.rules.length - 12} ข้อ</p>` : ''}</div>`;
    else { toast(`นำเข้า ${r.added} ข้อแล้ว`, 'ok'); location.hash = '#/admin/ai/rules'; } } catch (er) { fail(er); }
};
SK.inputs.airestore = async (el) => { const f = el.files[0]; if (!f) return; try { const d = JSON.parse(await f.text()); const r = await api('POST', '/admin/ai/restore', { rules: d.rules, qa: d.qa, replace: false }); toast(`กู้คืน ${r.rules} กฎ, ${r.qa} ตัวอย่าง`, 'ok'); } catch (e) { fail(e.message ? e : new Error('ไฟล์ไม่ถูกต้อง')); } };

/* ================= รายงานสรุป (พิมพ์ / บันทึกเป็น PDF) ================= */
AD.rdays = 30;
AD.report = async () => {
  const r = await api('GET', '/admin/report?days=' + AD.rdays), dt = new Date().toLocaleDateString('th-TH', { dateStyle: 'long' }), maxS = Math.max(1, ...r.items.series.map((x) => x.n));
  const retRate = r.items.total ? Math.round((r.items.returned / r.items.total) * 100) : 0, good = r.ai.good + r.ai.bad ? Math.round((r.ai.good / (r.ai.good + r.ai.bad)) * 100) : null;
  setPage(await adminShell(`<div class="noprint">${head('รายงานสรุป', 'สถิติการใช้งานระบบ สำหรับแนบรายงานโครงการ', `<select class="in" style="width:auto" data-ch="rdays" aria-label="ช่วงเวลา">${[7, 30, 90, 365].map((d) => `<option value="${d}" ${AD.rdays === d ? 'selected' : ''}>${d} วันล่าสุด</option>`).join('')}</select><button class="btn" data-act="doprint">${ic('printer')}พิมพ์ / บันทึก PDF</button>`)}</div>
    <div class="printhead"><h1>รายงานสรุปการใช้งาน ${esc((SK.site || {}).brand_name || '')}</h1><p>${esc(r.school || '')} · ข้อมูล ${r.days} วันล่าสุด · พิมพ์เมื่อ ${dt}</p></div>
    <div class="stats"><div class="stat"><b>${r.items.total}</b><span>โพสต์ของหาย (พบ ${r.items.found} / ตามหา ${r.items.lost})</span></div><div class="stat"><b>${r.items.returned}</b><span>คืนของสำเร็จ (${retRate}%)</span></div><div class="stat"><b>${r.items.avg_days == null ? '-' : r.items.avg_days}</b><span>เฉลี่ยวันกว่าจะได้คืน</span></div><div class="stat"><b>${r.points.given}</b><span>คะแนนความดีที่มอบ</span></div>
      <div class="stat"><b>${r.tutor.chats}</b><span>การจับคู่ติวเตอร์ (${r.tutor.offers} สอน / ${r.tutor.requests} ขอเรียน)</span></div><div class="stat"><b>${r.tutor.avg_stars == null ? '-' : r.tutor.avg_stars}</b><span>คะแนนรีวิวติวเตอร์ (${r.tutor.reviews} รีวิว)</span></div><div class="stat"><b>${r.news}</b><span>ประกาศ</span></div><div class="stat"><b>${r.suggestions.replied}/${r.suggestions.total}</b><span>ข้อเสนอแนะที่ตอบแล้ว</span></div>
      <div class="stat"><b>${r.ai.questions}</b><span>คำถามถึง AI${good == null ? '' : ` (พอใจ ${good}%)`}</span></div><div class="stat"><b>${r.ai.unknown}</b><span>คำถามที่ AI ยังตอบไม่ได้</span></div></div>
    <div class="grid2 mt2"><div class="card"><h3>โพสต์ของหายรายวัน</h3>${r.items.series.length ? `<div class="bars">${r.items.series.map((x) => `<div class="bar" title="${x.d}: ${x.n}"><i style="height:${Math.max(4, (x.n / maxS) * 100)}%"></i><span>${x.d.slice(8)}</span></div>`).join('')}</div>` : '<p class="mute sm">ไม่มีข้อมูล</p>'}</div>
      <div class="card"><h3>หมวดของหายที่พบบ่อย</h3>${r.items.by_category.length ? r.items.by_category.map((c) => `<div class="trow"><span>${esc(c.c)}</span><b>${c.n}</b></div>`).join('') : '<p class="mute sm">ไม่มีข้อมูล</p>'}</div></div>
    <div class="grid2 mt"><div class="card"><h3>ผู้ใช้ตามยศ</h3>${r.users.map((u) => `<div class="trow"><span>${esc(u.label)}</span><b>${u.n}</b></div>`).join('')}</div>
      <div class="card"><h3>ผู้ช่วยหาของยอดเยี่ยม</h3>${r.points.top.length ? r.points.top.map((u, i) => `<div class="trow"><span>${i + 1}. ${esc(u.name)}${u.grade ? ' ม.' + u.grade : ''}</span><b>+${u.s}</b></div>`).join('') : '<p class="mute sm">ยังไม่มีข้อมูล</p>'}</div></div>`, 'report'));
};
SK.inputs.rdays = (el) => { AD.rdays = +el.value; AD.report(); };
SK.acts.doprint = () => window.print();
