'use strict';
/* skwc_Omni — หลังบ้านแอดมิน */
const AD = (SK.admin = { counts: { pending: 0, anon: 0 } });
const ADMIN_NAV = [['--', '', 'ภาพรวม'], ['dashboard', 'grid', 'ภาพรวมระบบ'], ['report', 'list', 'รายงานสรุป'], ['--', '', 'จัดการ'], ['users', 'users', 'ผู้ใช้และยศ'], ['news', 'megaphone', 'ประกาศ'], ['items', 'tag', 'ของหาย'], ['tutor', 'book', 'ติวเตอร์'], ['--', '', 'ผู้ช่วย AI'], ['ai', 'sparkle', 'เทรน skwc_AI'], ['--', '', 'ความปลอดภัย'], ['anon', 'eyeoff', 'ไม่ระบุตัวตน'], ['chats', 'chat', 'บันทึกแชต'], ['audit', 'list', 'ประวัติระบบ'], ['--', '', 'ตั้งค่า'], ['look', 'palette', 'หน้าตาเว็บ'], ['settings', 'gear', 'ตั้งค่าข้อมูล']];
const ACTION_TH = { login: 'เข้าสู่ระบบ', logout: 'ออกจากระบบ', login_failed: 'เข้าสู่ระบบไม่สำเร็จ', change_password: 'เปลี่ยนรหัสผ่าน', anon_request: 'ขอโหมดไม่ระบุตัวตน', anon_on: 'เปิดโหมดไม่ระบุตัวตน', anon_off: 'ปิดโหมดไม่ระบุตัวตน',
  item_post_found: 'โพสต์พบของ', item_post_lost: 'โพสต์ตามหาของ', item_respond: 'ตอบรับโพสต์ของหาย', item_release: 'ยกเลิกการติดต่อ', item_received: 'ยืนยันได้รับของ', item_close: 'ปิดโพสต์ของหาย', tutor_post_offer: 'ลงประกาศสอน', tutor_post_request: 'ลงประกาศขอเรียน',
  tutor_contact: 'เริ่มแชตติวเตอร์', tutor_close: 'ปิดประกาศติวเตอร์', chat_blocked: 'แชตถูกบล็อก (ข้อมูลส่วนตัว)', admin_view_chat: 'แอดมินเปิดดูบันทึกแชต', admin_item_approve: 'แอดมินอนุมัติคืนของ', admin_item_reject: 'แอดมินปฏิเสธการคืน', admin_points: 'แอดมินปรับคะแนน',
  admin_user_create: 'แอดมินเพิ่มผู้ใช้', admin_user_update: 'แอดมินแก้ไขผู้ใช้', admin_reset_password: 'แอดมินรีเซ็ตรหัสผ่าน', admin_import: 'แอดมินนำเข้า CSV', admin_settings: 'แอดมินแก้ตั้งค่า', admin_anon_approve: 'อนุมัติโหมดไม่ระบุตัวตน', admin_anon_reject: 'ปฏิเสธโหมดไม่ระบุตัวตน', admin_anon_revoke: 'เพิกถอนโหมดไม่ระบุตัวตน',
  announce_create: 'ลงประกาศ', announce_update: 'แก้ไขประกาศ', announce_delete: 'ลบประกาศ', admin_announce_pin: 'ปักหมุดประกาศ', admin_announce_unpin: 'ยกเลิกปักหมุด', admin_announce_hide: 'ซ่อนประกาศ', admin_announce_show: 'แสดงประกาศ', admin_announce_delete: 'แอดมินลบประกาศ', admin_brand: 'เปลี่ยนโลโก้/ภาพหน้าแรก', admin_brand_remove: 'ลบโลโก้/ภาพหน้าแรก',
  event_create: 'เพิ่มกิจกรรมปฏิทิน', event_update: 'แก้กิจกรรมปฏิทิน', event_delete: 'ลบกิจกรรมปฏิทิน', suggest_send: 'ส่งข้อเสนอแนะ', suggest_reply: 'ตอบข้อเสนอแนะ', admin_ai_settings: 'ตั้งค่า skwc_AI', ai_rule_add: 'AI: เพิ่มกฎ', ai_rule_edit: 'AI: แก้กฎ', ai_rule_del: 'AI: ลบกฎ', ai_rule_import: 'AI: นำเข้ากฎ', ai_qa_add: 'AI: เพิ่มตัวอย่าง Q&A', ai_train_from_log: 'AI: สอนจากผลจริง', ai_restore: 'AI: กู้คืนข้อมูลเทรน' };
const actTh = (a) => ACTION_TH[a] || a;

async function adminShell(content, tab) {
  try { const s = await api('GET', '/admin/stats'); AD.counts = { pending: s.items_pending, anon: s.anon_pending }; AD.stats = s; } catch (e) { /* keep */ }
  const nav = ADMIN_NAV.filter(([k]) => !(k === 'ai' && SK.user.role !== 'admin')).map(([k, i, t]) => k === '--' ? `<div class="sb-label">${t}</div>` : `<a href="#/admin/${k}" class="${tab === k ? 'on' : ''}">${ic(i)}<span>${t}</span>${k === 'items' && AD.counts.pending ? `<span class="badge">${AD.counts.pending}</span>` : ''}${k === 'anon' && AD.counts.anon ? `<span class="badge">${AD.counts.anon}</span>` : ''}</a>`).join('');
  return shell(`<div class="adm"><aside class="sidebar" aria-label="เมนูหลังบ้าน">${nav}</aside><section id="adm-body" style="min-width:0">${content}</section></div>`, '#/admin');
}
SK.pages.admin = async (tab, arg) => {
  setPage(shell(loading(), '#/admin'));
  const fn = AD[tab]; if (!fn) { location.hash = '#/admin/dashboard'; return; }
  try { await fn(arg); } catch (e) { if (e.status !== 401) setPage(shell(empty('alert', 'เปิดหน้านี้ไม่ได้', e.message), '#/admin')); }
};
const head = (t, sub, right) => `<div class="page-head"><div><h1>${t}</h1>${sub ? `<p>${sub}</p>` : ''}</div>${right ? `<div class="row">${right}</div>` : ''}</div>`;
const dayShort = (d) => d.slice(8) + '/' + d.slice(5, 7);

/* ---------- dashboard ---------- */
AD.dashboard = async () => {
  const body = await adminShell(loading(), 'dashboard'); setPage(body);
  const s = AD.stats, max = Math.max(1, ...s.days.map((d) => Math.max(d.items, d.msgs, d.tutor)));
  $('#adm-body').innerHTML = head('ภาพรวมระบบ', 'สรุปการใช้งานทั้งโรงเรียน') + `
    ${s.items_pending || s.anon_pending ? `<div class="alert warn" style="margin-bottom:1rem">${ic('alert')}<span>มีงานรอตรวจ: <a class="b" href="#/admin/items">คืนของรอยืนยัน ${s.items_pending}</a> · <a class="b" href="#/admin/anon">คำขอไม่ระบุตัวตน ${s.anon_pending}</a></span></div>` : ''}
    <div class="stats">
      <div class="stat"><b>${s.users_active}</b><span>ผู้ใช้ที่ใช้งานได้ / ทั้งหมด ${s.users}</span></div>
      <div class="stat"><b>${s.news}</b><span>ประกาศที่เผยแพร่อยู่</span></div>
      <div class="stat"><b>${s.items_total}</b><span>โพสต์ของหายทั้งหมด</span></div>
      <div class="stat"><b>${s.items_returned}</b><span>คืนสำเร็จ</span></div>
      <div class="stat ${s.items_pending ? 'hot' : ''}"><b>${s.items_pending}</b><span>รอแอดมินยืนยัน</span></div>
      <div class="stat"><b>${s.tutor_open}</b><span>ประกาศติวเตอร์ที่เปิดอยู่</span></div>
      <div class="stat"><b>${s.convs}</b><span>การสนทนาทั้งหมด</span></div>
      <div class="stat ${s.blocked ? 'hot' : ''}"><b>${s.blocked}</b><span>ข้อความที่ถูกบล็อก</span></div>
      <div class="stat"><b>${s.points_total}</b><span>คะแนนความดีที่แจกแล้ว</span></div></div>
    <div class="card mt2"><div class="row between"><h3>กิจกรรม 14 วันล่าสุด</h3><div class="row xs mute"><span><i style="display:inline-block;width:10px;height:10px;background:var(--rose);border-radius:3px"></i> โพสต์ของหาย</span><span><i style="display:inline-block;width:10px;height:10px;background:var(--berry);border-radius:3px"></i> ข้อความแชต</span></div></div>
      <div class="bars" role="img" aria-label="กราฟกิจกรรมรายวัน">${s.days.map((d) => `<div class="bar" title="${d.d}: ของหาย ${d.items}, แชต ${d.msgs}, ติวเตอร์ ${d.tutor}"><i style="height:${(d.items / max) * 100}%"></i><i class="b2" style="height:${(d.msgs / max) * 100}%"></i><span>${dayShort(d.d)}</span></div>`).join('')}</div></div>`;
};

/* ---------- users ---------- */
AD.state = { q: '', grade: '', role: '' };
const ROLE_LIST = ['student', 'council', 'teacher', 'director', 'admin'];
const roleName = (r) => (SK.site && SK.site.roles && SK.site.roles[r]) || r;
AD.users = async () => {
  setPage(await adminShell(head('จัดการผู้ใช้', 'เลขประจำตัว = ชื่อผู้ใช้ · รหัสผ่านเริ่มต้น = เลขบัตรประชาชน (เก็บแบบเข้ารหัสทางเดียว ไม่สามารถดูย้อนหลังได้)', `<button class="btn ghost" data-act="uimport">นำเข้า CSV</button><button class="btn" data-act="uadd">${ic('plus')}เพิ่มผู้ใช้</button>`) +
    `<div class="row" style="margin-bottom:1rem"><input class="in grow" type="search" placeholder="ค้นหาเลขประจำตัวหรือชื่อ" value="${esc(AD.state.q)}" data-in="aq" aria-label="ค้นหาผู้ใช้"><select class="in" style="width:auto" data-ch="agrade" aria-label="ชั้น">${opts(['1', '2', '3', '4', '5', '6'].map((g) => g), AD.state.grade, 'ทุกชั้น')}</select>
    <select class="in" style="width:auto" data-ch="arole" aria-label="ยศ"><option value="">ทุกยศ</option>${ROLE_LIST.map((r) => `<option value="${r}" ${AD.state.role === r ? 'selected' : ''}>${esc(roleName(r))}</option>`).join('')}</select></div><div id="ulist">${loading()}</div>`, 'users'));
  loadUsers();
};
async function loadUsers() {
  const p = new URLSearchParams(); if (AD.state.q) p.set('q', AD.state.q); if (AD.state.grade) p.set('grade', AD.state.grade); if (AD.state.role) p.set('role', AD.state.role); const box = $('#ulist'); if (!box) return;
  const l = await api('GET', '/admin/users?' + p); AD.list = l;
  box.innerHTML = l.length ? `<div class="tbl-wrap"><table><thead><tr><th>เลขประจำตัว</th><th>ชื่อ</th><th>ชั้น</th><th>สถานะ</th><th>คะแนน</th><th>ไม่ระบุตัวตน</th><th></th></tr></thead><tbody>${l.map((u) => `<tr><td>${esc(u.student_id)}</td><td>${esc(u.name)}${roleBadge(u)}</td><td>${u.grade ? 'ม.' + u.grade + '/' + esc(u.room || '') : '-'}</td>
    <td>${u.active ? '<span class="pill ok">ใช้งานได้</span>' : '<span class="pill bad">ระงับ</span>'}</td><td>${u.points}</td><td>${{ none: '-', pending: '<span class="pill warn">รออนุมัติ</span>', approved: u.anon_enabled ? '<span class="pill info">เปิดอยู่</span>' : '<span class="pill">อนุมัติแล้ว</span>', rejected: '<span class="pill bad">ปฏิเสธ</span>' }[u.anon_status]}</td>
    <td style="white-space:nowrap">${u.role === 'admin' && SK.user.role !== 'admin' ? '<span class="xs mute">แก้ได้เฉพาะผู้ดูแล</span>' : `<button class="btn sm ghost" data-act="uedit" data-id="${u.id}">แก้ไข</button> <button class="btn sm ghost" data-act="upw" data-id="${u.id}">รีเซ็ตรหัส</button>`}</td></tr>`).join('')}</tbody></table></div>` : empty('users', 'ไม่พบผู้ใช้');
}
AD.inputs = {};
SK.inputs.aq = debounce((el) => { AD.state.q = el.value.trim(); loadUsers(); });
SK.inputs.agrade = (el) => { AD.state.grade = el.value; loadUsers(); };
SK.inputs.arole = (el) => { AD.state.role = el.value; loadUsers(); };
const userForm = (u) => `<form data-form="usave" data-id="${u ? u.id : ''}" class="stack"><h2>${u ? 'แก้ไขผู้ใช้' : 'เพิ่มผู้ใช้'}</h2>
  <div class="grid2"><label class="field"><span>เลขประจำตัว</span><input class="in" name="student_id" value="${u ? esc(u.student_id) : ''}" ${u ? 'disabled' : 'required'}></label><label class="field"><span>ชื่อ-สกุล</span><input class="in" name="name" value="${u ? esc(u.name) : ''}" required></label></div>
  <div class="grid3"><label class="field"><span>ชั้น (1-6)</span><input class="in" name="grade" type="number" min="1" max="6" value="${u && u.grade ? u.grade : ''}"></label><label class="field"><span>ห้อง</span><input class="in" name="room" value="${u ? esc(u.room || '') : ''}"></label>
    <label class="field"><span>ยศ</span><select class="in" name="role" ${u && ['admin', 'director'].includes(u.role) && SK.user.role !== 'admin' ? 'disabled' : ''}>${ROLE_LIST.filter((r) => SK.user.role === 'admin' || !['admin', 'director'].includes(r) || (u && u.role === r)).map((r) => `<option value="${r}" ${(u ? u.role : 'student') === r ? 'selected' : ''}>${esc(roleName(r))}</option>`).join('')}</select><small>สภานักเรียนขึ้นไปลงประกาศได้ · เข้าหลังบ้านได้เฉพาะผู้ดูแลและ ผอ.</small></label></div>
  ${u ? `<label class="row"><input type="checkbox" name="active" ${u.active ? 'checked' : ''}> <span>เปิดใช้งานบัญชีนี้</span></label>` : `<label class="field"><span>รหัสผ่านเริ่มต้น (เลขบัตรประชาชน)</span><input class="in" name="password" inputmode="numeric" required minlength="6"></label>`}
  <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn" type="submit">บันทึก</button></div></form>`;
SK.acts.uadd = () => modal(userForm(null), true);
SK.acts.uedit = (el) => modal(userForm(AD.list.find((u) => String(u.id) === el.dataset.id)), true);
SK.forms.usave = async (f) => {
  try {
    if (f.dataset.id) await api('PUT', '/admin/users/' + f.dataset.id, { name: f.elements.name.value, grade: f.elements.grade.value, room: f.elements.room.value, role: f.elements.role.value, active: f.elements.active.checked });
    else await api('POST', '/admin/users', { student_id: f.elements.student_id.value, name: f.elements.name.value, grade: f.elements.grade.value, room: f.elements.room.value, role: f.elements.role.value, password: f.elements.password.value });
    closeModal(); toast('บันทึกแล้ว', 'ok'); loadUsers();
  } catch (e) { fail(e); }
};
SK.acts.upw = (el) => { const u = AD.list.find((x) => String(x.id) === el.dataset.id);
  modal(`<form data-form="upw" data-id="${u.id}" class="stack"><h2>รีเซ็ตรหัสผ่าน</h2><p class="mute sm">${esc(u.name)} (${esc(u.student_id)}) — ผู้ใช้จะถูกออกจากระบบทุกอุปกรณ์</p><label class="field"><span>รหัสผ่านใหม่</span><input class="in" name="password" required minlength="6" inputmode="numeric" placeholder="เลขบัตรประชาชน 13 หลัก"></label>
  <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn" type="submit">รีเซ็ต</button></div></form>`); };
SK.forms.upw = async (f) => { try { await api('POST', `/admin/users/${f.dataset.id}/reset-password`, { password: f.elements.password.value }); closeModal(); toast('รีเซ็ตรหัสผ่านแล้ว', 'ok'); } catch (e) { fail(e); } };
SK.acts.uimport = () => modal(`<form data-form="uimport" class="stack"><h2>นำเข้ารายชื่อนักเรียน (CSV)</h2><p class="sm mute">วางข้อมูลทีละบรรทัด รูปแบบ: <b>เลขประจำตัว,เลขบัตรประชาชน,ชื่อ-สกุล,ชั้น,ห้อง,ยศ(ไม่บังคับ: student / council / teacher)</b><br>ถ้าเลขประจำตัวซ้ำ ระบบจะอัปเดตชื่อ/ชั้น/ห้อง และตั้งรหัสผ่านใหม่ตามเลขบัตร</p>
  <textarea class="in" name="csv" style="min-height:200px;font-family:monospace" placeholder="10001,1100900000000,ณัฐธิดา ใจดี,6,1" required></textarea>
  <label class="field"><span>หรือเลือกไฟล์ .csv</span><input type="file" accept=".csv,text/csv,text/plain" data-ch="csvfile"></label><div id="imp-res"></div>
  <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ปิด</button><button class="btn" type="submit">นำเข้า</button></div></form>`, true);
SK.inputs.csvfile = async (el) => { const f = el.files[0]; if (f) $('textarea[name=csv]').value = await f.text(); };
SK.forms.uimport = async (f) => {
  const btn = $('button[type=submit]', f); btn.disabled = true; btn.textContent = 'กำลังนำเข้า...';
  try { const r = await api('POST', '/admin/users/import', { csv: f.elements.csv.value }); $('#imp-res').innerHTML = `<div class="alert ${r.errors.length ? 'warn' : 'ok'}">${ic('check')}<span>สร้างใหม่ ${r.created} · อัปเดต ${r.updated}${r.errors.length ? '<br>' + r.errors.map(esc).join('<br>') : ''}</span></div>`; loadUsers(); } catch (e) { fail(e); }
  btn.disabled = false; btn.textContent = 'นำเข้า';
};

/* ---------- ประกาศ (หลังบ้าน) ---------- */
AD.news = async () => {
  const l = await api('GET', '/announcements?all=1');
  setPage(await adminShell(head('จัดการประกาศ', 'ปักหมุด ซ่อน หรือลบประกาศของทุกคนได้ (สภานักเรียนและครูลงประกาศได้เองจากหน้าเว็บ)', `<a class="btn" href="#/news/new">${ic('plus')}ลงประกาศ</a>`) +
    (l.length ? `<div class="tbl-wrap"><table><thead><tr><th>หัวข้อ</th><th>ผู้ประกาศ</th><th>ระดับ</th><th>สถานะ</th><th></th></tr></thead><tbody>${l.map((a) => `<tr><td style="max-width:300px"><a class="b" href="#/news/${a.id}">${esc(a.title)}</a><div class="xs mute">${ago(a.created_at)}${a.photo ? ' · มีรูป' : ''}</div></td><td>${esc(a.author.name)}${roleBadge(a.author)}</td>
      <td>${a.level === 'normal' ? '-' : lvPill(a.level)}</td><td>${a.status === 'hidden' ? '<span class="pill bad">ซ่อน</span>' : '<span class="pill ok">เผยแพร่</span>'}${a.pinned ? ` <span class="pill">${ic('pin')}ปักหมุด</span>` : ''}</td>
      <td style="white-space:nowrap"><button class="btn sm ghost" data-act="ann" data-a="${a.pinned ? 'unpin' : 'pin'}" data-id="${a.id}">${a.pinned ? 'เลิกปักหมุด' : 'ปักหมุด'}</button> <button class="btn sm ghost" data-act="ann" data-a="${a.status === 'hidden' ? 'show' : 'hide'}" data-id="${a.id}">${a.status === 'hidden' ? 'แสดง' : 'ซ่อน'}</button> <button class="btn sm danger" data-act="anndel" data-id="${a.id}">ลบ</button></td></tr>`).join('')}</tbody></table></div>` : empty('megaphone', 'ยังไม่มีประกาศ')), 'news'));
};
SK.acts.ann = async (el) => { try { await api('POST', '/admin/announcements/' + el.dataset.id, { action: el.dataset.a }); AD.news(); } catch (e) { fail(e); } };
SK.acts.anndel = (el) => confirmBox('ลบประกาศนี้?', 'ลบแล้วกู้คืนไม่ได้ (ถ้าแค่ไม่อยากให้แสดง ใช้ "ซ่อน")', 'ลบ', async () => { await api('POST', '/admin/announcements/' + el.dataset.id, { action: 'delete' }); AD.news(); }, true);

/* ---------- หน้าตาเว็บ: ปรับแต่งได้อิสระโดยไม่ต้องแก้ไฟล์ ---------- */
const PRESETS = ['#FF99FF', '#FF7EB6', '#C58CFF', '#8FB8FF', '#7ED7C1', '#FFC46B', '#FF9A8B', '#B5E36B'];
AD.look = async () => {
  const [s, site] = await Promise.all([api('GET', '/admin/settings'), api('GET', '/public')]); SK.site = site; applySite();
  const tg = (name, on, label, hint) => `<div class="trow"><div><div class="b">${label}</div>${hint ? `<div class="xs mute">${hint}</div>` : ''}</div><label class="switch"><input type="checkbox" name="${name}" ${on ? 'checked' : ''} aria-label="${label}"><i></i></label></div>`;
  const imgBox = (kind, src, label, hint) => `<div class="field"><span>${label}</span><div class="row"><div class="imgfit" style="width:110px;height:76px;border-radius:12px;border:1px solid var(--line);${src ? `--bg:url('${esc(src)}')` : ''}">${src ? `<img src="${esc(src)}" alt="">` : ic('image')}</div>
    <label class="btn ghost sm">${ic('upload')}เลือกรูป<input type="file" accept="image/png,image/jpeg,image/webp" hidden data-ch="brandup" data-kind="${kind}"></label>${src ? `<button type="button" class="btn danger sm" data-act="brandrm" data-kind="${kind}">ลบรูป</button>` : ''}</div>${hint ? `<small>${hint}</small>` : ''}</div>`;
  setPage(await adminShell(head('หน้าตาเว็บ', 'ปรับสี โลโก้ ข้อความ ยศ และเปิด/ปิดฟีเจอร์ได้ทันที ไม่ต้องแก้ไฟล์ — กด "บันทึก" แล้วทุกคนเห็นผลเลย') + `
    <form data-form="look" class="stack" style="max-width:820px">
      <div class="card stack"><h3>${ic('palette')} สีหลักของเว็บ</h3>
        <div class="row"><input type="color" class="in" style="width:70px" name="color_pick" value="${esc(s.theme_color)}" data-in="colorpick" aria-label="เลือกสี"><input class="in" style="width:130px;font-family:monospace" name="theme_color" value="${esc(s.theme_color)}" maxlength="7" data-in="colortext" aria-label="รหัสสี hex"><button type="button" class="btn ghost sm" data-act="colorreset">รีเซ็ตเป็น #FF99FF</button></div>
        <div class="swatches" aria-label="สีแนะนำ">${PRESETS.map((c) => `<button type="button" class="sw" style="background:${c}" data-act="colorset" data-c="${c}" title="${c}" aria-label="${c}"></button>`).join('')}</div>
        <small class="mute">ระบบสร้างโทนสีเข้ม/อ่อนทั้งหมดจากสีนี้ให้อัตโนมัติ เห็นตัวอย่างสดทันทีที่เลือก (ยังไม่บันทึกจนกว่าจะกดปุ่มด้านล่าง)</small></div>
      <div class="card stack"><h3>แบรนด์และหน้าเข้าสู่ระบบ</h3>
        <div class="grid2"><label class="field"><span>ชื่อเว็บ</span><input class="in" name="brand_name" value="${esc(s.brand_name)}" maxlength="40"></label><label class="field"><span>ชื่อโรงเรียน</span><input class="in" name="school_name" value="${esc(s.school_name)}" maxlength="80"></label></div>
        ${imgBox('logo', site.logo, 'โลโก้โรงเรียน', 'แนะนำ PNG พื้นโปร่งใส สี่เหลี่ยมจัตุรัส — แสดงที่แถบบนและหน้าเข้าสู่ระบบ')}
        <label class="field"><span>หัวข้อหน้าเข้าสู่ระบบ</span><input class="in" name="login_title" value="${esc(s.login_title)}" maxlength="60"></label>
        <label class="field"><span>ข้อความต้อนรับหน้าเข้าสู่ระบบ</span><textarea class="in" name="login_text" maxlength="400">${esc(s.login_text)}</textarea></label></div>
      <div class="card stack"><h3>หน้าแรก</h3>
        <label class="field"><span>ข้อความทักทาย</span><input class="in" name="hero_title" value="${esc(s.hero_title)}" maxlength="80"><small>ใช้ {name} แทนชื่อผู้ใช้ เช่น "สวัสดี {name} 👋"</small></label>
        <label class="field"><span>ข้อความใต้ทักทาย (เว้นว่าง = ระบบเขียนให้อัตโนมัติ)</span><textarea class="in" name="hero_text" maxlength="300">${esc(s.hero_text)}</textarea></label>
        ${imgBox('hero_image', site.hero_image, 'ภาพพื้นหลังหน้าแรก (ไม่บังคับ)', 'ใช้ภาพกว้างๆ เช่น ภาพโรงเรียน ระบบจะทับสีเข้มให้ตัวหนังสืออ่านง่าย')}
        ${tg('ticker_on', s.ticker_on === '1', 'แถบข้อความวิ่งด้านบนสุด', 'ใช้ประกาศด่วน/ข่าวสั้นๆ ให้เห็นทุกหน้า')}
        <label class="field"><span>ข้อความในแถบวิ่ง</span><input class="in" name="ticker_text" value="${esc(s.ticker_text)}" maxlength="200"></label>
        <label class="field"><span>ข้อความท้ายหน้า</span><input class="in" name="footer_text" value="${esc(s.footer_text)}" maxlength="160" placeholder="เช่น © 2569 โรงเรียน... · จัดทำโดยชมรมคอมพิวเตอร์"></label></div>
      <div class="card stack"><h3>ลักษณะและแอนิเมชัน</h3><div class="grid2">
        <label class="field"><span>ระดับแอนิเมชัน</span><select class="in" name="anim_level">${[['full', 'เต็ม (เอฟเฟกต์ลอย เปล่งประกาย)'], ['light', 'เบา (เฉพาะตอนโฮเวอร์/เปลี่ยนหน้า)'], ['off', 'ปิดทั้งหมด']].map(([v, t]) => `<option value="${v}" ${s.anim_level === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <label class="field"><span>ความโค้งของการ์ด</span><select class="in" name="radius">${[['round', 'โค้งมาก'], ['soft', 'โค้งปานกลาง'], ['sharp', 'เหลี่ยมมน']].map(([v, t]) => `<option value="${v}" ${s.radius === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label></div></div>
      <div class="card"><h3>เปิด/ปิดฟีเจอร์</h3>${tg('feature_items', s.feature_items !== '0', 'บอร์ดของหาย')}${tg('feature_tutor', s.feature_tutor !== '0', 'จับคู่ติวเตอร์')}${tg('feature_leaderboard', s.feature_leaderboard !== '0', 'อันดับคะแนนความดี')}${tg('feature_ai', s.feature_ai !== '0', 'ผู้ช่วย AI (skwc_AI)')}${tg('feature_calendar', s.feature_calendar !== '0', 'ปฏิทินโรงเรียน')}${tg('feature_suggest', s.feature_suggest !== '0', 'กล่องข้อเสนอแนะ')}</div>
      <div class="card stack"><h3>ชื่อยศที่แสดงในเว็บ</h3><p class="sm mute">ยศ = สิทธิ์การใช้งาน: สภานักเรียนขึ้นไปลงประกาศได้ · ครูปักหมุดได้ · เฉพาะผู้ดูแลและ ผอ. เข้าหลังบ้านได้</p>
        <div class="grid3">${ROLE_LIST.map((r) => `<label class="field"><span>${{ student: 'นักเรียน', council: 'สภานักเรียน', teacher: 'ครู', director: 'ผอ.', admin: 'ผู้ดูแล' }[r]}</span><input class="in" name="label_${r}" value="${esc(s['label_' + r])}" maxlength="30"></label>`).join('')}</div></div>
      <div class="row" style="position:sticky;bottom:1rem"><button class="btn" type="submit">${ic('check')}บันทึกและใช้ทันที</button><a class="btn ghost" href="#/home">ดูหน้าแรก</a></div>
    </form>`, 'look'));
};
const setColor = (c) => { const f = $('form[data-form=look]'); f.elements.theme_color.value = c; f.elements.color_pick.value = c; reloadTheme(c); };
SK.acts.colorset = (el) => setColor(el.dataset.c);
SK.acts.colorreset = () => setColor('#FF99FF');
SK.inputs.colorpick = (el) => setColor(el.value.toUpperCase());
SK.inputs.colortext = (el) => { if (/^#[0-9a-fA-F]{6}$/.test(el.value)) setColor(el.value.toUpperCase()); };
SK.inputs.brandup = async (el) => {
  const f = el.files[0]; if (!f) return;
  try { const d = await resizeImage(f, el.dataset.kind === 'logo' ? 512 : 1600, el.dataset.kind === 'logo' ? 'image/png' : 'image/jpeg'); SK.site = await api('POST', '/admin/brand/' + el.dataset.kind, { photo: d }); applySite(); toast('อัปโหลดแล้ว', 'ok'); AD.look(); } catch (e) { fail(e); }
};
SK.acts.brandrm = async (el) => { try { SK.site = await api('DELETE', '/admin/brand/' + el.dataset.kind); applySite(); AD.look(); } catch (e) { fail(e); } };
SK.forms.look = async (f) => {
  const e = f.elements, v = (n) => e[n].value;
  const d = { theme_color: v('theme_color'), brand_name: v('brand_name'), school_name: v('school_name'), login_title: v('login_title'), login_text: v('login_text'), hero_title: v('hero_title'), hero_text: v('hero_text'), ticker_text: v('ticker_text'), footer_text: v('footer_text'), anim_level: v('anim_level'), radius: v('radius'),
    ticker_on: e.ticker_on.checked ? '1' : '0', feature_items: e.feature_items.checked ? '1' : '0', feature_tutor: e.feature_tutor.checked ? '1' : '0', feature_leaderboard: e.feature_leaderboard.checked ? '1' : '0', feature_ai: e.feature_ai.checked ? '1' : '0', feature_calendar: e.feature_calendar.checked ? '1' : '0', feature_suggest: e.feature_suggest.checked ? '1' : '0' };
  ROLE_LIST.forEach((r) => { d['label_' + r] = v('label_' + r); });
  try { await api('PUT', '/admin/settings', d); SK.site = await api('GET', '/public'); SK.meta = await api('GET', '/meta'); applySite(); reloadTheme(); toast('บันทึกแล้ว ทุกคนเห็นหน้าตาใหม่ทันที', 'ok'); }
  catch (er) { fail(er); }
};

/* ---------- anonymity ---------- */
AD.anon = async () => {
  const l = await api('GET', '/admin/anon');
  setPage(await adminShell(head('คำขอโหมดไม่ระบุตัวตน', 'อนุมัติแล้ว ผู้ใช้จะเปิด/ปิดโหมดได้เอง ส่วนแอดมินยังเห็นชื่อจริงทุกครั้งในหลังบ้าน') + (l.length ? `<div class="tbl-wrap"><table><thead><tr><th>ผู้ใช้ (ชื่อจริง)</th><th>ชั้น</th><th>เหตุผล</th><th>สถานะ</th><th></th></tr></thead><tbody>${l.map((u) => `<tr><td><b>${esc(u.name)}</b><div class="xs mute">${esc(u.student_id)}</div></td><td>${u.grade ? 'ม.' + u.grade + '/' + esc(u.room || '') : '-'}</td><td style="max-width:280px">${esc(u.anon_note || '-')}</td>
    <td>${{ pending: '<span class="pill warn">รออนุมัติ</span>', approved: u.anon_enabled ? '<span class="pill info">อนุมัติ · เปิดอยู่</span>' : '<span class="pill ok">อนุมัติแล้ว</span>', rejected: '<span class="pill bad">ปฏิเสธ</span>' }[u.anon_status] || ''}</td>
    <td style="white-space:nowrap">${u.anon_status === 'pending' ? `<button class="btn sm ok" data-act="anondec" data-d="approve" data-id="${u.id}">อนุมัติ</button> <button class="btn sm danger" data-act="anondec" data-d="reject" data-id="${u.id}">ปฏิเสธ</button>` : u.anon_status === 'approved' ? `<button class="btn sm danger" data-act="anondec" data-d="revoke" data-id="${u.id}">เพิกถอน</button>` : `<button class="btn sm ghost" data-act="anondec" data-d="approve" data-id="${u.id}">อนุมัติใหม่</button>`}</td></tr>`).join('')}</tbody></table></div>` : empty('eyeoff', 'ยังไม่มีคำขอ')), 'anon'));
};
SK.acts.anondec = async (el) => { try { await api('POST', '/admin/anon/' + el.dataset.id, { decision: el.dataset.d }); toast('ดำเนินการแล้ว', 'ok'); AD.anon(); } catch (e) { fail(e); } };

/* ---------- items ---------- */
AD.istatus = '';
const ST_TH = { open: 'เปิดอยู่', claimed: 'กำลังติดต่อ', pending_admin: 'รอแอดมินยืนยัน', returned: 'คืนแล้ว', closed: 'ผู้โพสต์ปิด', hidden: 'ซ่อน' };
AD.items = async () => {
  const l = await api('GET', '/admin/items' + (AD.istatus ? '?status=' + AD.istatus : ''));
  const tabs = [['', 'ทั้งหมด'], ['pending_admin', 'รอยืนยัน'], ['claimed', 'กำลังติดต่อ'], ['open', 'เปิดอยู่'], ['returned', 'คืนแล้ว'], ['hidden', 'ซ่อน']];
  setPage(await adminShell(head('จัดการของหาย', 'ตรวจสอบการคืนของและให้คะแนนความดีแก่ผู้ช่วยหาของ') + `<div class="chips" style="margin-bottom:1rem">${tabs.map(([v, t]) => `<button class="chip ${AD.istatus === v ? 'on' : ''}" data-act="istab" data-v="${v}">${t}</button>`).join('')}</div>` +
    (l.length ? `<div class="tbl-wrap"><table><thead><tr><th>รายการ</th><th>ผู้โพสต์</th><th>ผู้ติดต่อ</th><th>สถานะ</th><th></th></tr></thead><tbody>${l.map((i) => `<tr><td><a class="b" href="#/item/${i.id}">${esc(tagNo(i.id))} ${esc(i.title)}</a><div class="xs mute">${i.kind === 'found' ? 'พบของ' : 'ตามหา'} · ${esc(i.location || '-')} · ${ago(i.created_at)}</div></td>
      <td>${esc(i.poster)}${i.anon ? ' <span class="pill info">ไม่ระบุตัวตน</span>' : ''}</td><td>${i.responder ? esc(i.responder) : '-'}</td><td><span class="pill ${i.status === 'returned' ? 'ok' : i.status === 'pending_admin' ? 'warn' : ''}">${ST_TH[i.status]}</span>${i.points_awarded ? `<div class="xs mute">+${i.points_awarded} คะแนน</div>` : ''}</td>
      <td style="white-space:nowrap">${['pending_admin', 'claimed'].includes(i.status) ? `<button class="btn sm ok" data-act="iapprove" data-id="${i.id}" data-finder="${esc(i.finder || '')}">ยืนยันคืน + ให้คะแนน</button> <button class="btn sm ghost" data-act="ireject" data-id="${i.id}">ปฏิเสธ</button>` : ''}
      ${i.status !== 'hidden' ? `<button class="btn sm danger" data-act="ihide" data-id="${i.id}">ซ่อน</button>` : `<button class="btn sm ghost" data-act="iunhide" data-id="${i.id}">เปิดแสดง</button>`}</td></tr>`).join('')}</tbody></table></div>` : empty('tag', 'ไม่มีรายการ')), 'items'));
};
SK.acts.istab = (el) => { AD.istatus = el.dataset.v; AD.items(); };
SK.acts.iapprove = (el) => { modal(`<form data-form="iapprove" data-id="${el.dataset.id}" class="stack"><h2>ยืนยันการคืนของ</h2><p class="mute">ให้คะแนนความดีแก่ผู้ช่วยหาของ: <b>${esc(el.dataset.finder || '-')}</b></p><label class="field"><span>จำนวนคะแนน</span><input class="in" type="number" name="points" min="0" max="1000" value="${SK.meta.points_return}"></label>
  <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="close">ยกเลิก</button><button class="btn ok" type="submit">ยืนยัน</button></div></form>`); };
SK.forms.iapprove = async (f) => { try { await api('POST', `/admin/items/${f.dataset.id}/approve`, { points: +f.elements.points.value }); closeModal(); toast('ยืนยันแล้ว ให้คะแนนเรียบร้อย', 'ok'); await refreshMe(); AD.items(); } catch (e) { fail(e); } };
SK.acts.ireject = (el) => confirmBox('ปฏิเสธการคืน?', 'โพสต์จะกลับไปเปิดรับใหม่ และไม่ให้คะแนน', 'ปฏิเสธ', async () => { await api('POST', `/admin/items/${el.dataset.id}/reject`); AD.items(); }, true);
SK.acts.ihide = (el) => confirmBox('ซ่อนโพสต์นี้?', 'โพสต์จะไม่แสดงต่อนักเรียน (กู้คืนได้)', 'ซ่อน', async () => { await api('POST', `/admin/items/${el.dataset.id}/status`, { status: 'hidden' }); AD.items(); }, true);
SK.acts.iunhide = async (el) => { try { await api('POST', `/admin/items/${el.dataset.id}/status`, { status: 'open' }); AD.items(); } catch (e) { fail(e); } };

/* ---------- tutor ---------- */
AD.tutor = async () => {
  const l = await api('GET', '/admin/tutor');
  setPage(await adminShell(head('จัดการประกาศติวเตอร์') + (l.length ? `<div class="tbl-wrap"><table><thead><tr><th>ประเภท</th><th>ชั้น/วิชา</th><th>รายละเอียด</th><th>ผู้โพสต์</th><th>สถานะ</th><th></th></tr></thead><tbody>${l.map((t) => `<tr><td>${t.kind === 'offer' ? 'สอน' : 'ขอเรียน'}</td><td>ม.${t.grade} ${esc(t.subject)}</td><td style="max-width:260px">${esc(t.topic)}</td><td>${esc(t.poster)}${t.anon ? ' <span class="pill info">ไม่ระบุตัวตน</span>' : ''}</td><td>${{ open: '<span class="pill ok">เปิด</span>', closed: '<span class="pill">ปิด</span>', hidden: '<span class="pill bad">ซ่อน</span>' }[t.status]}</td>
    <td>${t.status === 'hidden' ? `<button class="btn sm ghost" data-act="tstatus" data-s="open" data-id="${t.id}">เปิดแสดง</button>` : `<button class="btn sm danger" data-act="tstatus" data-s="hidden" data-id="${t.id}">ซ่อน</button>`}</td></tr>`).join('')}</tbody></table></div>` : empty('book', 'ยังไม่มีประกาศ')), 'tutor'));
};
SK.acts.tstatus = async (el) => { try { await api('POST', `/admin/tutor/${el.dataset.id}/status`, { status: el.dataset.s }); AD.tutor(); } catch (e) { fail(e); } };

/* ---------- chat logs ---------- */
AD.cstate = { flagged: false, q: '' };
AD.chats = async (id) => {
  const p = new URLSearchParams(); if (AD.cstate.flagged) p.set('flagged', '1'); if (AD.cstate.q) p.set('q', AD.cstate.q);
  const l = await api('GET', '/admin/conversations?' + p);
  setPage(await adminShell(head('บันทึกแชต', 'ดูย้อนหลังได้ทุกบทสนทนา รวมข้อความที่ถูกบล็อก (การเปิดดูจะถูกบันทึกในประวัติระบบ)') +
    `<div class="row" style="margin-bottom:1rem"><input class="in grow" type="search" placeholder="ค้นหาชื่อหรือเลขประจำตัว" value="${esc(AD.cstate.q)}" data-in="cq" aria-label="ค้นหาแชต"><button class="chip ${AD.cstate.flagged ? 'on' : ''}" data-act="cflag">เฉพาะที่มีข้อความถูกบล็อก</button></div>
    <div class="card flat" style="padding:.4rem">${l.length ? l.map((c) => `<a class="conv" href="#/admin/chats/${c.id}"><span class="avatar">${c.flagged ? '!' : initial(c.a)}</span><div class="grow"><div class="t">${esc(c.title)}</div><div class="last">${esc(c.a)} ↔ ${esc(c.b)}</div></div><div class="xs mute" style="text-align:right">${c.msgs} ข้อความ${c.flagged ? `<div><span class="pill bad">บล็อก ${c.flagged}</span></div>` : ''}<div>${ago(c.last_at)}</div></div></a>`).join('') : empty('chat', 'ไม่มีบทสนทนา')}</div>`, 'chats'));
  if (id) AD.chatView(id);
};
SK.inputs.cq = debounce((el) => { AD.cstate.q = el.value.trim(); AD.chats(); });
SK.acts.cflag = () => { AD.cstate.flagged = !AD.cstate.flagged; AD.chats(); };
AD.chatView = async (id) => {
  try {
    const c = await api('GET', '/admin/conversations/' + id);
    modal(`<div class="row between"><h2>${esc(c.title)}</h2><a class="btn ghost sm" href="#/admin/chats" data-act="close" aria-label="ปิด">${ic('x')}</a></div><p class="sm mute">ผู้ร่วมสนทนา: <b>${esc(c.a.label)}</b> และ <b>${esc(c.b.label)}</b></p>
      <div style="max-height:60vh;overflow:auto;margin-top:.8rem">${c.messages.map((m) => `<div class="log-m ${m.blocked ? 'blocked' : ''} ${m.system ? 'system' : ''}">${m.system ? '' : `<div class="xs b">${esc(m.sender)}${m.anon_shown ? ' <span class="pill info">แสดงเป็นนามแฝง</span>' : ''}</div>`}<div style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(m.body)}</div>
      <div class="xs mute">${full(m.created_at)}${m.blocked ? ` · <b style="color:var(--bad)">ถูกบล็อก: ${esc(m.reasons)}</b> (อีกฝ่ายไม่เห็นข้อความนี้)` : ''}</div></div>`).join('')}</div>`, true);
    $('#modal a[data-act=close]').addEventListener('click', () => { closeModal(); });
  } catch (e) { fail(e); }
};

/* ---------- audit ---------- */
AD.astate = { q: '' };
AD.audit = async () => {
  const l = await api('GET', '/admin/audit?limit=300&q=' + encodeURIComponent(AD.astate.q));
  setPage(await adminShell(head('ประวัติการใช้งานระบบ', 'บันทึกการเข้าสู่ระบบ การโพสต์ การบล็อกแชต และการกระทำของแอดมินทุกครั้ง') + `<input class="in" type="search" style="margin-bottom:1rem" placeholder="ค้นหา เช่น ชื่อ เลขประจำตัว หรือการกระทำ" value="${esc(AD.astate.q)}" data-in="auq" aria-label="ค้นหาประวัติ">
    <div class="tbl-wrap"><table><thead><tr><th>เวลา</th><th>ผู้ใช้</th><th>การกระทำ</th><th>รายละเอียด</th><th>IP</th></tr></thead><tbody id="aud-body">${auditRows(l)}</tbody></table></div>`, 'audit'));
};
const auditRows = (l) => l.map((a) => `<tr><td style="white-space:nowrap">${full(a.created_at)}</td><td>${a.name ? esc(a.name) + `<div class="xs mute">${esc(a.student_id)}</div>` : '-'}</td><td><span class="pill ${/blocked|failed/.test(a.action) ? 'bad' : a.action.startsWith('admin') ? 'info' : ''}">${esc(actTh(a.action))}</span></td><td>${esc(a.detail || '')}</td><td class="xs mute">${esc(a.ip || '')}</td></tr>`).join('') || '<tr><td colspan="5" class="center mute">ไม่พบข้อมูล</td></tr>';
SK.inputs.auq = debounce(async (el) => { AD.astate.q = el.value.trim(); const l = await api('GET', '/admin/audit?limit=300&q=' + encodeURIComponent(AD.astate.q)); $('#aud-body').innerHTML = auditRows(l); });

/* ---------- settings ---------- */
AD.settings = async () => {
  const s = await api('GET', '/admin/settings');
  setPage(await adminShell(head('ตั้งค่าระบบ') + `<form class="card stack" data-form="settings" style="max-width:720px">
    <label class="field"><span>ชื่อโรงเรียน</span><input class="in" name="school_name" value="${esc(s.school_name)}"></label>
    <label class="field"><span>คะแนนความดีที่ให้เมื่อช่วยคืนของ (ค่าเริ่มต้น)</span><input class="in" type="number" name="points_return" min="0" max="1000" value="${esc(s.points_return)}"></label>
    <label class="field"><span>วิชาในระบบติวเตอร์</span><textarea class="in" name="subjects">${esc(s.subjects)}</textarea><small>คั่นด้วยเครื่องหมายจุลภาค (,)</small></label>
    <label class="field"><span>หมวดหมู่ของหาย</span><textarea class="in" name="categories">${esc(s.categories)}</textarea></label>
    <label class="field"><span>สถานที่ในโรงเรียน</span><textarea class="in" name="locations">${esc(s.locations)}</textarea></label>
    <label class="field"><span>คำต้องห้ามในแชต/ประกาศ (เพิ่มเติมจากที่ระบบมีอยู่)</span><textarea class="in" name="blocked_words">${esc(s.blocked_words)}</textarea><small>ระบบบล็อกอยู่แล้ว: เบอร์โทร/เลขยาว อีเมล ลิงก์ @ชื่อผู้ใช้ และชื่อ Facebook, Instagram, TikTok, LINE ฯลฯ</small></label>
    <div class="row"><button class="btn" type="submit">บันทึกการตั้งค่า</button></div></form>
    <form class="card stack mt2" data-form="pointsadj" style="max-width:720px"><h3>ปรับคะแนนความดีด้วยตนเอง</h3><div class="grid3"><label class="field"><span>เลขประจำตัว</span><input class="in" name="sid" required></label><label class="field"><span>คะแนน (+/-)</span><input class="in" type="number" name="delta" required></label><label class="field"><span>เหตุผล</span><input class="in" name="reason" maxlength="100"></label></div><div class="row"><button class="btn ghost" type="submit">ปรับคะแนน</button></div></form>`, 'settings'));
};
SK.forms.settings = async (f) => { try { const d = Object.fromEntries(new FormData(f)); await api('PUT', '/admin/settings', d); SK.meta = await api('GET', '/meta'); toast('บันทึกแล้ว', 'ok'); } catch (e) { fail(e); } };
SK.forms.pointsadj = async (f) => {
  try { const u = (await api('GET', '/admin/users?q=' + encodeURIComponent(f.elements.sid.value.trim()))).find((x) => x.student_id === f.elements.sid.value.trim()); if (!u) throw new Error('ไม่พบเลขประจำตัวนี้');
    await api('POST', '/admin/points', { user_id: u.id, delta: +f.elements.delta.value, reason: f.elements.reason.value }); toast('ปรับคะแนนแล้ว', 'ok'); f.reset(); } catch (e) { fail(e); }
};
