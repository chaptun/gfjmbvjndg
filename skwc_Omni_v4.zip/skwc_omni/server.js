const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { db, setting, allSettings, setS, list, hashPw, checkPw, ensureAdmin, ROLES, RANK, roleLabel } = require('./lib/db');
const theme = require('./lib/theme');
const { notify, notifyAll } = require('./lib/notify');
const { findMatches } = require('./lib/match');
const { check: filterText } = require('./lib/filter');

const app = express();
const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(__dirname, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(express.json({ limit: '4mb' }));
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self'; connect-src 'self'; frame-ancestors 'none'",
  });
  next();
});

/* ---------- helpers ---------- */
const SESSION_DAYS = 7;
const ip = (req) => req.ip || '';
function audit(userId, action, detail, req) {
  db.prepare('INSERT INTO audit(user_id,action,detail,ip) VALUES(?,?,?,?)').run(userId || null, action, detail ? String(detail).slice(0, 500) : null, req ? ip(req) : null);
}
function cookies(req) {
  const o = {};
  (req.headers.cookie || '').split(';').forEach((p) => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return o;
}
function alias(id) {
  return 'นิรนาม#' + crypto.createHash('sha1').update('skwc-anon-' + id).digest('hex').slice(0, 4).toUpperCase();
}
// แสดงชื่อต่อสาธารณะ: ถ้าไม่ระบุตัวตนจะเห็นแค่นามแฝง (แอดมินเห็นชื่อจริงเสมอผ่านหลังบ้าน)
function who(u, anon) {
  if (!u) return { name: 'ไม่ทราบ', anon: false };
  if (anon) return { name: alias(u.id), anon: true };
  return { name: u.name, grade: u.grade, room: u.room, anon: false, role: u.role, role_label: u.role === 'student' ? null : roleLabel(u.role) };
}
const userById = (id) => db.prepare('SELECT * FROM users WHERE id=?').get(id);
const wrap = (fn) => (req, res, next) => { try { fn(req, res, next); } catch (e) { console.error(e); res.status(500).json({ error: 'เกิดข้อผิดพลาดในระบบ' }); } };
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const str = (v, max) => String(v == null ? '' : v).trim().slice(0, max);
const int = (v, d = null) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };

function auth(req, res, next) {
  const tok = cookies(req).skwc_sid;
  if (!tok) return bad(res, 'กรุณาเข้าสู่ระบบ', 401);
  const s = db.prepare("SELECT * FROM sessions WHERE token=? AND expires_at > datetime('now')").get(tok);
  if (!s) return bad(res, 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่', 401);
  const u = userById(s.user_id);
  if (!u || !u.active) return bad(res, 'บัญชีนี้ถูกระงับ', 403);
  req.user = u; req.token = tok;
  next();
}
const needReady = (req, res, next) => (req.user.must_change ? bad(res, 'กรุณาเปลี่ยนรหัสผ่านก่อนใช้งาน', 403) : next());
// หลังบ้าน: เฉพาะ ผู้ดูแลระบบ (admin) และ ผู้อำนวยการ (director) เท่านั้น
const isBackend = (u) => u.role === 'admin' || u.role === 'director';
const adminOnly = (req, res, next) => (isBackend(req.user) ? next() : bad(res, 'เฉพาะผู้ดูแลระบบและผู้อำนวยการ', 403));
// ลงประกาศได้: สภานักเรียนขึ้นไป
const canAnnounce = (u) => (RANK[u.role] || 0) >= 1;
const staffOnly = (req, res, next) => (canAnnounce(req.user) ? next() : bad(res, 'เฉพาะสภานักเรียน ครู และผู้บริหารเท่านั้น', 403));
const user = [auth, needReady];
const admin = [auth, needReady, adminOnly];
const staff = [auth, needReady, staffOnly];

function saveImage(dataUrl, sub) {
  const m = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || '');
  if (!m) return null;
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 2.5 * 1024 * 1024 || buf.length < 100) return null;
  const sig = buf.subarray(0, 12);
  const okJpg = sig[0] === 0xff && sig[1] === 0xd8;
  const okPng = sig.subarray(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]));
  const okWebp = sig.subarray(0, 4).toString() === 'RIFF' && sig.subarray(8, 12).toString() === 'WEBP';
  if (!(okJpg || okPng || okWebp)) return null;
  const ext = okJpg ? 'jpg' : okPng ? 'png' : 'webp';
  const name = crypto.randomBytes(12).toString('hex') + '.' + ext;
  const dir = sub ? path.join(UPLOAD_DIR, sub) : UPLOAD_DIR;
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, name), buf);
  return name;
}

/* ---------- auth ---------- */
const fails = new Map();
app.post('/api/auth/login', wrap((req, res) => {
  const sid = str(req.body.student_id, 40);
  const pw = str(req.body.password, 100);
  const key = ip(req) + '|' + sid;
  const f = fails.get(key);
  if (f && f.n >= 8 && Date.now() - f.t < 10 * 60 * 1000) return bad(res, 'ลองผิดหลายครั้งเกินไป กรุณารอ 10 นาที', 429);
  const u = db.prepare('SELECT * FROM users WHERE student_id=?').get(sid);
  if (!u || !checkPw(pw, u.pass_hash)) {
    fails.set(key, { n: (f && Date.now() - f.t < 10 * 60 * 1000 ? f.n : 0) + 1, t: Date.now() });
    audit(u && u.id, 'login_failed', sid, req);
    return bad(res, 'เลขประจำตัวหรือรหัสผ่านไม่ถูกต้อง', 401);
  }
  if (!u.active) return bad(res, 'บัญชีนี้ถูกระงับ ติดต่อผู้ดูแลระบบ', 403);
  fails.delete(key);
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,datetime('now','+" + SESSION_DAYS + " days'))").run(token, u.id);
  res.set('Set-Cookie', `skwc_sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS * 86400}${req.secure ? '; Secure' : ''}`);
  audit(u.id, 'login', null, req);
  res.json({ ok: true });
}));
app.post('/api/auth/logout', auth, wrap((req, res) => {
  db.prepare('DELETE FROM sessions WHERE token=?').run(req.token);
  res.set('Set-Cookie', 'skwc_sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  audit(req.user.id, 'logout', null, req);
  res.json({ ok: true });
}));
function me(u) {
  const unread = db.prepare(`SELECT COUNT(*) c FROM messages m JOIN conversations c ON c.id=m.conv_id
    LEFT JOIN reads r ON r.conv_id=c.id AND r.user_id=?
    WHERE (c.user_a=? OR c.user_b=?) AND m.blocked=0 AND (m.sender_id IS NULL OR m.sender_id!=?) AND m.id > COALESCE(r.last_id,0)`).get(u.id, u.id, u.id, u.id).c;
  return { id: u.id, student_id: u.student_id, name: u.name, grade: u.grade, room: u.room, role: u.role, role_label: roleLabel(u.role), can_announce: canAnnounce(u), is_backend: isBackend(u), points: u.points,
    must_change: !!u.must_change, anon_status: u.anon_status, anon_enabled: !!u.anon_enabled, anon_note: u.anon_note, unread, notif_unread: db.prepare('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read=0').get(u.id).n };
}
app.get('/api/auth/me', auth, wrap((req, res) => res.json(me(req.user))));
app.post('/api/auth/change-password', auth, wrap((req, res) => {
  const cur = str(req.body.current, 100), nw = str(req.body.password, 100);
  if (!checkPw(cur, req.user.pass_hash)) return bad(res, 'รหัสผ่านปัจจุบันไม่ถูกต้อง');
  if (nw.length < 8) return bad(res, 'รหัสผ่านใหม่ต้องยาวอย่างน้อย 8 ตัวอักษร');
  if (/^[\d\s-]+$/.test(nw) && nw.replace(/\D/g, '').length === 13) return bad(res, 'ห้ามใช้เลขบัตรประชาชนเป็นรหัสผ่านใหม่');
  if (nw === req.user.student_id) return bad(res, 'รหัสผ่านต้องไม่เหมือนเลขประจำตัว');
  db.prepare('UPDATE users SET pass_hash=?, must_change=0 WHERE id=?').run(hashPw(nw), req.user.id);
  db.prepare('DELETE FROM sessions WHERE user_id=? AND token!=?').run(req.user.id, req.token);
  audit(req.user.id, 'change_password', null, req);
  res.json({ ok: true });
}));

/* ---------- หน้าตาเว็บ (สาธารณะ: ใช้ในหน้าล็อกอินด้วย) ---------- */
const SITE_KEYS = ['brand_name', 'school_name', 'theme_color', 'hero_title', 'hero_text', 'login_title', 'login_text', 'footer_text', 'ticker_on', 'ticker_text', 'anim_level', 'radius'];
function siteConfig() {
  const o = {}; for (const k of SITE_KEYS) o[k] = setting(k);
  o.logo = setting('logo') ? '/brand/' + setting('logo') : '/img/school-logo-dark.png';
  o.logo_light = setting('logo') ? '/brand/' + setting('logo') : '/img/school-logo.png';
  o.logo_custom = !!setting('logo');
  o.hero_image = setting('hero_image') ? '/brand/' + setting('hero_image') : null;
  o.features = { items: setting('feature_items') !== '0', tutor: setting('feature_tutor') !== '0', leaderboard: setting('feature_leaderboard') !== '0', ai: setting('feature_ai') !== '0', calendar: setting('feature_calendar') !== '0', suggest: setting('feature_suggest') !== '0' };
  o.ai_name = setting('ai_name') || 'skwc_AI';
  o.roles = {}; for (const r of ROLES) o.roles[r] = roleLabel(r);
  return o;
}
app.get('/api/public', wrap((req, res) => { res.set('Cache-Control', 'no-store'); res.json(siteConfig()); }));
app.get('/theme.css', (req, res) => {
  res.set({ 'Content-Type': 'text/css; charset=utf-8', 'Cache-Control': 'no-cache' });
  res.send(theme.css(allSettings(), /^#[0-9a-fA-F]{6}$/.test(req.query.c || '') ? req.query.c : null));
});
app.use('/brand', express.static(path.join(UPLOAD_DIR, 'brand'), { maxAge: '1h', index: false, dotfiles: 'deny' }));

app.get('/api/meta', auth, wrap((req, res) => res.json({
  school_name: setting('school_name'), subjects: list('subjects'), categories: list('categories'), locations: list('locations'),
  points_return: int(setting('points_return'), 10),
})));

/* ---------- anonymous mode ---------- */
app.post('/api/anon/request', user, wrap((req, res) => {
  if (['pending', 'approved'].includes(req.user.anon_status)) return bad(res, 'คุณส่งคำขอไปแล้ว');
  db.prepare("UPDATE users SET anon_status='pending', anon_note=? WHERE id=?").run(str(req.body.reason, 300), req.user.id);
  audit(req.user.id, 'anon_request', str(req.body.reason, 200), req);
  res.json(me(userById(req.user.id)));
}));
app.post('/api/anon/toggle', user, wrap((req, res) => {
  if (req.user.anon_status !== 'approved') return bad(res, 'ต้องได้รับการอนุมัติจากแอดมินก่อน', 403);
  const on = req.body.enabled ? 1 : 0;
  db.prepare('UPDATE users SET anon_enabled=? WHERE id=?').run(on, req.user.id);
  audit(req.user.id, on ? 'anon_on' : 'anon_off', null, req);
  res.json(me(userById(req.user.id)));
}));

/* ---------- lost & found ---------- */
function itemView(r, viewer) {
  const poster = userById(r.user_id);
  const resp = r.responder_id ? userById(r.responder_id) : null;
  const mine = r.user_id === viewer.id;
  const respIsMe = r.responder_id === viewer.id;
  const o = {
    id: r.id, kind: r.kind, title: r.title, description: r.description, category: r.category, location: r.location,
    event_date: r.event_date, photo: r.photo ? '/uploads/' + r.photo : null, status: r.status, created_at: r.created_at,
    returned_at: r.returned_at, poster: who(poster, r.anon), mine, responder_is_me: respIsMe,
    can_respond: r.status === 'open' && !mine,
  };
  if (mine || respIsMe) {
    o.responder = resp ? who(resp, r.responder_anon) : null;
    if (resp) {
      const c = db.prepare("SELECT id FROM conversations WHERE type='item' AND ref_id=? AND (user_a=? OR user_b=?)").get(r.id, viewer.id, viewer.id);
      o.conv_id = c ? c.id : null;
    }
    // ผู้ที่เป็นเจ้าของของ = ผู้ที่ยืนยันการได้รับของคืน
    const ownerIsMe = r.kind === 'found' ? respIsMe : mine;
    o.can_confirm_received = r.status === 'claimed' && ownerIsMe;
    o.can_release = r.status === 'claimed' && mine;
  }
  return o;
}
app.get('/api/items', user, wrap((req, res) => {
  const w = ["i.status!='hidden'"], p = [];
  if (['found', 'lost'].includes(req.query.kind)) { w.push('i.kind=?'); p.push(req.query.kind); }
  if (req.query.category) { w.push('i.category=?'); p.push(req.query.category); }
  if (req.query.location) { w.push('i.location=?'); p.push(req.query.location); }
  if (req.query.status === 'open') w.push("i.status IN ('open','claimed','pending_admin')");
  else if (req.query.status === 'returned') w.push("i.status='returned'");
  if (req.query.mine) { w.push('(i.user_id=? OR i.responder_id=?)'); p.push(req.user.id, req.user.id); }
  if (req.query.q) { w.push('(i.title LIKE ? OR i.description LIKE ? OR i.category LIKE ? OR i.location LIKE ?)'); const q = '%' + str(req.query.q, 60) + '%'; p.push(q, q, q, q); }
  const rows = db.prepare(`SELECT i.* FROM items i WHERE ${w.join(' AND ')} ORDER BY (i.status='returned'), i.id DESC LIMIT 120`).all(...p);
  res.json(rows.map((r) => itemView(r, req.user)));
}));
app.get('/api/items/:id', user, wrap((req, res) => {
  const r = db.prepare("SELECT * FROM items WHERE id=? AND status!='hidden'").get(req.params.id);
  if (!r) return bad(res, 'ไม่พบรายการนี้', 404);
  res.json(itemView(r, req.user));
}));
app.post('/api/items', user, wrap((req, res) => {
  const b = req.body;
  const kind = b.kind === 'lost' ? 'lost' : 'found';
  const title = str(b.title, 80);
  if (title.length < 2) return bad(res, 'กรุณาใส่ชื่อสิ่งของ');
  let photo = null;
  if (b.photo) { photo = saveImage(b.photo); if (!photo) return bad(res, 'ไฟล์รูปไม่ถูกต้อง (รองรับ JPG/PNG/WebP ไม่เกิน 2.5MB)'); }
  const anon = req.user.anon_enabled ? 1 : 0;
  const r = db.prepare('INSERT INTO items(kind,title,description,category,location,event_date,photo,user_id,anon) VALUES(?,?,?,?,?,?,?,?,?)')
    .run(kind, title, str(b.description, 500), str(b.category, 40), str(b.location, 60), str(b.event_date, 10), photo, req.user.id, anon);
  audit(req.user.id, 'item_post_' + kind, `#${r.lastInsertRowid} ${title}`, req);
  // จับคู่ของหายอัตโนมัติ: แจ้งทั้งสองฝ่ายเมื่อมีโพสต์ที่คล้ายกันมาก
  try {
    const me2 = db.prepare('SELECT * FROM items WHERE id=?').get(r.lastInsertRowid);
    const ms = findMatches(me2, 3, 0.38);
    if (ms.length) {
      notify(req.user.id, '🔎 มีโพสต์ที่อาจตรงกับของคุณ', `"${ms[0].item.title}" คล้ายกับ "${title}" ${Math.round(ms[0].score * 100)}%`, '#/item/' + ms[0].item.id, 'match');
      for (const m of ms) notify(m.item.user_id, '🔎 มีโพสต์ที่อาจตรงกับของคุณ', `"${title}" คล้ายกับ "${m.item.title}" ${Math.round(m.score * 100)}%`, '#/item/' + r.lastInsertRowid, 'match');
    }
  } catch (e) { console.error('match', e.message); }
  res.json({ id: r.lastInsertRowid });
}));
function sysMsg(convId, body) {
  db.prepare('INSERT INTO messages(conv_id,sender_id,body,system) VALUES(?,NULL,?,1)').run(convId, body);
  db.prepare("UPDATE conversations SET last_at=datetime('now') WHERE id=?").run(convId);
}
app.post('/api/items/:id/respond', user, wrap((req, res) => {
  const r = db.prepare("SELECT * FROM items WHERE id=? AND status='open'").get(req.params.id);
  if (!r) return bad(res, 'รายการนี้ไม่เปิดรับแล้ว', 404);
  if (r.user_id === req.user.id) return bad(res, 'ไม่สามารถตอบรับโพสต์ของตัวเองได้');
  const anon = req.user.anon_enabled ? 1 : 0;
  db.prepare("UPDATE items SET status='claimed', responder_id=?, responder_anon=? WHERE id=?").run(req.user.id, anon, r.id);
  let c = db.prepare("SELECT id FROM conversations WHERE type='item' AND ref_id=? AND user_a=? AND user_b=?").get(r.id, req.user.id, r.user_id);
  if (!c) c = { id: db.prepare("INSERT INTO conversations(type,ref_id,user_a,user_b) VALUES('item',?,?,?)").run(r.id, req.user.id, r.user_id).lastInsertRowid };
  sysMsg(c.id, r.kind === 'found'
    ? `ระบบ: มีผู้แจ้งว่าเป็นเจ้าของ "${r.title}" ผู้พบโปรดให้อธิบายลักษณะที่ไม่ปรากฏในรูปเพื่อยืนยัน แล้วนัดรับของในโรงเรียน`
    : `ระบบ: มีผู้แจ้งว่าพบ "${r.title}" เจ้าของโปรดสอบถามรายละเอียดและนัดรับของในโรงเรียน เมื่อได้รับของแล้วให้กดยืนยัน`);
  notify(r.user_id, r.kind === 'found' ? '🙋 มีคนบอกว่าเป็นเจ้าของของที่คุณพบ' : '🎉 มีคนพบของที่คุณตามหา', r.title, '#/chats/' + c.id, 'item');
  audit(req.user.id, 'item_respond', `#${r.id}`, req);
  res.json({ conv_id: c.id });
}));
app.post('/api/items/:id/release', user, wrap((req, res) => {
  const r = db.prepare("SELECT * FROM items WHERE id=? AND status='claimed' AND user_id=?").get(req.params.id, req.user.id);
  if (!r) return bad(res, 'ทำรายการไม่ได้', 404);
  db.prepare("UPDATE items SET status='open', responder_id=NULL WHERE id=?").run(r.id);
  audit(req.user.id, 'item_release', `#${r.id}`, req);
  res.json({ ok: true });
}));
app.post('/api/items/:id/received', user, wrap((req, res) => {
  const r = db.prepare("SELECT * FROM items WHERE id=? AND status='claimed'").get(req.params.id);
  if (!r) return bad(res, 'ทำรายการไม่ได้', 404);
  const ownerId = r.kind === 'found' ? r.responder_id : r.user_id;
  if (ownerId !== req.user.id) return bad(res, 'เฉพาะเจ้าของของเท่านั้นที่ยืนยันได้', 403);
  db.prepare("UPDATE items SET status='pending_admin', received_at=datetime('now') WHERE id=?").run(r.id);
  const c = db.prepare("SELECT id FROM conversations WHERE type='item' AND ref_id=?").get(r.id);
  if (c) sysMsg(c.id, 'ระบบ: เจ้าของยืนยันว่าได้รับของคืนแล้ว รอแอดมินตรวจสอบและให้คะแนนผู้พบ');
  audit(req.user.id, 'item_received', `#${r.id}`, req);
  res.json({ ok: true });
}));
app.post('/api/items/:id/close', user, wrap((req, res) => {
  const r = db.prepare("SELECT * FROM items WHERE id=? AND user_id=? AND status IN ('open','claimed')").get(req.params.id, req.user.id);
  if (!r) return bad(res, 'ทำรายการไม่ได้', 404);
  db.prepare("UPDATE items SET status='closed' WHERE id=?").run(r.id);
  audit(req.user.id, 'item_close', `#${r.id}`, req);
  res.json({ ok: true });
}));

/* ---------- tutor matching ---------- */
function ratingOf(uid) { const x = db.prepare('SELECT COUNT(*) n, AVG(stars) a FROM reviews WHERE target_id=?').get(uid); return x.n ? { avg: Math.round(x.a * 10) / 10, count: x.n } : null; }
function tutorView(r, viewer) {
  const poster = userById(r.user_id);
  return { id: r.id, kind: r.kind, grade: r.grade, subject: r.subject, topic: r.topic, schedule: r.schedule, status: r.status,
    created_at: r.created_at, poster: who(poster, r.anon), mine: r.user_id === viewer.id, rating: r.anon ? null : ratingOf(r.user_id) };
}
app.get('/api/tutor', user, wrap((req, res) => {
  const w = ["t.status='open'"], p = [];
  if (['offer', 'request'].includes(req.query.kind)) { w.push('t.kind=?'); p.push(req.query.kind); }
  if (int(req.query.grade)) { w.push('t.grade=?'); p.push(int(req.query.grade)); }
  if (req.query.subject) { w.push('t.subject=?'); p.push(req.query.subject); }
  if (req.query.mine) { w.length = 0; w.push("t.status!='hidden'", 't.user_id=?'); p.length = 0; p.push(req.user.id); }
  if (req.query.q) { w.push('(t.topic LIKE ? OR t.subject LIKE ?)'); const q = '%' + str(req.query.q, 60) + '%'; p.push(q, q); }
  res.json(db.prepare(`SELECT t.* FROM tutor_posts t WHERE ${w.join(' AND ')} ORDER BY t.id DESC LIMIT 120`).all(...p).map((r) => tutorView(r, req.user)));
}));
app.get('/api/tutor/matches', user, wrap((req, res) => {
  // จับคู่อัตโนมัติ: โพสต์ของฉันที่เปิดอยู่ ↔ โพสต์ฝั่งตรงข้ามที่ชั้น+วิชาเดียวกัน
  const mine = db.prepare("SELECT * FROM tutor_posts WHERE user_id=? AND status='open'").all(req.user.id);
  const out = mine.map((m) => ({
    post: tutorView(m, req.user),
    matches: db.prepare("SELECT * FROM tutor_posts WHERE status='open' AND kind!=? AND grade=? AND subject=? AND user_id!=? ORDER BY id DESC LIMIT 8")
      .all(m.kind, m.grade, m.subject, req.user.id).map((r) => tutorView(r, req.user)),
  }));
  res.json(out);
}));
app.post('/api/tutor', user, wrap((req, res) => {
  const b = req.body;
  const kind = b.kind === 'request' ? 'request' : 'offer';
  const grade = int(b.grade);
  if (!grade || grade < 1 || grade > 6) return bad(res, 'กรุณาเลือกชั้น ม.1–ม.6');
  const subject = str(b.subject, 40);
  if (!list('subjects').includes(subject)) return bad(res, 'กรุณาเลือกวิชา');
  const text = str(b.topic, 300), sched = str(b.schedule, 120);
  const extra = list('blocked_words');
  for (const t of [text, sched]) { const f = filterText(t, extra); if (!f.ok) return bad(res, 'ห้ามใส่ข้อมูลติดต่อส่วนตัวในโพสต์ (' + f.reasons[0] + ') ให้คุยผ่านแชตในเว็บเท่านั้น'); }
  const r = db.prepare('INSERT INTO tutor_posts(user_id,kind,grade,subject,topic,schedule,anon) VALUES(?,?,?,?,?,?,?)')
    .run(req.user.id, kind, grade, subject, text, sched, req.user.anon_enabled ? 1 : 0);
  audit(req.user.id, 'tutor_post_' + kind, `#${r.lastInsertRowid} ม.${grade} ${subject}`, req);
  res.json({ id: r.lastInsertRowid });
}));
app.post('/api/tutor/:id/contact', user, wrap((req, res) => {
  const t = db.prepare("SELECT * FROM tutor_posts WHERE id=? AND status='open'").get(req.params.id);
  if (!t) return bad(res, 'โพสต์นี้ปิดแล้ว', 404);
  if (t.user_id === req.user.id) return bad(res, 'นี่คือโพสต์ของคุณ');
  let c = db.prepare("SELECT id FROM conversations WHERE type='tutor' AND ref_id=? AND user_a=? AND user_b=?").get(t.id, req.user.id, t.user_id);
  if (!c) {
    c = { id: db.prepare("INSERT INTO conversations(type,ref_id,user_a,user_b) VALUES('tutor',?,?,?)").run(t.id, req.user.id, t.user_id).lastInsertRowid };
    sysMsg(c.id, `ระบบ: เริ่มแชตเรื่อง ${t.kind === 'offer' ? 'ติว' : 'ขอติว'} ${t.subject} ม.${t.grade} — คุยผ่านเว็บนี้เท่านั้น ห้ามแลกช่องทางติดต่อส่วนตัว`);
    audit(req.user.id, 'tutor_contact', `post #${t.id}`, req);
  }
  res.json({ conv_id: c.id });
}));
app.post('/api/tutor/:id/close', user, wrap((req, res) => {
  const r = db.prepare("UPDATE tutor_posts SET status='closed' WHERE id=? AND user_id=? AND status='open'").run(req.params.id, req.user.id);
  if (!r.changes) return bad(res, 'ทำรายการไม่ได้', 404);
  audit(req.user.id, 'tutor_close', `#${req.params.id}`, req);
  res.json({ ok: true });
}));

/* ---------- chat ---------- */
function convFor(req) {
  const c = db.prepare('SELECT * FROM conversations WHERE id=? AND (user_a=? OR user_b=?)').get(req.params.id, req.user.id, req.user.id);
  return c;
}
function convTitle(c) {
  if (c.type === 'tutor') { const t = db.prepare('SELECT * FROM tutor_posts WHERE id=?').get(c.ref_id); return t ? `${t.kind === 'offer' ? 'ติว' : 'ขอติว'} ${t.subject} · ม.${t.grade}` : 'ติวเตอร์'; }
  const i = db.prepare('SELECT title,kind FROM items WHERE id=?').get(c.ref_id);
  return i ? `${i.kind === 'found' ? 'พบ' : 'ตามหา'}: ${i.title}` : 'ของหาย';
}
app.get('/api/conversations', user, wrap((req, res) => {
  const rows = db.prepare('SELECT * FROM conversations WHERE user_a=? OR user_b=? ORDER BY last_at DESC, id DESC').all(req.user.id, req.user.id);
  res.json(rows.map((c) => {
    const other = userById(c.user_a === req.user.id ? c.user_b : c.user_a);
    const last = db.prepare('SELECT body,system FROM messages WHERE conv_id=? AND blocked=0 ORDER BY id DESC LIMIT 1').get(c.id);
    const rd = db.prepare('SELECT last_id FROM reads WHERE conv_id=? AND user_id=?').get(c.id, req.user.id);
    const unread = db.prepare('SELECT COUNT(*) n FROM messages WHERE conv_id=? AND blocked=0 AND id>? AND (sender_id IS NULL OR sender_id!=?)').get(c.id, rd ? rd.last_id : 0, req.user.id).n;
    return { id: c.id, type: c.type, ref_id: c.ref_id, title: convTitle(c), other: who(other, other.anon_enabled), last: last ? last.body.slice(0, 80) : '', last_at: c.last_at, unread };
  }));
}));
app.get('/api/conversations/:id', user, wrap((req, res) => {
  const c = convFor(req);
  if (!c) return bad(res, 'ไม่พบการสนทนา', 404);
  const other = userById(c.user_a === req.user.id ? c.user_b : c.user_a);
  res.json({ id: c.id, type: c.type, ref_id: c.ref_id, title: convTitle(c), other: who(other, other.anon_enabled) });
}));
app.get('/api/conversations/:id/messages', user, wrap((req, res) => {
  const c = convFor(req);
  if (!c) return bad(res, 'ไม่พบการสนทนา', 404);
  const after = int(req.query.after, 0);
  const rows = db.prepare('SELECT * FROM messages WHERE conv_id=? AND blocked=0 AND id>? ORDER BY id LIMIT 300').all(c.id, after);
  if (rows.length) db.prepare('INSERT INTO reads(conv_id,user_id,last_id) VALUES(?,?,?) ON CONFLICT(conv_id,user_id) DO UPDATE SET last_id=MAX(last_id,excluded.last_id)').run(c.id, req.user.id, rows[rows.length - 1].id);
  res.json(rows.map((m) => ({ id: m.id, body: m.body, system: !!m.system, mine: m.sender_id === req.user.id, created_at: m.created_at,
    sender: m.system ? null : (m.anon ? alias(m.sender_id) : userById(m.sender_id).name) })));
}));
app.post('/api/conversations/:id/messages', user, wrap((req, res) => {
  const c = convFor(req);
  if (!c) return bad(res, 'ไม่พบการสนทนา', 404);
  const body = str(req.body.body, 500);
  if (!body) return bad(res, 'พิมพ์ข้อความก่อนส่ง');
  const f = filterText(body, list('blocked_words'));
  if (!f.ok) {
    db.prepare('INSERT INTO messages(conv_id,sender_id,body,anon,blocked,reasons) VALUES(?,?,?,?,1,?)').run(c.id, req.user.id, body, req.user.anon_enabled ? 1 : 0, f.reasons.join(', '));
    audit(req.user.id, 'chat_blocked', `conv #${c.id}: ${f.reasons.join(', ')}`, req);
    return res.status(422).json({ error: 'ส่งไม่ได้: ห้ามแชร์ข้อมูลติดต่อส่วนตัว (' + f.reasons.join(', ') + ') กรุณาคุยผ่านแชตในเว็บนี้เท่านั้น', blocked: true });
  }
  const r = db.prepare('INSERT INTO messages(conv_id,sender_id,body,anon) VALUES(?,?,?,?)').run(c.id, req.user.id, body, req.user.anon_enabled ? 1 : 0);
  db.prepare("UPDATE conversations SET last_at=datetime('now') WHERE id=?").run(c.id);
  res.json({ id: r.lastInsertRowid });
}));

/* ---------- announcements (ประกาศ) ---------- */
const LEVELS = ['normal', 'important', 'urgent'];
function annView(r, viewer) {
  const a = userById(r.author_id);
  return { id: r.id, title: r.title, body: r.body, photo: r.photo ? '/uploads/' + r.photo : null, level: r.level, pinned: !!r.pinned, status: r.status,
    created_at: r.created_at, updated_at: r.updated_at, author: a ? { name: a.name, role: a.role, role_label: roleLabel(a.role) } : { name: 'ไม่ทราบ', role: 'student', role_label: '' },
    can_edit: r.author_id === viewer.id || isBackend(viewer) };
}
app.get('/api/announcements', user, wrap((req, res) => {
  const w = [isBackend(req.user) && req.query.all ? "a.status!='deleted'" : "a.status='published'"], p = [];
  if (LEVELS.includes(req.query.level)) { w.push('a.level=?'); p.push(req.query.level); }
  if (req.query.q) { w.push('(a.title LIKE ? OR a.body LIKE ?)'); const q = '%' + str(req.query.q, 60) + '%'; p.push(q, q); }
  const rows = db.prepare(`SELECT a.* FROM announcements a WHERE ${w.join(' AND ')} ORDER BY a.pinned DESC, a.id DESC LIMIT 100`).all(...p);
  res.json(rows.map((r) => annView(r, req.user)));
}));
app.get('/api/announcements/:id', user, wrap((req, res) => {
  const r = db.prepare('SELECT * FROM announcements WHERE id=?').get(req.params.id);
  if (!r || (r.status !== 'published' && !isBackend(req.user) && r.author_id !== req.user.id)) return bad(res, 'ไม่พบประกาศนี้', 404);
  res.json(annView(r, req.user));
}));
function annFields(b, u, prev) {
  const title = str(b.title, 120), body = str(b.body, 4000);
  if (title.length < 2) return { err: 'กรุณาใส่หัวข้อประกาศ' };
  const level = LEVELS.includes(b.level) ? b.level : 'normal';
  // ปักหมุดได้เฉพาะครูขึ้นไป (สภานักเรียนประกาศได้แต่ไม่ปักหมุด)
  const pinned = (RANK[u.role] || 0) >= 2 ? (b.pinned ? 1 : 0) : (prev ? prev.pinned : 0);
  return { title, body, level, pinned };
}
app.post('/api/announcements', staff, wrap((req, res) => {
  const f = annFields(req.body, req.user); if (f.err) return bad(res, f.err);
  let photo = null;
  if (req.body.photo) { photo = saveImage(req.body.photo); if (!photo) return bad(res, 'ไฟล์รูปไม่ถูกต้อง (รองรับ JPG/PNG/WebP ไม่เกิน 2.5MB)'); }
  const r = db.prepare('INSERT INTO announcements(title,body,photo,level,pinned,author_id) VALUES(?,?,?,?,?,?)').run(f.title, f.body, photo, f.level, f.pinned, req.user.id);
  notifyAll((f.level === 'urgent' ? '🚨 ประกาศด่วน: ' : f.level === 'important' ? '📢 ประกาศสำคัญ: ' : '📢 ประกาศ: ') + f.title, `โดย ${req.user.name}`, '#/news/' + r.lastInsertRowid, 'news', req.user.id);
  audit(req.user.id, 'announce_create', `#${r.lastInsertRowid} ${f.title}`, req);
  res.json({ id: r.lastInsertRowid });
}));
function annOwn(req, res) {
  const r = db.prepare("SELECT * FROM announcements WHERE id=? AND status!='deleted'").get(req.params.id);
  if (!r) { bad(res, 'ไม่พบประกาศนี้', 404); return null; }
  if (r.author_id !== req.user.id && !isBackend(req.user)) { bad(res, 'แก้ไขได้เฉพาะประกาศของตัวเอง', 403); return null; }
  return r;
}
app.put('/api/announcements/:id', staff, wrap((req, res) => {
  const r = annOwn(req, res); if (!r) return;
  const f = annFields(req.body, req.user, r); if (f.err) return bad(res, f.err);
  let photo = r.photo;
  if (req.body.remove_photo) photo = null;
  if (req.body.photo) { photo = saveImage(req.body.photo); if (!photo) return bad(res, 'ไฟล์รูปไม่ถูกต้อง'); }
  db.prepare("UPDATE announcements SET title=?, body=?, photo=?, level=?, pinned=?, updated_at=datetime('now') WHERE id=?").run(f.title, f.body, photo, f.level, f.pinned, r.id);
  audit(req.user.id, 'announce_update', `#${r.id} ${f.title}`, req);
  res.json({ ok: true });
}));
app.delete('/api/announcements/:id', staff, wrap((req, res) => {
  const r = annOwn(req, res); if (!r) return;
  db.prepare("UPDATE announcements SET status='deleted' WHERE id=?").run(r.id);
  audit(req.user.id, 'announce_delete', `#${r.id} ${r.title}`, req);
  res.json({ ok: true });
}));

/* ---------- points ---------- */
app.get('/api/leaderboard', user, wrap((req, res) => {
  const rows = db.prepare("SELECT * FROM users WHERE role IN ('student','council') AND active=1 AND points>0 ORDER BY points DESC, id LIMIT 20").all();
  const meRank = db.prepare("SELECT COUNT(*)+1 r FROM users WHERE role IN ('student','council') AND active=1 AND points>?").get(req.user.points).r;
  res.json({ top: rows.map((u, i) => ({ rank: i + 1, ...who(u, u.anon_enabled), points: u.points, me: u.id === req.user.id })), my_rank: req.user.points > 0 ? meRank : null,
    returned_total: db.prepare("SELECT COUNT(*) n FROM items WHERE status='returned'").get().n });
}));
app.get('/api/me/points', user, wrap((req, res) => {
  res.json(db.prepare('SELECT delta,reason,created_at FROM points_log WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.user.id));
}));
app.get('/api/home', user, wrap((req, res) => {
  const c = (sql, ...p) => db.prepare(sql).get(...p).n;
  res.json({
    open_items: c("SELECT COUNT(*) n FROM items WHERE status IN ('open','claimed','pending_admin')"),
    returned: c("SELECT COUNT(*) n FROM items WHERE status='returned'"),
    tutor_open: c("SELECT COUNT(*) n FROM tutor_posts WHERE status='open'"),
    news_total: c("SELECT COUNT(*) n FROM announcements WHERE status='published'"),
    my_open: c("SELECT COUNT(*) n FROM items WHERE (user_id=? OR responder_id=?) AND status IN ('open','claimed','pending_admin')", req.user.id, req.user.id),
    news: db.prepare("SELECT * FROM announcements WHERE status='published' ORDER BY pinned DESC, id DESC LIMIT 4").all().map((r) => annView(r, req.user)),
    latest: db.prepare("SELECT * FROM items WHERE status IN ('open','claimed') ORDER BY id DESC LIMIT 4").all().map((r) => itemView(r, req.user)),
  });
}));

/* ---------- admin ---------- */
const A = '/api/admin';
app.get(A + '/stats', admin, wrap((req, res) => {
  const c = (sql, ...p) => db.prepare(sql).get(...p).n;
  const days = [];
  for (let i = 13; i >= 0; i--) {
    const d = db.prepare("SELECT date('now','localtime','-' || ? || ' day') d").get(i).d;
    days.push({ d, items: c("SELECT COUNT(*) n FROM items WHERE date(created_at,'localtime')=?", d), msgs: c('SELECT COUNT(*) n FROM messages WHERE system=0 AND blocked=0 AND date(created_at,\'localtime\')=?', d), tutor: c("SELECT COUNT(*) n FROM tutor_posts WHERE date(created_at,'localtime')=?", d) });
  }
  res.json({
    users: c("SELECT COUNT(*) n FROM users"), users_active: c("SELECT COUNT(*) n FROM users WHERE active=1"), news: c("SELECT COUNT(*) n FROM announcements WHERE status='published'"),
    items_open: c("SELECT COUNT(*) n FROM items WHERE status IN ('open','claimed')"), items_pending: c("SELECT COUNT(*) n FROM items WHERE status='pending_admin'"),
    items_returned: c("SELECT COUNT(*) n FROM items WHERE status='returned'"), items_total: c('SELECT COUNT(*) n FROM items'),
    tutor_open: c("SELECT COUNT(*) n FROM tutor_posts WHERE status='open'"), convs: c('SELECT COUNT(*) n FROM conversations'),
    blocked: c('SELECT COUNT(*) n FROM messages WHERE blocked=1'), anon_pending: c("SELECT COUNT(*) n FROM users WHERE anon_status='pending'"),
    points_total: c('SELECT COALESCE(SUM(delta),0) n FROM points_log'), days,
  });
}));
// users
const userRow = (u) => ({ id: u.id, student_id: u.student_id, name: u.name, grade: u.grade, room: u.room, role: u.role, role_label: roleLabel(u.role), active: !!u.active, points: u.points, anon_status: u.anon_status, anon_enabled: !!u.anon_enabled, anon_note: u.anon_note, created_at: u.created_at });
// ตั้งยศ ผู้ดูแล/ผอ. ได้เฉพาะผู้ดูแลระบบ (ผอ.เข้าหลังบ้านได้ แต่ตั้งผู้บริหารเพิ่มเองไม่ได้)
const canGrant = (actor, role) => (role === 'admin' || role === 'director' ? actor.role === 'admin' : true);
app.get(A + '/users', admin, wrap((req, res) => {
  const w = ['1=1'], p = [];
  if (req.query.q) { w.push('(student_id LIKE ? OR name LIKE ?)'); const q = '%' + str(req.query.q, 40) + '%'; p.push(q, q); }
  if (int(req.query.grade)) { w.push('grade=?'); p.push(int(req.query.grade)); }
  if (ROLES.includes(req.query.role)) { w.push('role=?'); p.push(req.query.role); }
  res.json(db.prepare(`SELECT * FROM users WHERE ${w.join(' AND ')} ORDER BY CASE role WHEN 'admin' THEN 0 WHEN 'director' THEN 1 WHEN 'teacher' THEN 2 WHEN 'council' THEN 3 ELSE 4 END, grade, room, student_id LIMIT 500`).all(...p).map(userRow));
}));
app.post(A + '/users', admin, wrap((req, res) => {
  const b = req.body, sid = str(b.student_id, 30), name = str(b.name, 80), pw = str(b.password, 100);
  if (!sid || !name || pw.length < 6) return bad(res, 'กรอกเลขประจำตัว ชื่อ และรหัสผ่านให้ครบ');
  if (db.prepare('SELECT 1 FROM users WHERE student_id=?').get(sid)) return bad(res, 'เลขประจำตัวนี้มีอยู่แล้ว');
  const role = ROLES.includes(b.role) ? b.role : 'student';
  if (!canGrant(req.user, role)) return bad(res, 'เฉพาะผู้ดูแลระบบเท่านั้นที่ตั้งยศ ผู้ดูแล/ผอ. ได้', 403);
  const r = db.prepare('INSERT INTO users(student_id,pass_hash,name,grade,room,role,must_change) VALUES(?,?,?,?,?,?,?)').run(sid, hashPw(pw), name, int(b.grade), str(b.room, 10), role, ['admin', 'director', 'teacher'].includes(role) ? 1 : 0);
  audit(req.user.id, 'admin_user_create', `${sid} ${name}`, req);
  res.json({ id: r.lastInsertRowid });
}));
app.put(A + '/users/:id', admin, wrap((req, res) => {
  const u = userById(req.params.id);
  if (!u) return bad(res, 'ไม่พบผู้ใช้', 404);
  const b = req.body;
  const active = b.active === undefined ? u.active : (b.active ? 1 : 0);
  if (u.id === req.user.id && !active) return bad(res, 'ไม่สามารถระงับบัญชีตัวเองได้');
  const role = b.role === undefined ? u.role : (ROLES.includes(b.role) ? b.role : u.role);
  if (u.id === req.user.id && role !== u.role) return bad(res, 'ไม่สามารถเปลี่ยนยศของตัวเองได้');
  if (u.role === 'admin' && req.user.role !== 'admin') return bad(res, 'แก้ไขบัญชีผู้ดูแลระบบได้เฉพาะผู้ดูแลระบบ', 403);
  if (role !== u.role && (!canGrant(req.user, role) || !canGrant(req.user, u.role))) return bad(res, 'เฉพาะผู้ดูแลระบบเท่านั้นที่ตั้ง/ถอดยศ ผู้ดูแล/ผอ. ได้', 403);
  db.prepare('UPDATE users SET name=?, grade=?, room=?, active=?, role=? WHERE id=?').run(str(b.name ?? u.name, 80), b.grade === undefined ? u.grade : int(b.grade), str(b.room ?? u.room, 10), active, role, u.id);
  if (!active) db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
  audit(req.user.id, 'admin_user_update', `${u.student_id}${b.active !== undefined ? (active ? ' เปิดใช้งาน' : ' ระงับ') : ''}${role !== u.role ? ` ยศ ${u.role}→${role}` : ''}`, req);
  res.json({ ok: true });
}));
app.post(A + '/users/:id/reset-password', admin, wrap((req, res) => {
  const u = userById(req.params.id), pw = str(req.body.password, 100);
  if (!u) return bad(res, 'ไม่พบผู้ใช้', 404);
  if (pw.length < 6) return bad(res, 'รหัสผ่านสั้นเกินไป');
  if (u.role === 'admin' && req.user.role !== 'admin') return bad(res, 'รีเซ็ตรหัสผู้ดูแลระบบได้เฉพาะผู้ดูแลระบบ', 403);
  db.prepare('UPDATE users SET pass_hash=?, must_change=? WHERE id=?').run(hashPw(pw), ['admin', 'director', 'teacher'].includes(u.role) ? 1 : 0, u.id);
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
  audit(req.user.id, 'admin_reset_password', u.student_id, req);
  res.json({ ok: true });
}));
app.post(A + '/users/import', admin, wrap((req, res) => {
  // CSV: เลขประจำตัว,เลขบัตรประชาชน,ชื่อ-สกุล,ชั้น(1-6),ห้อง
  const lines = String(req.body.csv || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean).slice(0, 2000);
  let created = 0, updated = 0; const errors = [];
  lines.forEach((l, i) => {
    const c = l.split(/[,\t]/).map((s) => s.trim());
    if (i === 0 && !/^\d/.test(c[0])) return; // header
    const [sid, pid, name, grade, room, rl] = c;
    const irole = ['student', 'council', 'teacher'].includes(rl) ? rl : null;
    if (!sid || !pid || !name) { errors.push(`บรรทัด ${i + 1}: ข้อมูลไม่ครบ`); return; }
    const ex = db.prepare('SELECT id FROM users WHERE student_id=?').get(sid);
    if (ex) { db.prepare('UPDATE users SET name=?, grade=?, room=?, pass_hash=?, role=COALESCE(?, role) WHERE id=? AND role NOT IN (\'admin\',\'director\')').run(name, int(grade), room || '', hashPw(pid), irole, ex.id); updated++; }
    else { db.prepare('INSERT INTO users(student_id,pass_hash,name,grade,room,role) VALUES(?,?,?,?,?,?)').run(sid, hashPw(pid), name, int(grade), room || '', irole || 'student'); created++; }
  });
  audit(req.user.id, 'admin_import', `สร้าง ${created} อัปเดต ${updated} ผิดพลาด ${errors.length}`, req);
  res.json({ created, updated, errors });
}));
// anonymity
app.get(A + '/anon', admin, wrap((req, res) => {
  res.json(db.prepare("SELECT * FROM users WHERE anon_status!='none' ORDER BY (anon_status='pending') DESC, id DESC").all().map(userRow));
}));
app.post(A + '/anon/:id', admin, wrap((req, res) => {
  const u = userById(req.params.id);
  if (!u) return bad(res, 'ไม่พบผู้ใช้', 404);
  const d = req.body.decision;
  if (d === 'approve') db.prepare("UPDATE users SET anon_status='approved' WHERE id=?").run(u.id);
  else if (d === 'reject') db.prepare("UPDATE users SET anon_status='rejected', anon_enabled=0 WHERE id=?").run(u.id);
  else if (d === 'revoke') db.prepare("UPDATE users SET anon_status='none', anon_enabled=0 WHERE id=?").run(u.id);
  else return bad(res, 'คำสั่งไม่ถูกต้อง');
  audit(req.user.id, 'admin_anon_' + d, u.student_id, req);
  res.json({ ok: true });
}));
// items
app.get(A + '/items', admin, wrap((req, res) => {
  const w = ['1=1'], p = [];
  if (req.query.status) { w.push('i.status=?'); p.push(req.query.status); }
  const rows = db.prepare(`SELECT i.*, u.name pname, u.student_id psid, u.grade pgrade, u.room proom, r.name rname, r.student_id rsid FROM items i JOIN users u ON u.id=i.user_id LEFT JOIN users r ON r.id=i.responder_id WHERE ${w.join(' AND ')} ORDER BY (i.status='pending_admin') DESC, i.id DESC LIMIT 200`).all(...p);
  res.json(rows.map((r) => ({ id: r.id, kind: r.kind, title: r.title, category: r.category, location: r.location, status: r.status, photo: r.photo ? '/uploads/' + r.photo : null, created_at: r.created_at, anon: !!r.anon,
    poster: `${r.pname} (${r.psid}${r.pgrade ? ' ม.' + r.pgrade + '/' + (r.proom || '') : ''})`, responder: r.rname ? `${r.rname} (${r.rsid})` : null, points_awarded: r.points_awarded,
    finder: r.kind === 'found' ? r.pname : r.rname })));
}));
app.post(A + '/items/:id/approve', admin, wrap((req, res) => {
  const r = db.prepare("SELECT * FROM items WHERE id=? AND status IN ('pending_admin','claimed')").get(req.params.id);
  if (!r) return bad(res, 'ทำรายการไม่ได้', 404);
  const finderId = r.kind === 'found' ? r.user_id : r.responder_id;
  if (!finderId) return bad(res, 'ยังไม่มีผู้พบ/ผู้ตอบรับ');
  const pts = int(req.body.points, int(setting('points_return'), 10));
  db.prepare("UPDATE items SET status='returned', returned_at=datetime('now'), points_awarded=? WHERE id=?").run(pts, r.id);
  db.prepare('UPDATE users SET points=points+? WHERE id=?').run(pts, finderId);
  db.prepare('INSERT INTO points_log(user_id,delta,reason,item_id,by_admin) VALUES(?,?,?,?,?)').run(finderId, pts, `ช่วยคืนของ: ${r.title}`, r.id, req.user.id);
  const c = db.prepare("SELECT id FROM conversations WHERE type='item' AND ref_id=?").get(r.id);
  if (c) sysMsg(c.id, `ระบบ: แอดมินยืนยันการคืนของแล้ว ผู้พบได้รับ ${pts} คะแนนความดี ขอบคุณที่ช่วยกัน`);
  notify(finderId, `⭐ ได้รับ +${pts} คะแนนความดี`, `ช่วยคืนของ: ${r.title}`, '#/profile', 'points');
  audit(req.user.id, 'admin_item_approve', `#${r.id} +${pts} → user ${finderId}`, req);
  res.json({ ok: true });
}));
app.post(A + '/items/:id/reject', admin, wrap((req, res) => {
  const r = db.prepare("UPDATE items SET status='open', responder_id=NULL WHERE id=? AND status IN ('pending_admin','claimed')").run(req.params.id);
  if (!r.changes) return bad(res, 'ทำรายการไม่ได้', 404);
  audit(req.user.id, 'admin_item_reject', `#${req.params.id}`, req);
  res.json({ ok: true });
}));
app.post(A + '/items/:id/status', admin, wrap((req, res) => {
  const s = req.body.status;
  if (!['open', 'closed', 'hidden'].includes(s)) return bad(res, 'สถานะไม่ถูกต้อง');
  db.prepare('UPDATE items SET status=? WHERE id=?').run(s, req.params.id);
  audit(req.user.id, 'admin_item_status', `#${req.params.id} → ${s}`, req);
  res.json({ ok: true });
}));
// tutor
app.get(A + '/tutor', admin, wrap((req, res) => {
  res.json(db.prepare("SELECT t.*, u.name, u.student_id FROM tutor_posts t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 200").all()
    .map((t) => ({ id: t.id, kind: t.kind, grade: t.grade, subject: t.subject, topic: t.topic, status: t.status, created_at: t.created_at, anon: !!t.anon, poster: `${t.name} (${t.student_id})` })));
}));
app.post(A + '/tutor/:id/status', admin, wrap((req, res) => {
  const s = req.body.status;
  if (!['open', 'closed', 'hidden'].includes(s)) return bad(res, 'สถานะไม่ถูกต้อง');
  db.prepare('UPDATE tutor_posts SET status=? WHERE id=?').run(s, req.params.id);
  audit(req.user.id, 'admin_tutor_status', `#${req.params.id} → ${s}`, req);
  res.json({ ok: true });
}));
// chat logs
app.get(A + '/conversations', admin, wrap((req, res) => {
  const w = ['1=1'], p = [];
  if (req.query.flagged) w.push('(SELECT COUNT(*) FROM messages m WHERE m.conv_id=c.id AND m.blocked=1)>0');
  if (req.query.q) { w.push('(a.name LIKE ? OR b.name LIKE ? OR a.student_id LIKE ? OR b.student_id LIKE ?)'); const q = '%' + str(req.query.q, 40) + '%'; p.push(q, q, q, q); }
  const rows = db.prepare(`SELECT c.*, a.name an, a.student_id asid, b.name bn, b.student_id bsid,
    (SELECT COUNT(*) FROM messages m WHERE m.conv_id=c.id AND m.system=0 AND m.blocked=0) msgs,
    (SELECT COUNT(*) FROM messages m WHERE m.conv_id=c.id AND m.blocked=1) flagged
    FROM conversations c JOIN users a ON a.id=c.user_a JOIN users b ON b.id=c.user_b WHERE ${w.join(' AND ')} ORDER BY c.last_at DESC LIMIT 200`).all(...p);
  res.json(rows.map((c) => ({ id: c.id, type: c.type, title: convTitle(c), a: `${c.an} (${c.asid})`, b: `${c.bn} (${c.bsid})`, msgs: c.msgs, flagged: c.flagged, last_at: c.last_at })));
}));
app.get(A + '/conversations/:id', admin, wrap((req, res) => {
  const c = db.prepare('SELECT * FROM conversations WHERE id=?').get(req.params.id);
  if (!c) return bad(res, 'ไม่พบการสนทนา', 404);
  const a = userById(c.user_a), b = userById(c.user_b);
  const msgs = db.prepare('SELECT * FROM messages WHERE conv_id=? ORDER BY id').all(c.id).map((m) => {
    const s = m.sender_id ? userById(m.sender_id) : null;
    return { id: m.id, system: !!m.system, blocked: !!m.blocked, reasons: m.reasons, body: m.body, created_at: m.created_at, anon_shown: !!m.anon, sender_id: m.sender_id, sender: s ? `${s.name} (${s.student_id})` : 'ระบบ' };
  });
  audit(req.user.id, 'admin_view_chat', `conv #${c.id}`, req);
  res.json({ id: c.id, title: convTitle(c), a: { id: a.id, label: `${a.name} (${a.student_id})` }, b: { id: b.id, label: `${b.name} (${b.student_id})` }, messages: msgs });
}));
// announcements (หลังบ้าน)
app.post(A + '/announcements/:id', admin, wrap((req, res) => {
  const r = db.prepare("SELECT * FROM announcements WHERE id=? AND status!='deleted'").get(req.params.id);
  if (!r) return bad(res, 'ไม่พบประกาศ', 404);
  const d = req.body.action;
  if (d === 'pin') db.prepare('UPDATE announcements SET pinned=1 WHERE id=?').run(r.id);
  else if (d === 'unpin') db.prepare('UPDATE announcements SET pinned=0 WHERE id=?').run(r.id);
  else if (d === 'hide') db.prepare("UPDATE announcements SET status='hidden' WHERE id=?").run(r.id);
  else if (d === 'show') db.prepare("UPDATE announcements SET status='published' WHERE id=?").run(r.id);
  else if (d === 'delete') db.prepare("UPDATE announcements SET status='deleted' WHERE id=?").run(r.id);
  else return bad(res, 'คำสั่งไม่ถูกต้อง');
  audit(req.user.id, 'admin_announce_' + d, `#${r.id} ${r.title}`, req);
  res.json({ ok: true });
}));
// หน้าตาเว็บ: อัปโหลดโลโก้/ภาพพื้นหลังฮีโร่
app.post(A + '/brand/:kind', admin, wrap((req, res) => {
  const kind = req.params.kind; if (!['logo', 'hero_image'].includes(kind)) return bad(res, 'ไม่ถูกต้อง');
  const name = saveImage(req.body.photo, 'brand'); if (!name) return bad(res, 'ไฟล์รูปไม่ถูกต้อง (JPG/PNG/WebP ไม่เกิน 2.5MB)');
  setS.run(kind, name); audit(req.user.id, 'admin_brand', kind, req); res.json(siteConfig());
}));
app.delete(A + '/brand/:kind', admin, wrap((req, res) => {
  const kind = req.params.kind; if (!['logo', 'hero_image'].includes(kind)) return bad(res, 'ไม่ถูกต้อง');
  setS.run(kind, ''); audit(req.user.id, 'admin_brand_remove', kind, req); res.json(siteConfig());
}));
// audit / points / settings
app.get(A + '/audit', admin, wrap((req, res) => {
  const w = ['1=1'], p = [];
  if (req.query.q) { w.push('(a.action LIKE ? OR a.detail LIKE ? OR u.name LIKE ? OR u.student_id LIKE ?)'); const q = '%' + str(req.query.q, 40) + '%'; p.push(q, q, q, q); }
  res.json(db.prepare(`SELECT a.id,a.action,a.detail,a.ip,a.created_at,u.name,u.student_id FROM audit a LEFT JOIN users u ON u.id=a.user_id WHERE ${w.join(' AND ')} ORDER BY a.id DESC LIMIT ${Math.min(int(req.query.limit, 200), 500)}`).all(...p));
}));
app.post(A + '/points', admin, wrap((req, res) => {
  const u = userById(req.body.user_id), d = int(req.body.delta);
  if (!u || !d || Math.abs(d) > 1000) return bad(res, 'ข้อมูลไม่ถูกต้อง');
  const reason = str(req.body.reason, 100) || 'แอดมินปรับคะแนน';
  db.prepare('UPDATE users SET points=MAX(0,points+?) WHERE id=?').run(d, u.id);
  db.prepare('INSERT INTO points_log(user_id,delta,reason,by_admin) VALUES(?,?,?,?)').run(u.id, d, reason, req.user.id);
  notify(u.id, `${d > 0 ? '⭐ ได้รับ' : '⚠️ ถูกหัก'} ${Math.abs(d)} คะแนน`, reason, '#/profile', 'points');
  audit(req.user.id, 'admin_points', `${u.student_id} ${d > 0 ? '+' : ''}${d} ${reason}`, req);
  res.json({ ok: true });
}));
const safeSettings = () => { const o = allSettings(); delete o.ai_api_key; return o; };
app.get(A + '/settings', admin, wrap((req, res) => res.json(safeSettings())));
app.put(A + '/settings', admin, wrap((req, res) => {
  const b = req.body, keys = Object.keys(allSettings());
  for (const k of keys) if (b[k] !== undefined && !k.startsWith('ai_')) {
    let v = str(b[k], 2000);
    if (k === 'points_return') v = String(Math.max(0, Math.min(1000, int(v, 10))));
    if (k === 'theme_color') v = theme.validColor(v);
    if (k === 'anim_level' && !['full', 'light', 'off'].includes(v)) v = 'full';
    if (k === 'radius' && !theme.RADIUS[v]) v = 'soft';
    if (k.startsWith('feature_') || k === 'ticker_on') v = (b[k] === true || v === '1' || v === 'true' || v === 'on') ? '1' : '0';
    if (k === 'logo' || k === 'hero_image') continue;   // เปลี่ยนผ่าน /brand เท่านั้น
    setS.run(k, v);
  }
  audit(req.user.id, 'admin_settings', Object.keys(b).join(','), req);
  res.json(safeSettings());
}));

/* ---------- ฟีเจอร์เสริม ---------- */
require('./routes/extra')(app, { db, wrap, bad, str, int, audit, who, userById, user, admin, staff, isBackend, RANK, roleLabel, setting, setS, list });
// PWA: manifest ปรับชื่อ/สีตามหลังบ้าน
app.get('/manifest.webmanifest', (req, res) => {
  res.type('application/manifest+json').json({ name: `${setting('brand_name')} — ${setting('school_name')}`, short_name: setting('brand_name'), start_url: '/', scope: '/', display: 'standalone', background_color: '#ffffff', theme_color: theme.validColor(setting('theme_color')), lang: 'th',
    icons: [{ src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' }, { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' }, { src: '/icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }] });
});

/* ---------- static ---------- */
app.use('/uploads', (req, res, next) => {
  const tok = cookies(req).skwc_sid;
  const ok = tok && db.prepare("SELECT 1 FROM sessions WHERE token=? AND expires_at > datetime('now')").get(tok);
  return ok ? next() : bad(res, 'กรุณาเข้าสู่ระบบ', 401);
}, express.static(UPLOAD_DIR, { maxAge: '1d', index: false, dotfiles: 'deny' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', (req, res) => bad(res, 'ไม่พบ API นี้', 404));
app.use((req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.use((err, req, res, next) => { console.error(err); res.status(err.status || 500).json({ error: err.status === 413 ? 'ไฟล์ใหญ่เกินไป' : 'เกิดข้อผิดพลาดในระบบ' }); });

setInterval(() => db.prepare("DELETE FROM sessions WHERE expires_at < datetime('now')").run(), 3600 * 1000).unref();
const initPw = ensureAdmin();
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`\n  skwc_Omni พร้อมใช้งาน → http://localhost:${PORT}`);
    if (initPw) console.log(`  สร้างบัญชีแอดมินแล้ว  ผู้ใช้: admin  รหัสผ่านเริ่มต้น: ${initPw}  (ระบบจะบังคับให้เปลี่ยนเมื่อเข้าสู่ระบบครั้งแรก)\n`);
  });
}
module.exports = app;
