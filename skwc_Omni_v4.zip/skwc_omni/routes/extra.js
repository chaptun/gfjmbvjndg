// ฟีเจอร์เสริม: แจ้งเตือน · ปฏิทิน · กล่องข้อเสนอแนะ · รีวิวติวเตอร์ · จับคู่ของหาย · รายงาน · skwc_AI
const crypto = require('crypto');
const ai = require('../lib/ai');
const { findMatches } = require('../lib/match');
const { notify, notifyAll } = require('../lib/notify');
const { check: filterText } = require('../lib/filter');

module.exports = function (app, c) {
  const { db, wrap, bad, str, int, audit, who, userById, user, admin, staff, isBackend, RANK, roleLabel, setting, setS, list } = c;
  const A = '/api/admin';
  const day = (d) => /^\d{4}-\d{2}-\d{2}$/.test(d || '') && !isNaN(Date.parse(d));
  const adminStrict = (req, res, next) => (req.user.role === 'admin' ? next() : bad(res, 'เฉพาะผู้ดูแลระบบ (admin) เท่านั้นที่เทรน/ตั้งค่า skwc_AI ได้', 403));
  const aiAdmin = [...admin, adminStrict];

  /* ---------- แจ้งเตือน ---------- */
  app.get('/api/notifications', user, wrap((req, res) => {
    const rows = db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 60').all(req.user.id);
    res.json({ unread: db.prepare('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read=0').get(req.user.id).n, items: rows });
  }));
  app.post('/api/notifications/read', user, wrap((req, res) => {
    if (req.body.all) db.prepare('UPDATE notifications SET read=1 WHERE user_id=?').run(req.user.id);
    else db.prepare('UPDATE notifications SET read=1 WHERE user_id=? AND id=?').run(req.user.id, int(req.body.id, 0));
    res.json({ ok: true });
  }));

  /* ---------- จับคู่ของหาย ---------- */
  app.get('/api/items/:id/matches', user, wrap((req, res) => {
    const it = db.prepare('SELECT * FROM items WHERE id=?').get(req.params.id);
    if (!it || it.status !== 'open') return res.json([]);
    res.json(findMatches(it).map((m) => ({ id: m.item.id, kind: m.item.kind, title: m.item.title, category: m.item.category, location: m.item.location, photo: m.item.photo ? '/uploads/' + m.item.photo : null, score: Math.round(m.score * 100) })));
  }));

  /* ---------- ปฏิทิน ---------- */
  const EV_TYPES = ['exam', 'activity', 'holiday', 'deadline', 'other'];
  const evView = (e, v) => { const a = e.created_by ? userById(e.created_by) : null; return { ...e, author: a ? { name: a.name, role: a.role, role_label: roleLabel(a.role) } : null, can_edit: e.created_by === v.id || isBackend(v) }; };
  app.get('/api/events', user, wrap((req, res) => {
    const from = day(req.query.from) ? req.query.from : '0000-01-01', to = day(req.query.to) ? req.query.to : '9999-12-31';
    const rows = db.prepare("SELECT * FROM events WHERE start_date<=? AND COALESCE(end_date,start_date)>=? ORDER BY start_date, id LIMIT 300").all(to, from);
    res.json(rows.map((e) => evView(e, req.user)));
  }));
  app.get('/api/events/upcoming', user, wrap((req, res) => {
    const today = new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
    res.json(db.prepare("SELECT * FROM events WHERE COALESCE(end_date,start_date)>=? ORDER BY start_date, id LIMIT ?").all(today, Math.min(10, int(req.query.n, 4))).map((e) => evView(e, req.user)));
  }));
  function evFields(b) {
    const title = str(b.title, 100); if (title.length < 2) return { err: 'กรุณาใส่ชื่อกิจกรรม' };
    if (!day(b.start_date)) return { err: 'วันที่เริ่มไม่ถูกต้อง' };
    const end = b.end_date && day(b.end_date) ? b.end_date : null; if (end && end < b.start_date) return { err: 'วันสิ้นสุดต้องไม่ก่อนวันเริ่ม' };
    return { title, description: str(b.description, 1000), location: str(b.location, 80), type: EV_TYPES.includes(b.type) ? b.type : 'activity', start_date: b.start_date, end_date: end };
  }
  app.post('/api/events', staff, wrap((req, res) => {
    const f = evFields(req.body); if (f.err) return bad(res, f.err);
    const r = db.prepare('INSERT INTO events(title,description,location,type,start_date,end_date,created_by) VALUES(?,?,?,?,?,?,?)').run(f.title, f.description, f.location, f.type, f.start_date, f.end_date, req.user.id);
    if (req.body.notify) notifyAll('📅 กิจกรรมใหม่: ' + f.title, f.start_date, '#/calendar', 'event', req.user.id);
    audit(req.user.id, 'event_create', `#${r.lastInsertRowid} ${f.title}`, req); res.json({ id: r.lastInsertRowid });
  }));
  const evOwn = (req, res) => { const e = db.prepare('SELECT * FROM events WHERE id=?').get(req.params.id); if (!e) { bad(res, 'ไม่พบกิจกรรม', 404); return null; } if (e.created_by !== req.user.id && !isBackend(req.user)) { bad(res, 'แก้ไขได้เฉพาะกิจกรรมของตัวเอง', 403); return null; } return e; };
  app.put('/api/events/:id', staff, wrap((req, res) => {
    const e = evOwn(req, res); if (!e) return; const f = evFields(req.body); if (f.err) return bad(res, f.err);
    db.prepare('UPDATE events SET title=?,description=?,location=?,type=?,start_date=?,end_date=? WHERE id=?').run(f.title, f.description, f.location, f.type, f.start_date, f.end_date, e.id);
    audit(req.user.id, 'event_update', `#${e.id}`, req); res.json({ ok: true });
  }));
  app.delete('/api/events/:id', staff, wrap((req, res) => { const e = evOwn(req, res); if (!e) return; db.prepare('DELETE FROM events WHERE id=?').run(e.id); audit(req.user.id, 'event_delete', `#${e.id} ${e.title}`, req); res.json({ ok: true }); }));

  /* ---------- กล่องข้อเสนอแนะ ---------- */
  const TO = ['council', 'director'];
  const canSee = (u, to) => (to === 'council' ? (RANK[u.role] || 0) >= 1 : u.role === 'director' || u.role === 'admin');
  app.post('/api/suggestions', user, wrap((req, res) => {
    const b = req.body, to = TO.includes(b.to_who) ? b.to_who : 'council', subject = str(b.subject, 100), body = str(b.body, 2000);
    if (subject.length < 2 || body.length < 5) return bad(res, 'กรุณาใส่หัวข้อและรายละเอียด');
    const today = new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
    const rate = db.prepare('SELECT n FROM suggest_rate WHERE user_id=? AND day=?').get(req.user.id, today);
    if (rate && rate.n >= 5) return bad(res, 'วันนี้ส่งครบ 5 เรื่องแล้ว พรุ่งนี้ส่งใหม่ได้นะ', 429);
    db.prepare('INSERT INTO suggest_rate(user_id,day,n) VALUES(?,?,1) ON CONFLICT(user_id,day) DO UPDATE SET n=n+1').run(req.user.id, today);
    const anon = !!b.anonymous, code = crypto.randomBytes(6).toString('base64').replace(/[^A-Za-z0-9]/g, 'x').slice(0, 8).toUpperCase();
    const r = db.prepare('INSERT INTO suggestions(user_id,code,to_who,subject,body) VALUES(?,?,?,?,?)').run(anon ? null : req.user.id, code, to, subject, body);
    // ไม่บันทึก audit ที่ผูกกับผู้ส่งเมื่อเลือกไม่ระบุชื่อ
    if (!anon) audit(req.user.id, 'suggest_send', `#${r.lastInsertRowid} → ${to}`, req);
    const targets = db.prepare(to === 'council' ? "SELECT id FROM users WHERE active=1 AND role IN ('council','teacher','director','admin')" : "SELECT id FROM users WHERE active=1 AND role IN ('director','admin')").all();
    for (const t of targets) notify(t.id, '📮 ข้อเสนอแนะใหม่: ' + subject, anon ? 'ไม่ระบุชื่อ' : '', '#/inbox', 'suggest');
    res.json({ id: r.lastInsertRowid, code, anonymous: anon });
  }));
  app.get('/api/suggestions/mine', user, wrap((req, res) => res.json(db.prepare('SELECT id,code,to_who,subject,body,status,reply,replied_at,created_at FROM suggestions WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.user.id))));
  app.get('/api/suggestions/track/:code', user, wrap((req, res) => {
    const s = db.prepare('SELECT subject,status,reply,replied_at,created_at,to_who FROM suggestions WHERE code=?').get(String(req.params.code || '').toUpperCase().slice(0, 12));
    if (!s) return bad(res, 'ไม่พบรหัสนี้', 404); res.json(s);
  }));
  app.get('/api/suggestions/inbox', staff, wrap((req, res) => {
    const rows = db.prepare('SELECT * FROM suggestions ORDER BY (status = \'new\') DESC, id DESC LIMIT 200').all().filter((s) => canSee(req.user, s.to_who));
    res.json(rows.map((s) => { const u = s.user_id ? userById(s.user_id) : null; const rb = s.replied_by ? userById(s.replied_by) : null; return { id: s.id, to_who: s.to_who, subject: s.subject, body: s.body, status: s.status, reply: s.reply, replied_at: s.replied_at, replied_by: rb ? rb.name : null, created_at: s.created_at, from: u ? { name: u.name, grade: u.grade, room: u.room } : null }; }));
  }));
  app.post('/api/suggestions/:id/reply', staff, wrap((req, res) => {
    const s = db.prepare('SELECT * FROM suggestions WHERE id=?').get(req.params.id); if (!s || !canSee(req.user, s.to_who)) return bad(res, 'ไม่พบเรื่องนี้', 404);
    const status = ['new', 'seen', 'done'].includes(req.body.status) ? req.body.status : null, reply = str(req.body.reply, 1500);
    if (reply) { db.prepare("UPDATE suggestions SET reply=?, replied_by=?, replied_at=datetime('now'), status='done' WHERE id=?").run(reply, req.user.id, s.id); if (s.user_id) notify(s.user_id, '💬 มีคำตอบข้อเสนอแนะของคุณ', s.subject, '#/suggest', 'suggest'); audit(req.user.id, 'suggest_reply', `#${s.id}`, req); }
    else if (status) db.prepare('UPDATE suggestions SET status=? WHERE id=?').run(status, s.id);
    res.json({ ok: true });
  }));

  /* ---------- รีวิวติวเตอร์ (จากหน้าแชตติวเตอร์) ---------- */
  const convOf = (req) => { const cv = db.prepare('SELECT * FROM conversations WHERE id=?').get(req.params.id); return cv && (cv.user_a === req.user.id || cv.user_b === req.user.id) ? cv : null; };
  app.get('/api/conversations/:id/review', user, wrap((req, res) => {
    const cv = convOf(req); if (!cv || cv.type !== 'tutor') return res.json({ can_review: false });
    const target = cv.user_a === req.user.id ? cv.user_b : cv.user_a, done = db.prepare('SELECT stars FROM reviews WHERE conv_id=? AND reviewer_id=?').get(cv.id, req.user.id);
    const msgs = db.prepare('SELECT COUNT(*) n FROM messages WHERE conv_id=? AND sender_id=?').get(cv.id, req.user.id).n;
    res.json({ can_review: !done && msgs >= 2, reviewed: done ? done.stars : null, target_name: who(userById(target), false).name });
  }));
  app.post('/api/conversations/:id/review', user, wrap((req, res) => {
    const cv = convOf(req); if (!cv || cv.type !== 'tutor') return bad(res, 'รีวิวได้เฉพาะแชตติวเตอร์', 404);
    const stars = int(req.body.stars, 0); if (stars < 1 || stars > 5) return bad(res, 'ให้ดาว 1-5');
    const comment = str(req.body.comment, 300); const f = filterText(comment, list('blocked_words')); if (!f.ok) return bad(res, 'ความเห็นมีข้อมูลติดต่อส่วนตัว (' + f.reasons[0] + ')');
    if (db.prepare('SELECT COUNT(*) n FROM messages WHERE conv_id=? AND sender_id=?').get(cv.id, req.user.id).n < 2) return bad(res, 'ต้องคุยกันก่อนจึงรีวิวได้');
    const target = cv.user_a === req.user.id ? cv.user_b : cv.user_a;
    try { db.prepare('INSERT INTO reviews(conv_id,reviewer_id,target_id,stars,comment) VALUES(?,?,?,?,?)').run(cv.id, req.user.id, target, stars, comment); } catch (e) { return bad(res, 'คุณรีวิวแชตนี้ไปแล้ว'); }
    notify(target, `⭐ คุณได้รับ ${stars} ดาว`, comment, '#/profile', 'review'); res.json({ ok: true });
  }));
  app.get('/api/users/:id/reviews', user, wrap((req, res) => {
    const rows = db.prepare('SELECT r.stars,r.comment,r.created_at,u.grade FROM reviews r JOIN users u ON u.id=r.reviewer_id WHERE r.target_id=? ORDER BY r.id DESC LIMIT 30').all(req.params.id);
    res.json({ count: rows.length, avg: rows.length ? +(rows.reduce((a, r) => a + r.stars, 0) / rows.length).toFixed(1) : null, list: rows.map((r) => ({ stars: r.stars, comment: r.comment, created_at: r.created_at, from: r.grade ? `นักเรียน ม.${r.grade}` : 'ผู้ใช้' })) });
  }));

  /* ---------- รายงานสรุป (พิมพ์/บันทึกเป็น PDF จากหน้าเว็บ) ---------- */
  app.get(A + '/report', admin, wrap((req, res) => {
    const days = Math.max(1, Math.min(365, int(req.query.days, 30))), since = `datetime('now','-${days} days')`, n = (sql, ...p) => db.prepare(sql).get(...p).n;
    const series = db.prepare(`SELECT date(created_at,'+7 hours') d, COUNT(*) n FROM items WHERE created_at>=${since} GROUP BY d ORDER BY d`).all();
    res.json({ days, generated_at: new Date().toISOString(), school: setting('school_name'),
      users: db.prepare('SELECT role, COUNT(*) n FROM users WHERE active=1 GROUP BY role').all().map((r) => ({ role: r.role, label: roleLabel(r.role), n: r.n })),
      items: { total: n(`SELECT COUNT(*) n FROM items WHERE created_at>=${since}`), lost: n(`SELECT COUNT(*) n FROM items WHERE kind='lost' AND created_at>=${since}`), found: n(`SELECT COUNT(*) n FROM items WHERE kind='found' AND created_at>=${since}`),
        returned: n(`SELECT COUNT(*) n FROM items WHERE status='returned' AND returned_at>=${since}`), open: n("SELECT COUNT(*) n FROM items WHERE status='open'"),
        avg_days: db.prepare(`SELECT ROUND(AVG(julianday(returned_at)-julianday(created_at)),1) v FROM items WHERE status='returned' AND returned_at>=${since}`).get().v,
        by_category: db.prepare(`SELECT COALESCE(NULLIF(category,''),'ไม่ระบุ') c, COUNT(*) n FROM items WHERE created_at>=${since} GROUP BY c ORDER BY n DESC LIMIT 6`).all(), series },
      tutor: { offers: n(`SELECT COUNT(*) n FROM tutor_posts WHERE kind='offer' AND created_at>=${since}`), requests: n(`SELECT COUNT(*) n FROM tutor_posts WHERE kind='request' AND created_at>=${since}`),
        chats: n(`SELECT COUNT(*) n FROM conversations WHERE type='tutor' AND last_at>=${since}`), reviews: n(`SELECT COUNT(*) n FROM reviews WHERE created_at>=${since}`), avg_stars: db.prepare(`SELECT ROUND(AVG(stars),2) v FROM reviews WHERE created_at>=${since}`).get().v },
      news: n(`SELECT COUNT(*) n FROM announcements WHERE status='published' AND created_at>=${since}`), events: n(`SELECT COUNT(*) n FROM events WHERE start_date>=date('now','-${days} days')`),
      suggestions: { total: n(`SELECT COUNT(*) n FROM suggestions WHERE created_at>=${since}`), replied: n(`SELECT COUNT(*) n FROM suggestions WHERE reply IS NOT NULL AND created_at>=${since}`) },
      ai: { questions: n(`SELECT COUNT(*) n FROM ai_logs WHERE is_test=0 AND created_at>=${since}`), good: n(`SELECT COUNT(*) n FROM ai_logs WHERE rating=1 AND is_test=0 AND created_at>=${since}`), bad: n(`SELECT COUNT(*) n FROM ai_logs WHERE rating=-1 AND is_test=0 AND created_at>=${since}`), unknown: n(`SELECT COUNT(*) n FROM ai_logs WHERE verdict='unknown' AND is_test=0 AND created_at>=${since}`) },
      points: { given: n(`SELECT COALESCE(SUM(delta),0) n FROM points_log WHERE delta>0 AND created_at>=${since}`), top: db.prepare(`SELECT u.name, u.grade, SUM(p.delta) s FROM points_log p JOIN users u ON u.id=p.user_id WHERE p.delta>0 AND p.created_at>=${since} GROUP BY p.user_id ORDER BY s DESC LIMIT 5`).all() } });
  }));

  /* ================= skwc_AI ================= */
  app.get('/api/ai/info', user, wrap((req, res) => {
    const sample = db.prepare("SELECT question FROM ai_qa WHERE active=1 ORDER BY RANDOM() LIMIT 5").all().map((r) => r.question);
    res.json({ enabled: setting('ai_enabled') !== '0', name: setting('ai_name') || 'skwc_AI', greeting: setting('ai_greeting'), mode: ai.mode(), samples: sample, rules: db.prepare('SELECT COUNT(*) n FROM ai_rules WHERE active=1').get().n });
  }));
  app.get('/api/ai/rules/:id', user, wrap((req, res) => { const r = db.prepare('SELECT id,title,content,category,severity,penalty,exceptions FROM ai_rules WHERE id=? AND active=1').get(req.params.id); r ? res.json(r) : bad(res, 'ไม่พบกฎ', 404); }));
  app.post('/api/ai/ask', user, wrap(async (req, res) => {
    if (setting('ai_enabled') === '0') return bad(res, 'skwc_AI ปิดใช้งานชั่วคราว', 503);
    const q = str(req.body.question, 500); if (q.length < 2) return bad(res, 'พิมพ์คำถามก่อนนะ');
    const lim = Math.max(1, int(setting('ai_limit_hour'), 20));
    if (db.prepare("SELECT COUNT(*) n FROM ai_logs WHERE user_id=? AND is_test=0 AND created_at>=datetime('now','-1 hour')").get(req.user.id).n >= lim) return bad(res, `ถามได้ ${lim} ครั้งต่อชั่วโมง รอสักครู่แล้วลองใหม่นะ`, 429);
    const r = await ai.ask({ question: q, history: Array.isArray(req.body.history) ? req.body.history : [] });
    const id = db.prepare('INSERT INTO ai_logs(user_id,question,answer,verdict,mode,confidence,rule_ids) VALUES(?,?,?,?,?,?,?)').run(req.user.id, q, r.answer, r.verdict, r.mode, r.confidence, JSON.stringify(r.rules.map((x) => x.id))).lastInsertRowid;
    delete r.debug; res.json({ id, ...r });
  }));
  app.post('/api/ai/feedback', user, wrap((req, res) => {
    const rating = int(req.body.rating, 0) > 0 ? 1 : -1;
    const r = db.prepare('UPDATE ai_logs SET rating=?, note=? WHERE id=? AND user_id=?').run(rating, str(req.body.note, 300), int(req.body.id, 0), req.user.id);
    r.changes ? res.json({ ok: true }) : bad(res, 'ไม่พบรายการ', 404);
  }));

  /* ---- ฝั่งแอดมิน (เฉพาะ role=admin เท่านั้น: ผอ./ครู/สภานักเรียนเทรนไม่ได้) ---- */
  const aiSettings = () => ({ ai_enabled: setting('ai_enabled') !== '0', ai_name: setting('ai_name'), ai_model: setting('ai_model'), ai_greeting: setting('ai_greeting'), ai_persona: setting('ai_persona'), ai_limit_hour: int(setting('ai_limit_hour'), 20), key_set: !!setting('ai_api_key'), env_key: !!process.env.ANTHROPIC_API_KEY, mode: ai.mode() });
  app.get(A + '/ai/overview', aiAdmin, wrap((req, res) => {
    const n = (s) => db.prepare(s).get().n;
    res.json({ settings: aiSettings(), rules: n('SELECT COUNT(*) n FROM ai_rules WHERE active=1'), qa: n('SELECT COUNT(*) n FROM ai_qa WHERE active=1'), logs: n('SELECT COUNT(*) n FROM ai_logs WHERE is_test=0'), unreviewed_bad: n('SELECT COUNT(*) n FROM ai_logs WHERE rating=-1 AND reviewed=0'), unknown: n("SELECT COUNT(*) n FROM ai_logs WHERE verdict='unknown' AND reviewed=0 AND is_test=0") });
  }));
  app.put(A + '/ai/settings', aiAdmin, wrap((req, res) => {
    const b = req.body;
    if (b.ai_enabled !== undefined) setS.run('ai_enabled', b.ai_enabled ? '1' : '0');
    for (const [k, m] of [['ai_name', 30], ['ai_model', 60], ['ai_greeting', 400], ['ai_persona', 800]]) if (b[k] !== undefined) setS.run(k, str(b[k], m) || (k === 'ai_name' ? 'skwc_AI' : ''));
    if (b.ai_limit_hour !== undefined) setS.run('ai_limit_hour', String(Math.max(1, Math.min(500, int(b.ai_limit_hour, 20)))));
    if (b.clear_key) setS.run('ai_api_key', ''); else if (b.ai_api_key && String(b.ai_api_key).trim().length > 10) setS.run('ai_api_key', String(b.ai_api_key).trim().slice(0, 300));
    audit(req.user.id, 'admin_ai_settings', Object.keys(b).filter((k) => k !== 'ai_api_key').join(',') + (b.ai_api_key ? ',key' : ''), req); res.json(aiSettings());
  }));
  const ruleFields = (b) => { const title = str(b.title, 100), content = str(b.content, 3000); if (title.length < 2 || content.length < 4) return { err: 'กรุณาใส่ชื่อกฎและเนื้อหา' }; return { title, content, category: str(b.category, 40), severity: ['prohibit', 'duty', 'info'].includes(b.severity) ? b.severity : 'prohibit', penalty: str(b.penalty, 400), exceptions: str(b.exceptions, 400), active: b.active === false || b.active === 0 ? 0 : 1 }; };
  app.get(A + '/ai/rules', aiAdmin, wrap((req, res) => { const q = str(req.query.q, 60); res.json(q ? db.prepare('SELECT * FROM ai_rules WHERE title LIKE ? OR content LIKE ? ORDER BY id DESC').all(`%${q}%`, `%${q}%`) : db.prepare('SELECT * FROM ai_rules ORDER BY id DESC').all()); }));
  app.post(A + '/ai/rules', aiAdmin, wrap((req, res) => { const f = ruleFields(req.body); if (f.err) return bad(res, f.err); const r = db.prepare('INSERT INTO ai_rules(title,content,category,severity,penalty,exceptions,active) VALUES(?,?,?,?,?,?,?)').run(f.title, f.content, f.category, f.severity, f.penalty, f.exceptions, f.active); audit(req.user.id, 'ai_rule_add', f.title, req); res.json({ id: r.lastInsertRowid }); }));
  app.put(A + '/ai/rules/:id', aiAdmin, wrap((req, res) => { const f = ruleFields(req.body); if (f.err) return bad(res, f.err); db.prepare("UPDATE ai_rules SET title=?,content=?,category=?,severity=?,penalty=?,exceptions=?,active=?,updated_at=datetime('now') WHERE id=?").run(f.title, f.content, f.category, f.severity, f.penalty, f.exceptions, f.active, req.params.id); audit(req.user.id, 'ai_rule_edit', `#${req.params.id} ${f.title}`, req); res.json({ ok: true }); }));
  app.delete(A + '/ai/rules/:id', aiAdmin, wrap((req, res) => { db.prepare('DELETE FROM ai_rules WHERE id=?').run(req.params.id); audit(req.user.id, 'ai_rule_del', '#' + req.params.id, req); res.json({ ok: true }); }));
  app.post(A + '/ai/import', aiAdmin, wrap(async (req, res) => {
    const text = str(req.body.text, 20000); if (text.length < 10) return bad(res, 'วางข้อความกฎก่อน');
    let rules = null, used = 'split';
    if (req.body.smart && ai.apiKey()) { try { rules = await ai.smartImport(text); if (rules && rules.length) used = 'ai'; } catch (e) { rules = null; } }
    if (!rules || !rules.length) rules = ai.splitRules(text);
    if (req.body.preview) return res.json({ used, rules });
    const ins = db.prepare('INSERT INTO ai_rules(title,content,category,severity,penalty,exceptions) VALUES(?,?,?,?,?,?)');
    for (const r of rules) ins.run(r.title, r.content, r.category, r.severity, r.penalty, r.exceptions);
    audit(req.user.id, 'ai_rule_import', `${rules.length} ข้อ (${used})`, req); res.json({ used, added: rules.length });
  }));
  app.get(A + '/ai/qa', aiAdmin, wrap((req, res) => res.json(db.prepare('SELECT * FROM ai_qa ORDER BY id DESC').all())));
  const qaFields = (b) => { const question = str(b.question, 300), answer = str(b.answer, 1500); if (question.length < 3 || answer.length < 2) return { err: 'กรุณาใส่คำถามและคำตอบ' }; return { question, answer, verdict: ['violates', 'ok', 'depends', 'unknown', 'info'].includes(b.verdict) ? b.verdict : 'info', active: b.active === false || b.active === 0 ? 0 : 1 }; };
  app.post(A + '/ai/qa', aiAdmin, wrap((req, res) => { const f = qaFields(req.body); if (f.err) return bad(res, f.err); const r = db.prepare('INSERT INTO ai_qa(question,answer,verdict,active) VALUES(?,?,?,?)').run(f.question, f.answer, f.verdict, f.active); audit(req.user.id, 'ai_qa_add', f.question.slice(0, 60), req); res.json({ id: r.lastInsertRowid }); }));
  app.put(A + '/ai/qa/:id', aiAdmin, wrap((req, res) => { const f = qaFields(req.body); if (f.err) return bad(res, f.err); db.prepare('UPDATE ai_qa SET question=?,answer=?,verdict=?,active=? WHERE id=?').run(f.question, f.answer, f.verdict, f.active, req.params.id); res.json({ ok: true }); }));
  app.delete(A + '/ai/qa/:id', aiAdmin, wrap((req, res) => { db.prepare('DELETE FROM ai_qa WHERE id=?').run(req.params.id); res.json({ ok: true }); }));
  app.post(A + '/ai/test', aiAdmin, wrap(async (req, res) => {
    const q = str(req.body.question, 500); if (q.length < 2) return bad(res, 'พิมพ์คำถามทดสอบ');
    const t0 = Date.now(), r = await ai.ask({ question: q, history: [], forceLocal: !!req.body.local }), h = ai.retrieve(q, ai.loadKb());
    db.prepare('INSERT INTO ai_logs(user_id,question,answer,verdict,mode,confidence,rule_ids,is_test,reviewed) VALUES(?,?,?,?,?,?,?,1,1)').run(req.user.id, q, r.answer, r.verdict, r.mode, r.confidence, JSON.stringify(r.rules.map((x) => x.id)));
    delete r.debug;
    res.json({ ...r, ms: Date.now() - t0, retrieved: [...h.qa.map((x) => ({ type: 'ตัวอย่าง Q&A', title: x.doc.q.question.slice(0, 70), score: +x.score.toFixed(2) })), ...h.rules.map((x) => ({ type: 'กฎ', title: x.doc.r.title, score: +x.score.toFixed(2) }))] });
  }));
  app.get(A + '/ai/logs', aiAdmin, wrap((req, res) => {
    const w = ['l.is_test=0'], p = [];
    if (req.query.filter === 'bad') w.push('l.rating=-1'); else if (req.query.filter === 'good') w.push('l.rating=1'); else if (req.query.filter === 'unknown') w.push("l.verdict='unknown'"); else if (req.query.filter === 'todo') w.push('l.reviewed=0 AND (l.rating=-1 OR l.verdict=\'unknown\')');
    if (req.query.q) { w.push('l.question LIKE ?'); p.push('%' + str(req.query.q, 60) + '%'); }
    res.json(db.prepare(`SELECT l.*, u.name uname, u.grade ugrade FROM ai_logs l LEFT JOIN users u ON u.id=l.user_id WHERE ${w.join(' AND ')} ORDER BY l.id DESC LIMIT 120`).all(...p));
  }));
  // เทรนจากผลจริง: แก้คำตอบที่ผิด/ตอบไม่ได้ → กลายเป็นตัวอย่าง Q&A ที่ AI ใช้ทันที
  app.post(A + '/ai/logs/:id/fix', aiAdmin, wrap((req, res) => {
    const l = db.prepare('SELECT * FROM ai_logs WHERE id=?').get(req.params.id); if (!l) return bad(res, 'ไม่พบ', 404);
    if (req.body.dismiss) { db.prepare('UPDATE ai_logs SET reviewed=1 WHERE id=?').run(l.id); return res.json({ ok: true }); }
    const f = qaFields({ question: req.body.question || l.question, answer: req.body.answer, verdict: req.body.verdict }); if (f.err) return bad(res, f.err);
    db.prepare("INSERT INTO ai_qa(question,answer,verdict,source) VALUES(?,?,?,'feedback')").run(f.question, f.answer, f.verdict);
    db.prepare('UPDATE ai_logs SET reviewed=1 WHERE id=?').run(l.id); audit(req.user.id, 'ai_train_from_log', `#${l.id}`, req); res.json({ ok: true });
  }));
  app.get(A + '/ai/export', aiAdmin, wrap((req, res) => { res.set('Content-Disposition', 'attachment; filename="skwc_ai_training.json"'); res.json({ version: 1, exported_at: new Date().toISOString(), rules: db.prepare('SELECT title,content,category,severity,penalty,exceptions,active FROM ai_rules').all(), qa: db.prepare('SELECT question,answer,verdict,active FROM ai_qa').all(), persona: setting('ai_persona'), greeting: setting('ai_greeting') }); }));
  app.post(A + '/ai/restore', aiAdmin, wrap((req, res) => {
    const d = req.body; if (!d || !Array.isArray(d.rules) || !Array.isArray(d.qa)) return bad(res, 'ไฟล์ไม่ถูกต้อง');
    if (d.replace) { db.prepare('DELETE FROM ai_rules').run(); db.prepare('DELETE FROM ai_qa').run(); }
    let a = 0, b = 0;
    for (const r of d.rules.slice(0, 500)) { const f = ruleFields(r); if (!f.err) { db.prepare('INSERT INTO ai_rules(title,content,category,severity,penalty,exceptions,active) VALUES(?,?,?,?,?,?,?)').run(f.title, f.content, f.category, f.severity, f.penalty, f.exceptions, f.active); a++; } }
    for (const q of d.qa.slice(0, 1000)) { const f = qaFields(q); if (!f.err) { db.prepare("INSERT INTO ai_qa(question,answer,verdict,active,source) VALUES(?,?,?,?,'import')").run(f.question, f.answer, f.verdict, f.active); b++; } }
    audit(req.user.id, 'ai_restore', `rules ${a}, qa ${b}`, req); res.json({ rules: a, qa: b });
  }));
};
